# Lab 2: Writing Your First Controller — Summary

This is a summary of the concepts and steps covered in the `lab2-first-controller.html` lesson.

## Goal
To build a functional Spring Boot REST API that handles HTTP GET requests, returns plain text and JSON, uses `@PathVariable` and `@RequestParam`, and removes the Whitelabel Error Page from your application.

## Step 1: Generate the Project
Use Spring Initializr (`start.spring.io`) with these exact settings:
* **Project:** Maven
* **Language:** Java
* **Spring Boot Version:** Latest stable (no SNAPSHOT/M/RC)
* **Group:** `com.example`
* **Artifact:** `hello-{yourFirstName}` (e.g., `hello-daniel`)
* **Name:** `hello-controller` (MUST manually change back to this)
* **Package name:** `com.example.hellocontroller` (MUST manually change back to this)
* **Packaging:** Jar
* **Java Version:** 17 or 21 (matching your installed JDK)
* **Dependency:** **Spring Web** (Only this one!)

Click **GENERATE**, download the ZIP, extract it, and open it in IntelliJ.

## Step 2: Create Your First Controller
1. Create a `controller` package inside `com.example.hellocontroller`.
2. Create a new Java class `HelloController` inside it.
3. Annotate the class with `@RestController`.
4. Add your first endpoint using `@GetMapping("/hello")`:
   ```java
   @GetMapping("/hello")
   public String sayHello() {
       return "Hello, Spring Boot!";
   }
   ```

## Step 3: Run and Test
Run `HelloControllerApplication`. If port `8080` is in use, either stop your Lab 1 application or change the port by adding `server.port=8081` to `application.properties`. 

Visit `http://localhost:8080/hello` in your browser to verify it works.

## Step 4: Add Dynamic Endpoints
Add these concepts to your controller to handle dynamic data:
* **`@PathVariable`:** Extracts values directly from the URL path.
  * Example: `@GetMapping("/hello/{name}")` maps to `http://localhost:8080/hello/Juan`.
* **`@RequestParam`:** Extracts values from the URL query string (after the `?`).
  * Example: `@GetMapping("/greet")` using `@RequestParam String name` maps to `http://localhost:8080/greet?name=Juan`.

## Step 5: Return JSON
Spring Boot automatically converts returned objects into JSON using Jackson.
1. Create a `model` package and add a `Greeting` class. **It must have standard Getter methods** for Jackson to work.
2. In your controller, add an endpoint `@GetMapping("/api/greeting")` that returns a new `Greeting` object.

## Step 6: Personalize the Application
Your submission must identify you as the developer:
1. Update your `/api/greeting` endpoint to return your own personal message and your full name.
2. Create a `Profile` model (with `name`, `school`, `eid`, and `funFact`) and expose it as JSON at `/whoami`.
3. Create a **custom topic endpoint** using `@PathVariable` (e.g., `/food/{dish}`) and return a personalized response.

## Step 7: Submission
Create a `screenshots/` folder inside your project containing 7 full-browser/full-window screenshots:
1. `01-hello.png`
2. `02-hello-name.png`
3. `03-greet.png`
4. `04-greeting.png`
5. `05-whoami.png`
6. `06-custom.png`
7. `07-intellij.png` (Full IDE window showing `HelloController.java`)

Compress the project folder (including `pom.xml`, `src`, and `screenshots`) into a ZIP file using the format:
`[EID]_Lab2-[School].zip` (e.g. `juan.dela.cruz_Lab2-TechUniv.zip`).
