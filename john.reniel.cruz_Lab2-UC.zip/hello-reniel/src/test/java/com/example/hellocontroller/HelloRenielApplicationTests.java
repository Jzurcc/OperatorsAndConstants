package com.example.hellocontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloRenielApplicationTests {

	@Test
	void contextLoads() {
	}

}
