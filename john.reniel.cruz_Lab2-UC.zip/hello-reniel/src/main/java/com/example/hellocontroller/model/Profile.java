package com.example.hellocontroller.model;

public class Profile {

    private String name;
    private String school;
    private String eid;
    private String funFact;

    public Profile(String name, String school, String eid, String funFact) {
        this.name = name;
        this.school = school;
        this.eid = eid;
        this.funFact = funFact;
    }

    public String getName() {
        return name;
    }

    public String getSchool() {
        return school;
    }

    public String getEid() {
        return eid;
    }

    public String getFunFact() {
        return funFact;
    }
}
