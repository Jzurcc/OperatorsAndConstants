package com.example.hellocontroller.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.hellocontroller.model.Greeting;
import com.example.hellocontroller.model.Profile;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String sayHello() {
        return "Hello, Spring Boot!";
    }

    @GetMapping("/hello/{name}")
    public String sayHelloTo(@PathVariable String name) {
        return "Hello, " + name + "!";
    }

    @GetMapping("/greet")
    public String greet(@RequestParam(defaultValue = "World") String name) {
        return "Greetings, " + name + "!";
    }

    @GetMapping("/api/greeting")
    public Greeting getGreeting() {
        return new Greeting("Greetings from the planet Earth.", "John Reniel D. Cruz", 2026);
    }

    @GetMapping("/whoami")
    public Profile whoAmI() {
        return new Profile(
                "John Reniel Cruz",
                "University of the Cordilleras",
                "john.reniel.cruz",
                "I love my girlfriend Jenny Ann Tumbaga Guyong from Cauayan City, Isabela!"
        );
    }

    @GetMapping("/research-papers/{paper}")
    public String displayResearchPaper(@PathVariable String paper) {
        return "This is my research paper titled, " + paper + "!";
    }
}
