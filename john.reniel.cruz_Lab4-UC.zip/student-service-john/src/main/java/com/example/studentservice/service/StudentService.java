package com.example.studentservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.studentservice.dto.StudentDto;
import com.example.studentservice.model.Student;
import com.example.studentservice.repository.StudentRepository;

@Service
public class StudentService {


    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    // ---------- Mapping helpers (private) ----------
    private StudentDto toDto(Student student) {
        return new StudentDto(
                student.getId(),
                student.getName(),
                student.getCourse(),
                student.getGrade()
        );
    }

    private Student toEntity(StudentDto dto) {
        return new Student(
                dto.getName(),
                dto.getCourse(),
                dto.getGrade()
        );
    }

    private Student findEntityOrThrow(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Student not found with id: " + id));
    }

    // ---------- Public CRUD methods (only DTOs) ----------
    public List<StudentDto> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public StudentDto getStudentById(Long id) {
        return toDto(findEntityOrThrow(id));
    }

    public StudentDto createStudent(StudentDto dto) {
        Student saved = studentRepository.save(toEntity(dto));
        return toDto(saved);
    }

    public StudentDto updateStudent(Long id, StudentDto dto) {
        Student existing = findEntityOrThrow(id);
        existing.setName(dto.getName());
        existing.setCourse(dto.getCourse());
        existing.setGrade(dto.getGrade());
        Student saved = studentRepository.save(existing);
        return toDto(saved);
    }

    public void deleteStudent(Long id) {
        findEntityOrThrow(id);  // throws 404 if not found
        studentRepository.deleteById(id);
    }

}
