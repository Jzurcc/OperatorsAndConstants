package com.example.studentservice.service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.example.studentservice.dto.StudentDto;
import com.example.studentservice.exception.StudentNotFoundException;
import com.example.studentservice.model.Student;
import com.example.studentservice.repository.StudentRepository;

class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllStudents() {
        // ARRANGE — the repository returns ENTITIES; the service maps them to DTOs
        Student student1 = new Student("Juan Dela Cruz", "Computer Science", new BigDecimal("1.5"));
        Student student2 = new Student("Maria Santos", "Information Technology", new BigDecimal("1.25"));
        List<Student> fakeStudents = Arrays.asList(student1, student2);

        when(studentRepository.findAll()).thenReturn(fakeStudents);

        // ACT — the service returns a List of DTOs, not entities
        List<StudentDto> result = studentService.getAllStudents();

        // ASSERT — verify the result is what we expect
        assertEquals(2, result.size());
        assertEquals("Juan Dela Cruz", result.get(0).getName());
        assertEquals("Maria Santos", result.get(1).getName());

        // VERIFY — confirm the repository was actually called
        verify(studentRepository, times(1)).findAll();
    }

    @Test
    void testGetStudentById_Found() {
        // Arrange — build an entity the mock will "find"
        Student student = new Student("Juan Dela Cruz", "Computer Science", new BigDecimal("1.5"));
        ReflectionTestUtils.setField(student, "id", 1L);

        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));

        // Act — the service returns a DTO
        StudentDto result = studentService.getStudentById(1L);

        // Assert
        assertNotNull(result);
        assertEquals("Juan Dela Cruz", result.getName());
        assertEquals(1L, result.getId());

        verify(studentRepository, times(1)).findById(1L);
    }

    @Test
    void testGetStudentById_NotFound() {
        // Arrange — return empty Optional (student doesn't exist)
        when(studentRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert — expect our custom StudentNotFoundException
        StudentNotFoundException exception = assertThrows(StudentNotFoundException.class, () -> {
            studentService.getStudentById(99L);
        });

        assertEquals("Student not found with id: 99", exception.getMessage());
        verify(studentRepository, times(1)).findById(99L);
    }

    @Test
    void testCreateStudent() {
        // Arrange — the client sends a DTO (no id yet)
        StudentDto inputDto = new StudentDto(null, "Maria Santos", "Information Technology", new BigDecimal("1.25"));

        // The entity the repository "saves" and returns (now with a DB-generated id)
        Student savedEntity = new Student("Maria Santos", "Information Technology", new BigDecimal("1.25"));
        ReflectionTestUtils.setField(savedEntity, "id", 1L);

        // The service calls save(toEntity(dto)) — a NEW Student it builds internally,
        // so we match ANY Student, not a specific object reference.
        when(studentRepository.save(any(Student.class))).thenReturn(savedEntity);

        // Act — pass a DTO, get a DTO back
        StudentDto result = studentService.createStudent(inputDto);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Maria Santos", result.getName());

        verify(studentRepository, times(1)).save(any(Student.class));
    }

    @Test
    void testUpdateStudent() {
        // Arrange — existing entity the repository will "find"
        Student existing = new Student("Juan Dela Cruz", "Computer Science", new BigDecimal("1.5"));
        ReflectionTestUtils.setField(existing, "id", 1L);

        // Updated data from the client, as a DTO
        StudentDto updatedData = new StudentDto(null, "Juan Dela Cruz", "Information Technology", new BigDecimal("1.0"));

        when(studentRepository.findById(1L)).thenReturn(Optional.of(existing));
        // The service mutates 'existing' then saves it — same object, so we can match it
        when(studentRepository.save(existing)).thenReturn(existing);

        // Act — pass a DTO, get a DTO back
        StudentDto result = studentService.updateStudent(1L, updatedData);

        // Assert — verify the fields were updated
        assertEquals("Information Technology", result.getCourse());
        assertEquals(0, result.getGrade().compareTo(new BigDecimal("1.0")));

        verify(studentRepository, times(1)).findById(1L);
        verify(studentRepository, times(1)).save(existing);
    }

    @Test
    void testDeleteStudent() {
        // Arrange — the service calls findEntityOrThrow(id) first, then deleteById(id)
        Student student = new Student("Juan Dela Cruz", "Computer Science", new BigDecimal("1.5"));
        ReflectionTestUtils.setField(student, "id", 1L);

        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        doNothing().when(studentRepository).deleteById(1L);

        // Act
        studentService.deleteStudent(1L);

        // Assert — verify both findById and deleteById were called
        verify(studentRepository, times(1)).findById(1L);
        verify(studentRepository, times(1)).deleteById(1L);
    }
}
