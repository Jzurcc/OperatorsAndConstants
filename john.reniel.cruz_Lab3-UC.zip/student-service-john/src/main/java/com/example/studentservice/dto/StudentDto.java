package com.example.studentservice.dto;

import java.math.BigDecimal;

public class StudentDto {

    private Long id;
    private String name;
    private String course;
    private BigDecimal grade;

    // Default constructor (required by Jackson to build the object from JSON)
    public StudentDto() {
    }

    public StudentDto(Long id, String name, String course, BigDecimal grade) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.grade = grade;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public BigDecimal getGrade() {
        return grade;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setGrade(BigDecimal grade) {
        this.grade = grade;
    }
}
