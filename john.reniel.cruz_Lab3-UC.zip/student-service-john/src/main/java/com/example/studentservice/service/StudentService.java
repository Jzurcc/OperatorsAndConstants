package com.example.studentservice.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.studentservice.dto.StudentDto;
import com.example.studentservice.model.Student;
import com.example.studentservice.repository.StudentRepository;

@Service
public class StudentService {

    private static final Logger logger = LoggerFactory.getLogger(StudentService.class);

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    // ---------- Mapping helpers (private) ----------
    private StudentDto toDto(Student student) {
        return new StudentDto(
                student.getId(),
                student.getName(),
                student.getCourse(),
                student.getGrade()
        );
    }

    private Student toEntity(StudentDto dto) {
        return new Student(
                dto.getName(),
                dto.getCourse(),
                dto.getGrade()
        );
    }

    private Student findEntityOrThrow(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Student not found with id: {}", id);
                    return new ResponseStatusException(
                            HttpStatus.NOT_FOUND, "Student not found with id: " + id);
                });
    }

    // ---------- Public CRUD methods (only DTOs) ----------
    public List<StudentDto> getAllStudents() {
        logger.info("Fetching all students");
        List<StudentDto> students = studentRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        logger.info("Found {} students", students.size());
        return students;
    }

    public StudentDto getStudentById(Long id) {
        logger.info("Fetching student with id: {}", id);
        return toDto(findEntityOrThrow(id));
    }

    public StudentDto createStudent(StudentDto dto) {
        logger.info("Creating student: name={}, course={}", dto.getName(), dto.getCourse());
        Student saved = studentRepository.save(toEntity(dto));
        logger.info("Student created with id: {}", saved.getId());
        return toDto(saved);
    }

    public StudentDto updateStudent(Long id, StudentDto dto) {
        logger.info("Updating student with id: {}", id);
        Student existing = findEntityOrThrow(id);
        existing.setName(dto.getName());
        existing.setCourse(dto.getCourse());
        existing.setGrade(dto.getGrade());
        Student saved = studentRepository.save(existing);
        logger.info("Student updated: id={}, name={}", saved.getId(), saved.getName());
        return toDto(saved);
    }

    public void deleteStudent(Long id) {
        logger.info("Deleting student with id: {}", id);
        findEntityOrThrow(id);  // throws 404 if not found
        studentRepository.deleteById(id);
        logger.info("Student deleted: id={}", id);
    }

    // Find by name
    public List<StudentDto> getStudentsByName(String name) {
        logger.info("Searching students by name: {}", name);
        return studentRepository.findByName(name).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Find by course
    public List<StudentDto> getStudentsByCourse(String course) {
        logger.info("Searching students by course: {}", course);
        return studentRepository.findByCourse(course).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Find by name containing keyword
    public List<StudentDto> getStudentsByNameContaining(String keyword) {
        logger.info("Searching students with name containing: {}", keyword);
        return studentRepository.findByNameContaining(keyword).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Find students with grade above a value
    public List<StudentDto> getStudentsWithGradeAbove(BigDecimal grade) {
        logger.info("Searching students with grade greater than: {}", grade);
        return studentRepository.findByGradeGreaterThan(grade).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Count students in a course
    public long countStudentsByCourse(String course) {
        logger.info("Counting students in course: {}", course);
        long count = studentRepository.countByCourse(course);
        logger.info("Found {} students in course: {}", count, course);
        return count;
    }
}
