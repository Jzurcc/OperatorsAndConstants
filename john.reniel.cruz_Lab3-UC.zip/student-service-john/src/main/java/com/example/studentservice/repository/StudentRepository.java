package com.example.studentservice.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.studentservice.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    // Find all students with exact name
    List<Student> findByName(String name);

    // Find all students in a specific course
    List<Student> findByCourse(String course);

    // Find students whose name contains a keyword (case-sensitive)
    List<Student> findByNameContaining(String keyword);

    // Find students with grade less than a value (lower grade = better in PH system)
    List<Student> findByGradeLessThan(BigDecimal grade);

    // Find students with grade greater than a value
    List<Student> findByGradeGreaterThan(BigDecimal grade);

    // Count students in a course
    long countByCourse(String course);

    // Custom JPQL query — find students by course (case-insensitive)
    @Query("SELECT s FROM Student s WHERE LOWER(s.course) = LOWER(:course)")
    List<Student> findByCourseIgnoreCase(@Param("course") String course);

// Custom JPQL query — search name and course at the same time
    @Query("SELECT s FROM Student s WHERE s.name LIKE %:keyword% OR s.course LIKE %:keyword%")
    List<Student> searchByKeyword(@Param("keyword") String keyword);
}
