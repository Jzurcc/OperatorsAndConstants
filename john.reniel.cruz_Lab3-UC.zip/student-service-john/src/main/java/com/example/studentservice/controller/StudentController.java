package com.example.studentservice.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.studentservice.dto.Profile;
import com.example.studentservice.dto.StudentDto;
import com.example.studentservice.service.StudentService;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // GET /api/students — get all students
    @GetMapping
    public List<StudentDto> getAllStudents() {
        return studentService.getAllStudents();
    }

    // GET /api/students/{id} — get one student
    @GetMapping("/{id}")
    public StudentDto getStudentById(@PathVariable Long id) {
        return studentService.getStudentById(id);
    }

    // POST /api/students — create a student
    @PostMapping
    public ResponseEntity<StudentDto> createStudent(@RequestBody StudentDto dto) {
        StudentDto created = studentService.createStudent(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // PUT /api/students/{id} — update a student
    @PutMapping("/{id}")
    public StudentDto updateStudent(@PathVariable Long id, @RequestBody StudentDto dto) {
        return studentService.updateStudent(id, dto);
    }

    // DELETE /api/students/{id} — delete a student
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }

    // GET /api/developer — returns YOUR profile as the developer of this API
    @GetMapping("/developer")
    public Profile getDeveloper() {
        return new Profile(
                "Juan Reniel D. Cruz",
                "University of the Cordilleras",
                "john.reniel.cruz",
                "I love my girlfriend Jenny Ann Tumbaga Guyong from Cauayan City, Isabela!"
        );
    }

    // GET /api/students/search/name/{name}
    @GetMapping("/search/name/{name}")
    public List<StudentDto> getStudentsByName(@PathVariable String name) {
        return studentService.getStudentsByName(name);
    }

    // GET /api/students/search/course/{course}
    @GetMapping("/search/course/{course}")
    public List<StudentDto> getStudentsByCourse(@PathVariable String course) {
        return studentService.getStudentsByCourse(course);
    }

    // GET /api/students/search/name-contains?keyword=Juan
    @GetMapping("/search/name-contains")
    public List<StudentDto> getStudentsByNameContaining(@RequestParam String keyword) {
        return studentService.getStudentsByNameContaining(keyword);
    }

    // GET /api/students/search/grade-above?grade=2.0
    @GetMapping("/search/grade-above")
    public List<StudentDto> getStudentsWithGradeAbove(@RequestParam BigDecimal grade) {
        return studentService.getStudentsWithGradeAbove(grade);
    }

    // GET /api/students/search/course-count?course=Computer Science
    @GetMapping("/search/course-count")
    public long countStudentsByCourse(@RequestParam String course) {
        return studentService.countStudentsByCourse(course);
    }
}
