package com.example.studentservice.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class StudentDto {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Course is required")
    private String course;

    @NotNull(message = "Grade is required")
    @DecimalMin(value = "1.0", message = "Grade must be at least 1.0")
    @DecimalMax(value = "5.0", message = "Grade must be at most 5.0")
    private BigDecimal grade;

    // Default constructor (required by Jackson to build the object from JSON)
    public StudentDto() {
    }

    public StudentDto(Long id, String name, String course, BigDecimal grade) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.grade = grade;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public BigDecimal getGrade() {
        return grade;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setGrade(BigDecimal grade) {
        this.grade = grade;
    }
}
