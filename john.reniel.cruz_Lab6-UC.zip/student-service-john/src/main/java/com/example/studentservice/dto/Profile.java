package com.example.studentservice.dto;

public class Profile {

    private final String name;
    private final String school;
    private final String eid;
    private final String funFact;

    public Profile(String name, String school, String eid, String funFact) {
        this.name = name;
        this.school = school;
        this.eid = eid;
        this.funFact = funFact;
    }

    public String getName() {
        return name;
    }

    public String getSchool() {
        return school;
    }

    public String getEid() {
        return eid;
    }

    public String getFunFact() {
        return funFact;
    }
}
