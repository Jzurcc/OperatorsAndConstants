package com.example.studentservice.model;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String course;
    private BigDecimal grade;

    // Default constructor (required by JPA)
    public Student() {
    }

    // Constructor with fields (without id — database generates it)
    public Student(String name, String course, BigDecimal grade) {
        this.name = name;
        this.course = course;
        this.grade = grade;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public BigDecimal getGrade() {
        return grade;
    }

    // Setters — note: no setId! The database owns the id (see callout below)
    public void setName(String name) {
        this.name = name;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setGrade(BigDecimal grade) {
        this.grade = grade;
    }
}
