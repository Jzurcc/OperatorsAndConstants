package com.example.studentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentServiceJohnApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServiceJohnApplication.class, args);
	}

}
