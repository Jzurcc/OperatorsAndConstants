package com.school.conditionals;

public class GradeChecker {
    public static void main(String[] args) {
        double average = 88.5;
        System.out.printf("Average: %s%n", average);
        if (average > 100) {
            System.out.println("Error: Average cannot be greater than 100");
        } else if (average >= 97) {
            System.out.println("Grade: 1.00");
        } else if (average >= 94) {
            System.out.println("Grade: 1.25");
        } else if (average >= 91) {
            System.out.println("Grade: 1.50");
        } else if (average >= 88) {
            System.out.println("Grade: 1.75");
        } else if (average >= 85) {
            System.out.println("Grade: 2.00");
        } else if (average >= 82) {
            System.out.println("Grade: 2.25");
        } else if (average >= 79) {
            System.out.println("Grade: 2.50");
        } else if (average >= 76) {
            System.out.println("Grade: 2.75");
        } else if (average >= 75) {
            System.out.println("Grade: 3.00");
        } else {
            System.out.println("Grade: 5.00 (Failed)");
        }
    }
}
