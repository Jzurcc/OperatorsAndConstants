package com.school.conditionals;

public class IfExample {
    public static void main(String[] args) {
        int temperature = 38;
        if (temperature > 37) {
            System.out.println("WARNING: You have a fever!");
        }
        System.out.printf("Your temperature is: %s%n", temperature);
    }
}
