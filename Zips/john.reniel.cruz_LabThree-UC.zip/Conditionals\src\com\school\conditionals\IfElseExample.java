package com.school.conditionals;

public class IfElseExample {
    public static void main(String[] args) {
        int number = 45;
        if (number % 2 == 0) {
            System.out.printf("%s is even%n", number);
        } else {
            System.out.printf("%s is odd%n", number);
        }
    }
}
