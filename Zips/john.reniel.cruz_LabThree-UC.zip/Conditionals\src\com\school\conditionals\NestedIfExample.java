package com.school.conditionals;

public class NestedIfExample {
    public static void main(String[] args) {
        int age = 20;
        boolean hasID = true;
        System.out.printf("Age: %s%n", age);
        System.out.printf("Has ID: %s%n", hasID);
        if (age >= 18) {
            if (hasID) {
                System.out.println("Access granted — welcome!");
            } else {
                System.out.println("You are old enough but need a valid ID.");
            }
        } else {
            System.out.println("Sorry, you must be 18 or older.");
        }
    }
}
