package com.school.conditionals;

public class LoginValidator {
    public static void main(String[] args) {
        String correctUser = "admin";
        String correctPass = "java123";
        String inputUser = "admin";
        String inputPass = "java123";
        
        if (inputUser.equals(correctUser) && inputPass.equals(correctPass)) {
            System.out.println("Login successful! Welcome, admin.");
        } else {
            System.out.println("Login failed. Invalid username or password.");
        }
    }
}
