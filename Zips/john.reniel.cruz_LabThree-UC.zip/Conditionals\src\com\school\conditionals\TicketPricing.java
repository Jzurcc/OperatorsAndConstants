package com.school.conditionals;

public class TicketPricing {
    static final double BASE_PRICE = 500.00;

    public static void main(String[] args) {
        int age = 25;
        String memberType = "Gold";
        
        System.out.printf("Age: %s%n", age);
        System.out.printf("Member type: %s%n", memberType);
        System.out.printf("Base price: %s%n", BASE_PRICE);
        
        double ageDiscountPercent = 0;
        if (age < 12) {
            ageDiscountPercent = 0.50;
        } else if (age >= 12 && age <= 17) {
            ageDiscountPercent = 0.25;
        } else if (age >= 18 && age <= 59) {
            ageDiscountPercent = 0.00;
        } else if (age >= 60) {
            ageDiscountPercent = 0.30;
        }
        
        double ageDiscount = BASE_PRICE * ageDiscountPercent;
        System.out.printf("Age discount: %s%n", ageDiscount);
        
        double priceAfterAgeDiscount = BASE_PRICE - ageDiscount;
        System.out.printf("Price after age discount: %s%n", priceAfterAgeDiscount);
        
        double memberDiscount = 0;
        switch (memberType) {
            case "Gold":
                memberDiscount = 100.0;
                break;
            case "Silver":
                memberDiscount = 50.0;
                break;
            case "Bronze":
                memberDiscount = 25.0;
                break;
            default:
                memberDiscount = 0.0;
                break;
        }
        
        System.out.printf("Member discount: %s%n", memberDiscount);
        
        double finalPrice = priceAfterAgeDiscount - memberDiscount;
        System.out.printf("Final price: %s%n", finalPrice);
    }
}
