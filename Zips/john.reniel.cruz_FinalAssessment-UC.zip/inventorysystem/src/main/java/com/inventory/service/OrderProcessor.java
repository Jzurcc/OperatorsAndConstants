package com.inventory.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.inventory.exception.InventoryException;
import com.inventory.exception.OutOfStockException;
import com.inventory.model.Product;
import com.inventory.model.Receipt;

public class OrderProcessor {

    private final Inventory inventory;
    private final List<String> log = new ArrayList<>();

    public OrderProcessor(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * Attempts to fulfill an order: 1. Look up the product by SKU 2. Check if
     * enough quantity is available 3. Reduce quantity by amountOrdered 4.
     * Always log the attempt in the log list
     */
    public Receipt processOrder(String sku, int amountOrdered) {
        try {
            Product product = inventory.getProduct(sku);
            if (product == null) {
                throw new InventoryException("SKU not found: " + sku);
            }

            if (product.getQuantity() < amountOrdered) {
                throw new OutOfStockException(product.getName(), amountOrdered);
            }

            List<String> receiptItems = List.of(product.getName());
            double totalCost = product.getPrice() * amountOrdered;

            product.setQuantity(product.getQuantity() - amountOrdered);
            return new Receipt(receiptItems, totalCost);

        } catch (InventoryException e) {
            System.err.println(e.getMessage());
            return null;
        } finally {
            log.add(String.format("Order attempt: SKU=%s, qty=%d", sku, amountOrdered));
        }
    }

    public List<String> getLog() {
        return Collections.unmodifiableList(log);
    }
}
