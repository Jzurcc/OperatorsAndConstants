package com.inventory.service;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.inventory.model.Product;

public class InventoryUtils {

    public static void sortByPrice(List<Product> products) {
        products.sort(Comparator.comparingDouble(Product::getPrice));
    }

    public static List<Product> filterByMinQuantity(List<Product> products, int min) {
        return products.stream()
                .filter(p -> p.getQuantity() >= min)
                .collect(Collectors.toList());
    }

    public static Set<String> getUniqueProductNames(List<Product> products) {
        return products.stream()
                .map(Product::getName)
                .collect(Collectors.toSet());
    }
}
