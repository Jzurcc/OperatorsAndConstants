package com.inventory.service;

import java.util.*;
import com.inventory.model.*;

public class DiscountProcessor {
    /**
     * Applies the given discount percentage to every product
     * in the list that implements Discountable.
     * Returns the count of items that were discounted.
     */
    public static int applyToEligible(List<Product> products, double pct) {
        int count = 0;
        for (Product product : products) {
            if (product instanceof Discountable d) {
                d.applyDiscount(pct);
                count++;
            }
        }
        return count;
    }
}