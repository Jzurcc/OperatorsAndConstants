package com.inventory.model;

import java.time.LocalDate;

public class Grocery extends Product {

    private final LocalDate expiryDate;

    public Grocery(String name, double price, int qty, LocalDate expiryDate) {
        super(name, price, qty);
        this.expiryDate = expiryDate;
    }

    public boolean isExpired() {
        return LocalDate.now().isAfter(expiryDate);

    }

    public LocalDate getexpiryDate() {
        return expiryDate;
    }

    @Override
    public String toString() {
        String status = isExpired() ? "EXPIRED" : "fresh";
        return super.toString() + String.format("  [%s — exp: %s]", status, expiryDate);
    }
}
