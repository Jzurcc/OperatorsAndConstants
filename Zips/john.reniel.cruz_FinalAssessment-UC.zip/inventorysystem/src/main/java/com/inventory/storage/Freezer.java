package com.inventory.storage;

public class Freezer extends StorageUnit {

    public Freezer(String label) {
        super(label);
    }

    @Override
    public int getMaxCapacity() {
        return 50;
    }

    @Override
    public double getTemperature() {
        return -18.0;
    }

}