package com.inventory.storage;

public class Shelf extends StorageUnit {

    public Shelf(String label) {
        super(label);
    }

    @Override
    public int getMaxCapacity() {
        return 200;
    }

    @Override
    public double getTemperature() {
        return 22.0;
    }

}