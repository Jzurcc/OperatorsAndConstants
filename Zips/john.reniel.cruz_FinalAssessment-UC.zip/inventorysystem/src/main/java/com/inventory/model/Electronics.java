package com.inventory.model;

public class Electronics extends Product implements Discountable {

    private int warrantyMonths;

    public Electronics(String name, double price, int qty, int warrantyMonths) {
        super(name, price, qty);
        setWarrantyMonths(warrantyMonths);
    }

    public final void setWarrantyMonths(int warrantyMonths) {
        if (warrantyMonths < 0) {
            throw new IllegalArgumentException("Warranty months cannot be less than 0");
        }

        this.warrantyMonths = warrantyMonths;
    }

    public int getWarrantyMonths() {
        return warrantyMonths;
    }

    @Override
    public String toString() {
        return super.toString() + String.format("  [Warranty: %d mo]", warrantyMonths);
    }

    @Override
    public double applyDiscount(double percentage) {
        if (percentage > 50 || percentage < 0) {
            throw new IllegalArgumentException("Percentage must be between 0 and 50");
        }

        setPrice(getPrice() - (getPrice() * (percentage / 100)));
        return getPrice();
    }
}
