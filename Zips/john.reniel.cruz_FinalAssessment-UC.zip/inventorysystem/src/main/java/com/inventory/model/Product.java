package com.inventory.model;

public class Product {

    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        setName(name);
        setPrice(price);
        setQuantity(quantity);
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public final void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be null or blank");
        }

        this.name = name;
    }

    public final void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be less than 0");
        }

        this.price = price;
    }

    public final void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be less than 0");
        }

        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return String.format("%-20s $%7.2f  qty: %d", name, price, quantity);
    }
}
