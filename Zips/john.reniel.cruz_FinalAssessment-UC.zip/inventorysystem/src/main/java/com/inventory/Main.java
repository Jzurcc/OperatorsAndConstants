package com.inventory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.inventory.model.Electronics;
import com.inventory.model.Grocery;
import com.inventory.model.Product;
import com.inventory.model.Receipt;
import com.inventory.service.DiscountProcessor;
import com.inventory.service.Inventory;
import com.inventory.service.InventoryUtils;
import com.inventory.service.OrderProcessor;
import com.inventory.storage.Freezer;
import com.inventory.storage.Shelf;
import com.inventory.storage.StorageUnit;

public class Main {

    public static void main(String[] args) throws Exception {

        System.out.println("=== INVENTORY MANAGEMENT SYSTEM ===");

        // ─── ENCAPSULATION ───
        System.out.println("\n--- Encapsulation ---");

        // TODO A: Create a Product("Mechanical Keyboard", 89.99, 25)
        //   Print: System.out.println("Created: " + product);
        Product keyboard = new Product("Mechanical Keyboard", 89.99, 25);
        System.out.println("Created: " + keyboard);
        // TODO B: Try creating a Product with a blank name ""
        //   Wrap in try-catch, then print:
        //     "Blocked blank name: " + e.getMessage()
        try {
            Product blank = new Product("", 89.99, 25);
            System.out.println(blank.getName());
        } catch (Exception e) {
            System.out.println("Blocked blank name: " + e.getMessage());
        }
        // TODO C: Create a Receipt from a list containing ONE item.
        //   AFTER constructing the receipt, add another item to the ORIGINAL list.
        //   Print: "Receipt items (should be 1): " + receipt.getItems().size()
        //   (If the defensive copy works, the receipt still holds 1 item.)
        List<String> originalList = new ArrayList<>();
        originalList.add("LAPTOP");
        Receipt receipt = new Receipt(originalList, 89.99);
        originalList.add("FAKE-LAPTOP");
        System.out.println("Receipt items (should be 1): " + receipt.getItems().size());

        // ─── INHERITANCE ───
        System.out.println("\n--- Inheritance ---");

        // TODO D: Create three items — keep the variables, you'll need them later:
        Electronics laptop = new Electronics("Gaming Laptop", 1299.99, 10, 24);
        Grocery milk = new Grocery("Organic Milk", 5.49, 100, LocalDate.now().plusDays(7));
        Grocery bread = new Grocery("Stale Bread", 2.99, 5, LocalDate.now().minusDays(3));
        System.out.println(laptop);
        System.out.println("Is old bread expired? " + bread.isExpired());

        // ─── POLYMORPHISM ───
        System.out.println("\n--- Polymorphism ---");

        // TODO E: Create an Electronics("Smartphone", 699.99, 50, 12)
        //   Put the laptop, smartphone, and milk into a List<Product>
        //   int n = DiscountProcessor.applyToEligible(list, 15.0);
        //   Print: "Discounted " + n + " items (Electronics only)"
        Electronics smartphone = new Electronics("Smartphone", 699.99, 50, 12);
        List<Product> list = List.of(laptop, smartphone, milk);
        int n = DiscountProcessor.applyToEligible(list, 15.0);
        System.out.println("Discounted " + n + " Items (Electronics only)");

        // ─── ABSTRACTION ───
        System.out.println("\n--- Abstraction ---");

        // TODO F: Create a Freezer("Freezer-A1") and a Shelf("Shelf-B3")
        //   For each unit, print:
        //     unit.getLabel() + " — cap: " + unit.getMaxCapacity()
        //       + ", temp: " + unit.getTemperature() + "C"
        Freezer freezer = new Freezer("Freezer-A1");
        Shelf shelf = new Shelf("Shelf-B3");

        for (StorageUnit unit : List.of(freezer, shelf)) {
            System.out.println(unit.getLabel() + " - cap: " + unit.getMaxCapacity() + ", temp: " + unit.getTemperature() + "C");
        }

        // ─── COLLECTIONS ───
        System.out.println("\n--- Collections ---");

        // TODO G: Create an Inventory and add at least 4 products with SKUs.
        //   Print: "Inventory size: " + inventory.size()
        //   Get inventory.getAllProducts() as a List<Product>.
        //   Call InventoryUtils.sortByPrice(list).
        //   Print: "Sorted by price: (ascending)"
        //     then print each product on its own line.
        //   (Total value & unique names are exercised in the tests.)
        Inventory inventory = new Inventory();
        inventory.addProduct("PRODUCT-1", new Product("iPhone 17 Pro Max", 57000.0, 1));
        inventory.addProduct("PRODUCT-2", new Product("Nokia 2210", 699.99, 3));
        inventory.addProduct("PRODUCT-3", new Product("Mystery Box", 250.0, 10));
        inventory.addProduct("PRODUCT-4", new Electronics("Downloadable RAM", 2200.0, 8, 12));
        System.out.println("Inventory size: " + inventory.size());
        List<Product> inventoryList = new ArrayList<>(inventory.getAllProducts());
        InventoryUtils.sortByPrice(inventoryList);
        System.out.println("Sorted by price: (ascending)");
        inventoryList.forEach(System.out::println);

        // ─── ERROR HANDLING ───
        System.out.println("\n--- Error Handling ---");
        OrderProcessor processor = new OrderProcessor(inventory);
        Receipt r1 = processor.processOrder("PRODUCT-1", 1);
        System.out.println((r1 != null) ? "Order 1: SUCCESS" : "Order 1: FAILED");
        Receipt r2 = processor.processOrder("PRODUCT-1", 25);
        System.out.println((r2 != null) ? "Order 2: SUCCESS" : "Order 2: FAILED - out of stock");
        Receipt r3 = processor.processOrder("FAKE-SKU", 1);
        System.out.println((r3 != null) ? "Order 3: SUCCESS" : "Order 3: FAILED - SKU not found");
        for (String entry : processor.getLog()) {
            System.out.println("  " + entry);
        }

        // TODO H: Create an OrderProcessor with your inventory.
        //   Order 1 — valid SKU, reasonable qty:
        //     Print: (r1 != null) ? "Order 1: SUCCESS" : "Order 1: FAILED"
        //   Order 2 — request more than available stock:
        //     Print: (r2 == null) ? "Order 2: FAILED — out of stock" : "Order 2: SUCCESS"
        //   Order 3 — fake/invalid SKU:
        //     Print: (r3 == null) ? "Order 3: FAILED — SKU not found" : "Order 3: SUCCESS"
        //   Print: "Order log (" + processor.getLog().size() + " entries):"
        //   Then print each entry, e.g.:
        //     for (String entry : processor.getLog()) System.out.println("  " + entry);
        System.out.println("\n=== ALL SYSTEMS OPERATIONAL ===");
    }
}
