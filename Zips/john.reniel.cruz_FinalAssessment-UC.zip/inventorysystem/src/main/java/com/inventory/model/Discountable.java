package com.inventory.model;

public interface Discountable {
    double applyDiscount(double percentage);
}
