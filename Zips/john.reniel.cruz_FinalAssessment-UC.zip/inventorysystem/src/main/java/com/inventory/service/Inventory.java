package com.inventory.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.inventory.exception.DuplicateSkuException;
import com.inventory.model.Product;

public class Inventory {

    private final Map<String, Product> catalog = new HashMap<>();

    public void addProduct(String sku, Product p) throws DuplicateSkuException {
        if (catalog.containsKey(sku)) {
            throw new DuplicateSkuException(sku);
        }

        catalog.put(sku, p);
    }

    public Product getProduct(String sku) {
        return catalog.get(sku); // returns null if not found
    }

    public Product removeProduct(String sku) {
        return catalog.remove(sku);
    }

    public double getTotalValue() {
        return catalog.values()
                .stream()
                .mapToDouble(p -> p.getPrice() * p.getQuantity())
                .sum();
    }

    public int size() {
        return catalog.size();
    }

    public Collection<Product> getAllProducts() {
        return catalog.values();
    }
}
