package com.inventory.model;

import java.util.*;

public final class Receipt {

    private final List<String> items;
    private final double total;

    public Receipt(List<String> items, double total) {
        this.items = new ArrayList<>(items);
        this.total = total;
    }

    public List<String> getItems() {
        return Collections.unmodifiableList(items);
    }

    public double getTotal() {
        return total;
    }
}