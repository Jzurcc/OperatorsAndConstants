package com.inventory.exception;

public class OutOfStockException extends InventoryException {
    public OutOfStockException(String productName, int requested) {
        super(String.format("Out of stock: cannot fulfill %d units of %s", requested, productName));
    }
}
