package com.inventory.storage;

import java.util.ArrayList;
import java.util.List;

import com.inventory.model.Product;

public abstract class StorageUnit {

    private final String label;
    protected List<Product> products = new ArrayList<>();

    public StorageUnit(String label) {
        this.label = label;
    }

    public abstract int getMaxCapacity();

    public abstract double getTemperature();

    public boolean addProduct(Product p) {
        if (products.size() >= getMaxCapacity()) {
            return false;
        }
        return products.add(p);
    }

    public String getLabel() {
        return label;
    }

    public List<Product> getProducts() {
        return products;
    }
}
