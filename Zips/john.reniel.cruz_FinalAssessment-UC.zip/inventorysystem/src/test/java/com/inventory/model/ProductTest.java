package com.inventory.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class ProductTest {

    Product p = new Product("Keyboard", 49.99, 10);

    @Test
    void testValidProductCreation() {
        assertEquals("Keyboard", p.getName());
        assertEquals(49.99, p.getPrice(), 0.001);
        assertEquals(10, p.getQuantity());
    }

    @Test
    void testNegativePriceThrowsException() {
        assertNotNull(assertThrows(IllegalArgumentException.class, () -> p.setPrice(-500.0)));
    }

    @Test
    void testBlankNameThrowsException() {
        assertNotNull(assertThrows(IllegalArgumentException.class, () -> p.setName(null)));
        assertNotNull(assertThrows(IllegalArgumentException.class, () -> p.setName("")));
    }

    @Test
    void testSetPriceUpdatesValue() {
        double setValue = 500.0;
        p.setPrice(setValue);
        assertEquals(setValue, p.getPrice(), 0.001);
    }
}
