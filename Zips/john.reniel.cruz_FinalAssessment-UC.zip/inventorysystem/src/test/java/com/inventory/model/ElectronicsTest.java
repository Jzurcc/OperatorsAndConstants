package com.inventory.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class ElectronicsTest {

    @Test
    void testElectronicsIsProduct() {
        Electronics e = new Electronics("Monitor", 299.99, 5, 24);
        assertInstanceOf(Product.class, e);
        assertEquals(24, e.getWarrantyMonths());
    }

    @Test
    void testApplyDiscountCalculation() {
        Electronics e = new Electronics("Monitor", 100.00, 0, 0);
        e.applyDiscount(20);
        assertEquals(80.0, e.getPrice(), 0.001);
    }

    @Test
    void testDiscountOverFiftyThrows() {
        Electronics e = new Electronics("Monitor", 100.00, 0, 0);
        assertNotNull(assertThrows(IllegalArgumentException.class, () -> e.applyDiscount(51)));
    }
}
