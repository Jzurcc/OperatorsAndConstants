package com.inventory.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.inventory.model.Electronics;
import com.inventory.model.Grocery;
import com.inventory.model.Receipt;

public class OrderProcessorTest {

    private Inventory inventory;
    private OrderProcessor processor;

    @BeforeEach
    @SuppressWarnings("unused")
    void setUp() throws Exception {
        inventory = new Inventory();
        inventory.addProduct("LAPTOP-01",
                new Electronics("Laptop", 999.99, 10, 24));
        inventory.addProduct("BREAD-01",
                new Grocery("Bread", 3.49, 50,
                        java.time.LocalDate.now().plusDays(7)));
        processor = new OrderProcessor(inventory);
    }

    @Test
    void testSuccessfulOrder() {
        assertNotNull(processor.processOrder("LAPTOP-01", 2));
        assertEquals(8, inventory.getProduct("LAPTOP-01").getQuantity());
    }

    @Test
    void testInvalidSkuReturnsNull() {
        assertNull(processor.processOrder("FAKE-SKU", 1));
    }

    @Test
    void testOutOfStockReturnsNull() {
        assertNull(processor.processOrder("LAPTOP-01", 999));
        assertEquals(10, inventory.getProduct("LAPTOP-01").getQuantity());
    }

    @Test
    void testLogAlwaysRecordsAttempt() {
        processor.processOrder("LAPTOP-01", 2);
        processor.processOrder("FAKE-SKU", 2);
        assertEquals(2, processor.getLog().size());
        assertTrue(processor.getLog().get(0).contains("LAPTOP-01"));
        assertTrue(processor.getLog().get(1).contains("FAKE-SKU"));
    }

    @Test
    void testReceiptIsImmutable() {
        assertNotNull(assertThrows(UnsupportedOperationException.class, () -> processor.processOrder("LAPTOP-01", 2).getItems().add("FAKE RECEIPT")));
    }

    @Test
    void testEdgeCase_ApplyDiscountBeforeOrdering() {
        // 1. Grab the laptop from inventory and cast it to Electronics
        Electronics laptop = (Electronics) inventory.getProduct("LAPTOP-01");

        // 2. Apply a 20% discount (Drops price from $999.99 to $799.992)
        laptop.applyDiscount(20);

        // 3. Process the order for 1 laptop
        Receipt receipt = processor.processOrder("LAPTOP-01", 1);

        // 4. Assert that the receipt automatically used the new discounted price!
        assertEquals(799.992, receipt.getTotal(), 0.001);
    }

}
