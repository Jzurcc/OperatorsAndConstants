package com.inventory.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.inventory.exception.DuplicateSkuException;
import com.inventory.model.Product;

public class InventoryTest {

    private Inventory inventory;
    Product p = new Product("Product", 100, 1);

    @BeforeEach
    @SuppressWarnings("unused")
    void setUp() {
        inventory = new Inventory();
    }

    @Test
    void testAddAndRetrieveProduct() throws Exception {
        inventory.addProduct("A001", p);
        assertNotNull(inventory.getProduct("A001"));
        assertEquals(1, inventory.size());
    }

    @Test
    void testDuplicateSkuThrows() throws Exception {
        assertNotNull(assertThrows(DuplicateSkuException.class, () -> {
            inventory.addProduct("A001", p);
            inventory.addProduct("A001", p);
        }));
    }

    @Test
    void testGetTotalValue() throws Exception {
        inventory.addProduct("1", new Product("A", 10.0, 5));
        assertEquals(50, inventory.getTotalValue(), 0.001);
        inventory.addProduct("2", new Product("B", 20.0, 3));
        assertEquals(110, inventory.getTotalValue(), 0.001);
    }
}
