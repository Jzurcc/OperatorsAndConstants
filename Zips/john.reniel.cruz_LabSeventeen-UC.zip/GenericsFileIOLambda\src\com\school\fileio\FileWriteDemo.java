package com.school.fileio;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileWriteDemo {
    public static void main(String[] args) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("output.txt"))) {
            writer.println("Name: Alice Santos");
            writer.println("Age: 25");
            writer.println("Course: BSIT");
            writer.println("GPA: 3.8");
            writer.println("Status: Active");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
        System.out.println("File \"output.txt\" created successfully.");

        try (PrintWriter appendWriter = new PrintWriter(new FileWriter("output.txt", true))) {
            appendWriter.println("Date: 2025-01-15");
        } catch (IOException e) {
            System.err.println("Error appending to file: " + e.getMessage());
        }
        System.out.println("Line appended to \"output.txt\".");
        System.out.println("Done.");
    }
}
