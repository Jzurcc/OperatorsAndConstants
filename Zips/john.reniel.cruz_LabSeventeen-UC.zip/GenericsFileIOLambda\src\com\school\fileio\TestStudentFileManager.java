package com.school.fileio;

public class TestStudentFileManager {
    public static void main(String[] args) {
        String[] names = {"Alice", "Bob", "Charlie", "Diana", "Edward"};
        double[] grades = {88.5, 62.0, 91.0, 74.5, 95.5};

        System.out.println("--- Writing students to students.csv ---");
        StudentFileManager.writeStudents("students.csv", names, grades);
        System.out.println("Written 5 students to students.csv");
        System.out.println();

        System.out.println("--- Reading students from students.csv ---");
        StudentFileManager.readAndDisplayStudents("students.csv");
        System.out.println();

        System.out.println("--- Writing report to report.txt ---");
        String reportContent = "Class average: 82.3\nPassed: 3 | Failed: 2\n";
        StudentFileManager.writeReport("report.txt", reportContent);
        System.out.println("Report saved to report.txt");
    }
}
