package com.school.lambda;

@FunctionalInterface
interface StringProcessor {
    String process(String input);
}

@FunctionalInterface
interface MathOperation {
    double operate(double a, double b);
}

@FunctionalInterface
interface Validator<T> {
    boolean validate(T input);
}

public class CustomFunctional {
    // Empty class, logic goes to TestCustomFunctional
}
