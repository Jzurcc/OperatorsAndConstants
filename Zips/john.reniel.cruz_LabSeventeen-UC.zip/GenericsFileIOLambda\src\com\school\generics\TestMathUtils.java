package com.school.generics;

import java.util.Arrays;

public class TestMathUtils {
    public static void main(String[] args) {
        System.out.println("--- Bounded Number methods ---");
        System.out.printf("sum(10, 20) = %s%n", MathUtils.sum(10, 20));
        System.out.printf("sum(3.14, 2.86) = %s%n", MathUtils.sum(3.14, 2.86));
        System.out.println();

        System.out.println("--- Bounded Comparable methods ---");
        System.out.printf("findMax(10, 20) = %s%n", MathUtils.findMax(10, 20));
        System.out.printf("findMax(3.14, 2.86) = %s%n", MathUtils.findMax(3.14, 2.86));
        System.out.printf("findMax(\"Apple\", \"Banana\") = %s%n", MathUtils.findMax("Apple", "Banana"));
        System.out.printf("findMin(\"Apple\", \"Banana\") = %s%n", MathUtils.findMin("Apple", "Banana"));
        System.out.println();

        System.out.println("--- Average of List ---");
        java.util.List<Integer> intList = Arrays.asList(10, 20, 30, 40, 50);
        System.out.printf("Integer list %s \u2192 average: %s%n", intList, MathUtils.average(intList));
        java.util.List<Double> doubleList = Arrays.asList(3.5, 4.0, 2.5);
        System.out.printf("Double list %s \u2192 average: %s%n", doubleList, String.format("%.2f", MathUtils.average(doubleList)));
    }
}
