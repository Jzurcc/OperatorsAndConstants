package com.school.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LambdaBasics {
    public static void main(String[] args) {
        System.out.println("--- Sort by length ---");
        List<String> fruits = Arrays.asList("Banana", "Fig", "Apple", "Kiwi", "Elderberry");
        System.out.printf("Before: %s%n", fruits);
        Collections.sort(fruits, (a, b) -> Integer.compare(a.length(), b.length()));
        System.out.printf("After: %s%n", fruits);
        System.out.println();

        System.out.println("--- Sort descending ---");
        List<Integer> nums = Arrays.asList(5, 2, 8, 1, 9, 3);
        System.out.printf("Before: %s%n", nums);
        Collections.sort(nums, (a, b) -> b.compareTo(a));
        System.out.printf("After: %s%n", nums);
        System.out.println();

        System.out.println("--- forEach ---");
        List<String> list = Arrays.asList("Mango", "Apple", "Cherry");
        list.forEach(item -> System.out.printf("- %s%n", item));
        System.out.println();

        System.out.println("--- removeIf (length < 4) ---");
        List<String> words = new ArrayList<>(Arrays.asList("Hi", "Hello", "OK", "World", "Go"));
        System.out.printf("Before: %s%n", words);
        words.removeIf(s -> s.length() < 4);
        System.out.printf("After: %s%n", words);
        System.out.println();

        System.out.println("--- Runnable lambda ---");
        Runnable r = () -> System.out.println("Running from a lambda!");
        r.run();
    }
}
