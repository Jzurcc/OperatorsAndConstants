package com.school.generics;

import java.util.List;

public class MathUtils {
    public static <T extends Number> double sum(T a, T b) {
        return a.doubleValue() + b.doubleValue();
    }

    public static <T extends Comparable<T>> T findMax(T a, T b) {
        return (a.compareTo(b) >= 0) ? a : b;
    }

    public static <T extends Comparable<T>> T findMin(T a, T b) {
        return (a.compareTo(b) <= 0) ? a : b;
    }

    public static <T extends Number> double average(List<T> list) {
        if (list == null || list.isEmpty()) return 0;
        double sum = 0;
        for (T num : list) {
            sum += num.doubleValue();
        }
        return sum / list.size();
    }
}
