package com.school.lambda;

public class TestCustomFunctional {
    public static String applyProcessor(String input, StringProcessor processor) {
        return processor.process(input);
    }

    public static void main(String[] args) {
        System.out.println("--- StringProcessor ---");
        StringProcessor toUpper = s -> s.toUpperCase();
        StringProcessor reverse = s -> new StringBuilder(s).reverse().toString();
        StringProcessor addExclamation = s -> s + "!";
        
        System.out.printf("toUpper: %s%n", toUpper.process("Hello World"));
        System.out.printf("reverse: %s%n", reverse.process("Hello World"));
        System.out.printf("addExclamation: %s%n", addExclamation.process("Hello World"));
        
        StringProcessor stars = s -> "***" + s + "***";
        System.out.printf("applyProcessor: %s%n", applyProcessor("Hello World", stars));
        System.out.println();

        System.out.println("--- MathOperation ---");
        MathOperation add = (a, b) -> a + b;
        MathOperation subtract = (a, b) -> a - b;
        MathOperation multiply = (a, b) -> a * b;
        MathOperation power = Math::pow;
        
        System.out.printf("add(10, 5): %s%n", add.operate(10, 5));
        System.out.printf("subtract(10, 5): %s%n", subtract.operate(10, 5));
        System.out.printf("multiply(10, 5): %s%n", multiply.operate(10, 5));
        System.out.printf("power(2, 8): %s%n", power.operate(2, 8));
        System.out.println();

        System.out.println("--- Generic Validator ---");
        Validator<Integer> isPositive = n -> n > 0;
        Validator<String> isValidEmail = s -> s.contains("@");
        
        System.out.printf("isPositive(10): %s%n", isPositive.validate(10));
        System.out.printf("isPositive(-5): %s%n", isPositive.validate(-5));
        System.out.printf("isValidEmail(\"alice@email.com\"): %s%n", isValidEmail.validate("alice@email.com"));
        System.out.printf("isValidEmail(\"not-an-email\"): %s%n", isValidEmail.validate("not-an-email"));
    }
}
