package com.school.lambda;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class BuiltInFunctions {
    public static void main(String[] args) {
        System.out.println("--- Predicate ---");
        Predicate<Integer> isEven = n -> n % 2 == 0;
        Predicate<String> isLong = s -> s.length() > 5;
        
        System.out.printf("isEven.test(4): %s%n", isEven.test(4));
        System.out.printf("isEven.test(7): %s%n", isEven.test(7));
        
        Predicate<Integer> greaterThan10 = n -> n > 10;
        System.out.printf("isEven.and(n > 10).test(12): %s%n", isEven.and(greaterThan10).test(12));
        System.out.printf("isEven.or(n > 10).test(11): %s%n", isEven.or(greaterThan10).test(11));
        System.out.printf("isEven.negate().test(7): %s%n", isEven.negate().test(7));
        System.out.println();

        System.out.println("--- Function ---");
        Function<String, Integer> toLength = s -> s.length();
        Function<Integer, String> toLabel = n -> "Score: " + n;
        
        System.out.printf("toLength.apply(\"Hello\"): %s%n", toLength.apply("Hello"));
        System.out.printf("toLabel.apply(95): %s%n", toLabel.apply(95));
        System.out.printf("toLength.andThen(toLabel).apply(\"Hello\"): %s%n", toLength.andThen(toLabel).apply("Hello"));
        System.out.println();

        System.out.println("--- Consumer ---");
        Consumer<String> shout = s -> System.out.printf("%s!%n", s.toUpperCase());
        System.out.print("shout.accept(\"hello\"): ");
        shout.accept("hello");
        System.out.println();

        System.out.println("--- Supplier ---");
        Supplier<Double> randomScore = () -> Math.round(Math.random() * 100.0) / 1.0;
        System.out.printf("randomScore.get(): %s%n", randomScore.get());
        System.out.printf("randomScore.get(): %s%n", randomScore.get());
    }
}
