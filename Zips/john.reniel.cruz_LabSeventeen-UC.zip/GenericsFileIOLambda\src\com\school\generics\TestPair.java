package com.school.generics;

public class TestPair {
    public static <A, B> Pair<B, A> swap(Pair<A, B> pair) {
        return new Pair<>(pair.getValue(), pair.getKey());
    }

    public static void main(String[] args) {
        System.out.println("--- Student ID + Name ---");
        Pair<Integer, String> student = new Pair<>(20240001, "Alice Santos");
        System.out.println(student);
        System.out.println();

        System.out.println("--- Product + Price ---");
        Pair<String, Double> product = new Pair<>("Laptop", 45999.0);
        System.out.println(product);
        System.out.println();

        System.out.println("--- Coordinate ---");
        Pair<Integer, Integer> coord = new Pair<>(10, 20);
        System.out.println(coord);
        System.out.println();

        System.out.println("--- Swapping values ---");
        Pair<String, String> pair = new Pair<>("Hello", "World");
        System.out.printf("Before: %s%n", pair);
        Pair<String, String> swapped = swap(pair);
        System.out.printf("After swap: key=%s, value=%s%n", swapped.getKey(), swapped.getValue());
    }
}
