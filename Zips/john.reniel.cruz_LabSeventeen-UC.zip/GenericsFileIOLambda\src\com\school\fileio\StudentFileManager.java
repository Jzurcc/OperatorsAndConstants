package com.school.fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class StudentFileManager {
    public static void writeStudents(String filename, String[] names, double[] grades) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (int i = 0; i < names.length; i++) {
                writer.println(names[i] + "," + grades[i]);
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    public static void readAndDisplayStudents(String filename) {
        int passed = 0;
        int failed = 0;
        double sum = 0;
        int count = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    count++;
                    String name = parts[0];
                    double grade = Double.parseDouble(parts[1]);
                    sum += grade;
                    String status = grade >= 75.0 ? "Passed" : "Failed";
                    if (status.equals("Passed")) passed++;
                    else failed++;
                    
                    System.out.printf("%d. %-12s %-6.1f %s%n", count, name, grade, status);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        System.out.println();
        System.out.printf("Class average: %.1f%n", (count > 0 ? sum / count : 0));
        System.out.printf("Passed: %s | Failed: %s%n", passed, failed);
    }

    public static void writeReport(String filename, String reportContent) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.print(reportContent);
        } catch (IOException e) {
            System.err.println("Error writing report: " + e.getMessage());
        }
    }
}
