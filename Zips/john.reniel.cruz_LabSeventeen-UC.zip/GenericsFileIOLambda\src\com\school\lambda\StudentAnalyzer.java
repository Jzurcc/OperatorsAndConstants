package com.school.lambda;

import com.school.generics.Pair;
import java.io.*;
import java.util.*;
import java.util.function.*;

public class StudentAnalyzer {
    public static void main(String[] args) {
        String dataFile = "students_data.csv";
        String reportFile = "analysis_report.txt";

        // Write data file
        try (PrintWriter writer = new PrintWriter(new FileWriter(dataFile))) {
            writer.println("Alice,88.5");
            writer.println("Bob,62.0");
            writer.println("Charlie,91.0");
            writer.println("Diana,74.5");
            writer.println("Edward,95.5");
            writer.println("Fiona,55.0");
            writer.println("George,82.0");
            writer.println("Hannah,98.0");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Read and parse
        List<Pair<String, Double>> students = new ArrayList<>();
        System.out.printf("--- Reading %s ---%n", dataFile);
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    students.add(new Pair<>(parts[0], Double.parseDouble(parts[1])));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.printf("Loaded %s students.\n%n", students.size());

        // Process with lambdas
        Predicate<Pair<String, Double>> passed = p -> p.getValue() >= 75.0;
        Predicate<Pair<String, Double>> failed = p -> p.getValue() < 75.0;
        
        // Count passes and fails
        long passCount = 0;
        long failCount = 0;
        double sum = 0;
        double highest = -1;
        String highestStudent = "";
        double lowest = 1000;
        String lowestStudent = "";

        for (Pair<String, Double> p : students) {
            double grade = p.getValue();
            sum += grade;
            if (passed.test(p)) passCount++;
            if (failed.test(p)) failCount++;
            
            if (grade > highest) {
                highest = grade;
                highestStudent = p.getKey();
            }
            if (grade < lowest) {
                lowest = grade;
                lowestStudent = p.getKey();
            }
        }

        double average = sum / students.size();

        // Sort descending
        students.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        Function<Pair<String, Double>, String> formatReportLine = p -> {
            String mark = passed.test(p) ? "\u2605 Passed" : "\u2717 Failed";
            return String.format("%-13s %-6.1f %s", p.getKey(), p.getValue(), mark);
        };

        // We use a StringBuilder to build the report and also print to console using Consumer
        StringBuilder reportBuilder = new StringBuilder();
        reportBuilder.append("--- All students (sorted by grade, descending) ---\n");
        System.out.println("--- All students (sorted by grade, descending) ---");
        
        int[] index = {1};
        Consumer<Pair<String, Double>> printStudent = p -> {
            String line = index[0] + ". " + formatReportLine.apply(p);
            System.out.println(line);
            reportBuilder.append(line).append("\n");
            index[0]++;
        };

        students.forEach(printStudent);
        System.out.println();
        reportBuilder.append("\n");

        String summary = String.format("--- Summary ---\n" +
                "Total students: %d\n" +
                "Passed: %d\n" +
                "Failed: %d\n" +
                "Highest: %s (%.1f)\n" +
                "Lowest: %s (%.1f)\n" +
                "Average: %.2f\n", 
                students.size(), passCount, failCount, highestStudent, highest, lowestStudent, lowest, average);
                
        System.out.println(summary);
        reportBuilder.append(summary);

        try (PrintWriter writer = new PrintWriter(new FileWriter(reportFile))) {
            writer.print(reportBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.printf("Report written to %s%n", reportFile);
    }
}
