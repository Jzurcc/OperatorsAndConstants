package com.school.generics;

public class TestBox {
    public static void main(String[] args) {
        System.out.println("--- String Box ---");
        Box<String> stringBox = new Box<>("Hello World");
        System.out.println(stringBox);
        System.out.printf("Content: %s%n", stringBox.getContent());
        System.out.printf("Empty: %s%n", stringBox.isEmpty());
        System.out.println();

        System.out.println("--- Integer Box ---");
        Box<Integer> intBox = new Box<>(42);
        System.out.println(intBox);
        System.out.printf("Content: %s%n", intBox.getContent());
        System.out.println();

        System.out.println("--- Double Box ---");
        Box<Double> doubleBox = new Box<>(3.14);
        System.out.println(doubleBox);
        System.out.printf("Content: %s%n", doubleBox.getContent());
        System.out.println();

        System.out.println("--- Empty Box ---");
        Box<String> emptyBox = new Box<>(null);
        System.out.println(emptyBox);
        System.out.printf("Empty: %s%n", emptyBox.isEmpty());
    }
}
