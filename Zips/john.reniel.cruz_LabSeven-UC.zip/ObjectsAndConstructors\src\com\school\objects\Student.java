package com.school.objects;

public class Student {
    String name;
    int studentId;
    String course;
    double gpa;

    public Student(String name, int studentId, String course, double gpa) {
        this.name = name;
        this.studentId = studentId;
        this.course = course;
        this.gpa = gpa;
    }

    public void displayInfo() {
        System.out.printf("Name: %s%n", name);
        System.out.printf("ID: %s%n", studentId);
        System.out.printf("Course: %s%n", course);
        System.out.printf("GPA: %s%n", gpa);
    }
}
