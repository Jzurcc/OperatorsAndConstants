package com.school.objects;

public class TestMovie {
    public static void main(String[] args) {
        Movie m1 = new Movie("Inception", "Sci-Fi", 148, 8.8);
        System.out.println("--- Movie 1 ---");
        m1.displayInfo();
        System.out.println();

        Movie m2 = new Movie("The Room", "Drama", 99, 3.6);
        System.out.println("--- Movie 2 ---");
        m2.displayInfo();
    }
}
