package com.school.objects;

public class BankAccount {
    String owner;
    String accountNumber;
    double balance;

    public BankAccount(String owner, String accountNumber, double balance) {
        this.owner = owner;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.printf("Deposit: %s%n", amount);
        } else {
            System.out.println("Error: Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.printf("Withdraw: %s%n", amount);
        } else if (amount > balance) {
            System.out.println("Error: Insufficient funds.");
        } else {
            System.out.println("Error: Withdrawal amount must be positive.");
        }
    }

    public void displayBalance() {
        System.out.printf("Balance: %s%n", balance);
    }
}
