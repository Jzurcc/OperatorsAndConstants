package com.school.objects;

public class Car {
    String brand;
    String model;
    int year;
    String color;

    public void displayInfo() {
        System.out.printf("Brand: %s%n", brand);
        System.out.printf("Model: %s%n", model);
        System.out.printf("Year: %s%n", year);
        System.out.printf("Color: %s%n", color);
    }
}
