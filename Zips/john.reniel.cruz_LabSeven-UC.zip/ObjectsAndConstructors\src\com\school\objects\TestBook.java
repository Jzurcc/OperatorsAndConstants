package com.school.objects;

public class TestBook {
    public static void main(String[] args) {
        Book book = new Book();
        System.out.println("--- Default Book ---");
        book.displayInfo();
        System.out.println();

        book.title = "Noli Me Tangere";
        book.author = "Jose Rizal";
        book.price = 350.0;
        System.out.println("--- After updating ---");
        book.displayInfo();
    }
}
