package com.school.objects;

public class TestCircle {
    public static void main(String[] args) {
        Circle c1 = new Circle(5.0);
        System.out.println("--- Circle 1 ---");
        c1.displayInfo();
        System.out.println();

        Circle c2 = new Circle(12.5);
        System.out.println("--- Circle 2 ---");
        c2.displayInfo();
    }
}
