package com.school.objects;

public class Classroom {
    static int totalClassrooms = 0;
    int classroomId;
    String teacherName;
    String subject;
    String[] students;
    int studentCount;

    public Classroom(String teacherName, String subject) {
        totalClassrooms++;
        this.classroomId = totalClassrooms;
        this.teacherName = teacherName;
        this.subject = subject;
        this.students = new String[5];
        this.studentCount = 0;
    }

    public void enrollStudent(String name) {
        if (isFull()) {
            System.out.println("Error: Classroom is full.");
        } else {
            students[studentCount] = name;
            studentCount++;
        }
    }

    public boolean isFull() {
        return studentCount == 5;
    }

    public void displayInfo() {
        System.out.println("========================================");
        System.out.printf("  Classroom #%s%n", classroomId);
        System.out.println("========================================");
        System.out.printf("Teacher: %s%n", teacherName);
        System.out.printf("Subject: %s%n", subject);
        System.out.println();
        System.out.println("Enrolled students:");
        for (int i = 0; i < studentCount; i++) {
            System.out.printf("  %s. %s%n", (i + 1), students[i]);
        }
        System.out.printf("Students: %s/5%n", studentCount);
        System.out.printf("Full: %s%n", isFull());
    }
}
