package com.school.objects;

public class TestBankAccount {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Maria Santos", "ACC-1001", 10000.0);
        System.out.printf("Account created for: %s (%s)%n", account.owner, account.accountNumber);
        account.displayBalance();
        System.out.println();

        account.deposit(5000.0);
        account.displayBalance();
        System.out.println();

        account.withdraw(3000.0);
        account.displayBalance();
        System.out.println();

        account.withdraw(20000.0);
        account.displayBalance();
        System.out.println();

        account.deposit(-500.0);
        account.displayBalance();
    }
}
