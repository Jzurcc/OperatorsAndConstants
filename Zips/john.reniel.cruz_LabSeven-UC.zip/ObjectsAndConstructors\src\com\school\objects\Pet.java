package com.school.objects;

public class Pet {
    String name;
    String species;
    int age;
    String owner;

    public Pet(String name, String species, int age, String owner) {
        this.name = name;
        this.species = species;
        this.age = age;
        this.owner = owner;
    }

    public Pet(String name, String species) {
        this(name, species, 0, "No owner");
    }

    public Pet(String name) {
        this(name, "Unknown");
    }

    public void displayInfo() {
        System.out.printf("Name: %s%n", name);
        System.out.printf("Species: %s%n", species);
        System.out.printf("Age: %s%n", age);
        System.out.printf("Owner: %s%n", owner);
    }
}
