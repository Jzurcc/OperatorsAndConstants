package com.school.objects;

public class TestPhone {
    public static void main(String[] args) {
        Phone p1 = new Phone();
        System.out.println("--- Phone 1 (no-arg) ---");
        p1.displayInfo();
        System.out.println();

        Phone p2 = new Phone("Samsung", "Galaxy A15");
        System.out.println("--- Phone 2 (brand + model) ---");
        p2.displayInfo();
        System.out.println();

        Phone p3 = new Phone("Apple", "iPhone 15", 54990.0, 128);
        System.out.println("--- Phone 3 (full) ---");
        p3.displayInfo();
    }
}
