package com.school.objects;

public class Movie {
    String title;
    String genre;
    int durationMinutes;
    double rating;

    public Movie(String title, String genre, int durationMinutes, double rating) {
        this.title = title;
        this.genre = genre;
        this.durationMinutes = durationMinutes;
        this.rating = rating;
    }

    public String getDurationFormatted() {
        int hours = durationMinutes / 60;
        int mins = durationMinutes % 60;
        return hours + "h " + mins + "m";
    }

    public String getRatingLabel() {
        if (rating >= 8) return "Excellent";
        else if (rating >= 6) return "Good";
        else if (rating >= 4) return "Average";
        else return "Poor";
    }

    public void displayInfo() {
        System.out.printf("Title: %s%n", title);
        System.out.printf("Genre: %s%n", genre);
        System.out.printf("Duration: %s%n", getDurationFormatted());
        System.out.printf("Rating: %s (%s)%n", rating, getRatingLabel());
    }
}
