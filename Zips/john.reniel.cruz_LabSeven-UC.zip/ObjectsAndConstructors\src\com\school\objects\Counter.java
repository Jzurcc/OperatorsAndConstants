package com.school.objects;

public class Counter {
    static int totalCount = 0;
    int id;
    String label;

    public Counter(String label) {
        totalCount++;
        this.id = totalCount;
        this.label = label;
    }

    public void displayInfo() {
        System.out.printf("Created: %s (ID: %s)%n", label, id);
    }
}
