package com.school.objects;

public class TestCar {
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.brand = "Toyota";
        car1.model = "Vios";
        car1.year = 2023;
        car1.color = "White";

        Car car2 = new Car();
        car2.brand = "Honda";
        car2.model = "Civic";
        car2.year = 2024;
        car2.color = "Black";

        System.out.println("--- Car 1 ---");
        car1.displayInfo();
        System.out.println();
        System.out.println("--- Car 2 ---");
        car2.displayInfo();
    }
}
