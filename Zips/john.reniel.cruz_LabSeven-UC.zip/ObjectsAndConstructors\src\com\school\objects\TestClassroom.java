package com.school.objects;

public class TestClassroom {
    public static void main(String[] args) {
        Classroom room1 = new Classroom("Mr. Garcia", "Java Programming");
        room1.enrollStudent("Alice");
        room1.enrollStudent("Bob");
        room1.enrollStudent("Charlie");
        room1.displayInfo();
        System.out.println();

        Classroom room2 = new Classroom("Ms. Reyes", "Data Structures");
        room2.enrollStudent("Diana");
        room2.enrollStudent("Edward");
        room2.enrollStudent("Fiona");
        room2.enrollStudent("George");
        room2.enrollStudent("Hannah");
        room2.displayInfo();
        System.out.println();

        System.out.println("Attempting to enroll \"Ivan\" in Classroom #2...");
        room2.enrollStudent("Ivan");
        System.out.println();

        System.out.printf("Total classrooms created: %s%n", Classroom.totalClassrooms);
    }
}
