package com.school.objects;

public class TestStudent {
    public static void main(String[] args) {
        Student s1 = new Student("Alice Reyes", 20240001, "BSIT", 3.8);
        Student s2 = new Student("Bob Santos", 20240002, "BSCS", 3.2);
        Student s3 = new Student("Charlie Cruz", 20240003, "BSIT", 2.9);

        System.out.println("--- Student 1 ---");
        s1.displayInfo();
        System.out.println();
        System.out.println("--- Student 2 ---");
        s2.displayInfo();
        System.out.println();
        System.out.println("--- Student 3 ---");
        s3.displayInfo();
    }
}
