package com.school.objects;

public class Circle {
    double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    public double getDiameter() {
        return 2 * radius;
    }

    public void displayInfo() {
        System.out.printf("Radius: %s%n", String.format("%.2f", radius));
        System.out.printf("Diameter: %s%n", String.format("%.2f", getDiameter()));
        System.out.printf("Area: %s%n", String.format("%.2f", getArea()));
        System.out.printf("Circumference: %s%n", String.format("%.2f", getCircumference()));
    }
}
