package com.school.objects;

public class Phone {
    String brand;
    String model;
    double price;
    int storage;

    public Phone() {
        brand = "Generic";
        model = "Basic";
        price = 0.0;
        storage = 32;
    }

    public Phone(String brand, String model) {
        this.brand = brand;
        this.model = model;
        this.price = 0.0;
        this.storage = 64;
    }

    public Phone(String brand, String model, double price, int storage) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.storage = storage;
    }

    public void displayInfo() {
        System.out.printf("Brand: %s%n", brand);
        System.out.printf("Model: %s%n", model);
        System.out.printf("Price: %s%n", price);
        System.out.printf("Storage: %sGB%n", storage);
    }
}
