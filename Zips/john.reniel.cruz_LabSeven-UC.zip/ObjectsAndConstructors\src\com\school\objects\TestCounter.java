package com.school.objects;

public class TestCounter {
    public static void main(String[] args) {
        Counter a = new Counter("Item A");
        Counter b = new Counter("Item B");
        Counter c = new Counter("Item C");
        Counter d = new Counter("Item D");

        a.displayInfo();
        b.displayInfo();
        c.displayInfo();
        d.displayInfo();
        System.out.println();
        System.out.printf("Total objects created: %s%n", Counter.totalCount);
    }
}
