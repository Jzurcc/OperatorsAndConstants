package com.school.objects;

public class TestPet {
    public static void main(String[] args) {
        Pet p1 = new Pet("Bantay", "Dog", 3, "Maria Santos");
        System.out.println("--- Pet 1 (full constructor) ---");
        p1.displayInfo();
        System.out.println();

        Pet p2 = new Pet("Mingming", "Cat");
        System.out.println("--- Pet 2 (name + species) ---");
        p2.displayInfo();
        System.out.println();

        Pet p3 = new Pet("Tweety");
        System.out.println("--- Pet 3 (name only) ---");
        p3.displayInfo();
    }
}
