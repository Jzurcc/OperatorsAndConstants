package com.school.objects;

public class Book {
    String title;
    String author;
    double price;

    public Book() {
        title = "Untitled";
        author = "Unknown";
        price = 0.0;
    }

    public void displayInfo() {
        System.out.printf("Title: %s%n", title);
        System.out.printf("Author: %s%n", author);
        System.out.printf("Price: %s%n", price);
    }
}
