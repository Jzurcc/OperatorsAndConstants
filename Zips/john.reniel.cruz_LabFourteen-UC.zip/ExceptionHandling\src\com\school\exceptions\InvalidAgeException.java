package com.school.exceptions;

public class InvalidAgeException extends Exception {
    int age;

    public InvalidAgeException(int age, String message) {
        super(message);
        this.age = age;
    }

    public int getAge() {
        return age;
    }
}
