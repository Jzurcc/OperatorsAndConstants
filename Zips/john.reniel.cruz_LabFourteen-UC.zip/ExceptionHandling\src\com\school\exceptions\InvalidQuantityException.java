package com.school.exceptions;

public class InvalidQuantityException extends Exception {
    int quantity;

    public InvalidQuantityException(int quantity) {
        super("Quantity must be greater than 0. Got: " + quantity);
        this.quantity = quantity;
    }
}
