package com.school.exceptions;

public class PaymentFailedException extends Exception {
    String reason;

    public PaymentFailedException(String reason) {
        super(reason);
        this.reason = reason;
    }
}
