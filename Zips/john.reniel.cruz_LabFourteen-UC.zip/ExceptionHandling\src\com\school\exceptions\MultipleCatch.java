package com.school.exceptions;

public class MultipleCatch {
    public static void main(String[] args) {
        String[] values = {"10", "abc", "30", null, "50"};

        for (int i = 0; i < values.length; i++) {
            try {
                int num = Integer.parseInt(values[i]);
                int result = 100 / num;
                System.out.printf("Index %s: 100 / %s = %s%n", i, num, result);
            } catch (NumberFormatException e) {
                System.out.printf("Index %s: %s \u2014 %s%n", i, e.getClass().getSimpleName(), e.getMessage());
            } catch (NullPointerException e) {
                System.out.printf("Index %s: %s \u2014 Cannot parse null%n", i, e.getClass().getSimpleName());
            } catch (ArithmeticException e) {
                System.out.printf("Index %s: %s \u2014 %s%n", i, e.getClass().getSimpleName(), e.getMessage());
            } catch (Exception e) {
                System.out.printf("Index %s: %s \u2014 %s%n", i, e.getClass().getSimpleName(), e.getMessage());
            }
        }
    }
}
