package com.school.exceptions;

public class TestOrderProcessor {
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  ORDER PROCESSING SYSTEM");
        System.out.println("========================================");
        System.out.println();

        System.out.println("--- Order 1: Laptop x 2 ---");
        OrderProcessor.placeOrder("Laptop", 2, true);
        System.out.println();

        System.out.println("--- Order 2: Mouse x 0 ---");
        OrderProcessor.placeOrder("Mouse", 0, true);
        System.out.println();

        System.out.println("--- Order 3: Monitor x 1 ---");
        OrderProcessor.placeOrder("Monitor", 1, true);
        System.out.println();

        System.out.println("--- Order 4: Keyboard x 20 ---");
        OrderProcessor.placeOrder("Keyboard", 20, true);
        System.out.println();

        System.out.println("--- Order 5: Mouse x 5 (insufficient funds) ---");
        OrderProcessor.placeOrder("Mouse", 5, false);
        System.out.println();

        System.out.println("========================================");
    }
}
