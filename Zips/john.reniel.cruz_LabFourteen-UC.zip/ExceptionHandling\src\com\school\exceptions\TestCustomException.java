package com.school.exceptions;

public class TestCustomException {
    public static void registerVoter(String name, int age) throws InvalidAgeException {
        if (age < 18 || age > 120) {
            throw new InvalidAgeException(age, "Age " + age + " is not valid for voter registration.");
        }
    }

    public static void main(String[] args) {
        System.out.println("--- Registration 1 ---");
        try {
            System.out.print("Registering Alice (age 25)... ");
            registerVoter("Alice", 25);
            System.out.println("SUCCESS");
        } catch (InvalidAgeException e) {
            System.out.printf("\nInvalidAgeException: %s%n", e.getMessage());
            System.out.printf("Invalid age value: %s%n", e.getAge());
        }
        System.out.println();

        System.out.println("--- Registration 2 ---");
        try {
            System.out.print("Registering Bob (age 15)... ");
            registerVoter("Bob", 15);
            System.out.println("SUCCESS");
        } catch (InvalidAgeException e) {
            System.out.printf("\nInvalidAgeException: %s%n", e.getMessage());
            System.out.printf("Invalid age value: %s%n", e.getAge());
        }
        System.out.println();

        System.out.println("--- Registration 3 ---");
        try {
            System.out.print("Registering Charlie (age -3)... ");
            registerVoter("Charlie", -3);
            System.out.println("SUCCESS");
        } catch (InvalidAgeException e) {
            System.out.printf("\nInvalidAgeException: %s%n", e.getMessage());
            System.out.printf("Invalid age value: %s%n", e.getAge());
        }
    }
}
