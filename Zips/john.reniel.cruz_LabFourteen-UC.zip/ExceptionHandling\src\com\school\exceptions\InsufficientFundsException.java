package com.school.exceptions;

public class InsufficientFundsException extends Exception {
    double balance;
    double amount;

    public InsufficientFundsException(double balance, double amount) {
        super("Cannot withdraw " + amount + ". Balance is only " + balance + ".");
        this.balance = balance;
        this.amount = amount;
    }

    public double getBalance() {
        return balance;
    }

    public double getAmount() {
        return amount;
    }

    public double getShortfall() {
        return amount - balance;
    }
}
