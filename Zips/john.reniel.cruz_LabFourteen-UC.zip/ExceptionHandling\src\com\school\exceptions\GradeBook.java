package com.school.exceptions;

public class GradeBook {
    String[] students;
    double[] grades;

    public GradeBook(String[] students, double[] grades) {
        this.students = students;
        this.grades = grades;
    }

    public double getGrade(String name) throws StudentNotFoundException {
        for (int i = 0; i < students.length; i++) {
            if (students[i].equals(name)) {
                return grades[i];
            }
        }
        throw new StudentNotFoundException(name);
    }

    public void addGrade(String name, double grade) throws StudentNotFoundException, InvalidGradeException {
        if (grade < 0 || grade > 100) {
            throw new InvalidGradeException(grade);
        }
        boolean found = false;
        for (int i = 0; i < students.length; i++) {
            if (students[i].equals(name)) {
                grades[i] = grade;
                found = true;
                break;
            }
        }
        if (!found) {
            throw new StudentNotFoundException(name);
        }
    }
}
