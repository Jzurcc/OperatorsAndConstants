package com.school.exceptions;

public class TestBankAccount {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Alice", 10000.0);
        System.out.printf("Account: %s, Balance: %s%n", account.owner, account.balance);
        System.out.println();

        try {
            System.out.print("Deposit 5000.0... ");
            account.deposit(5000.0);
            System.out.printf("Balance: %s%n", account.balance);
        } catch (IllegalArgumentException e) {
            System.out.printf("\nIllegalArgumentException: %s%n", e.getMessage());
        }

        try {
            System.out.print("Withdraw 3000.0... ");
            account.withdraw(3000.0);
            System.out.printf("Balance: %s%n", account.balance);
        } catch (InsufficientFundsException e) {
            System.out.printf("\nInsufficientFundsException: %s%n", e.getMessage());
            System.out.printf("You are short by: %s%n", e.getShortfall());
        }
        System.out.println();

        try {
            System.out.println("Attempting to withdraw 20000.0...");
            account.withdraw(20000.0);
            System.out.printf("Balance: %s%n", account.balance);
        } catch (InsufficientFundsException e) {
            System.out.printf("InsufficientFundsException: %s%n", e.getMessage());
            System.out.printf("You are short by: %s%n", e.getShortfall());
        }
        System.out.println();

        try {
            System.out.println("Attempting to deposit -500.0...");
            account.deposit(-500.0);
            System.out.printf("Balance: %s%n", account.balance);
        } catch (IllegalArgumentException e) {
            System.out.printf("IllegalArgumentException: %s%n", e.getMessage());
        }
    }
}
