package com.school.exceptions;

public class ThrowKeyword {
    public static void validateAge(int age) {
        if (age < 0 || age > 150) {
            throw new IllegalArgumentException("Invalid age: " + age);
        }
    }

    public static void validateName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty.");
        }
    }

    public static double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return (double) a / b;
    }

    public static void main(String[] args) {
        System.out.println("--- validateAge ---");
        try {
            validateAge(25);
            System.out.println("Age 25: Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Age 25: Caught \u2014 %s%n", e.getMessage());
        }

        try {
            validateAge(-5);
            System.out.println("Age -5: Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Age -5: Caught \u2014 %s%n", e.getMessage());
        }

        try {
            validateAge(200);
            System.out.println("Age 200: Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Age 200: Caught \u2014 %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- validateName ---");
        try {
            validateName("Alice");
            System.out.println("Name \"Alice\": Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Name \"Alice\": Caught \u2014 %s%n", e.getMessage());
        }

        try {
            validateName("");
            System.out.println("Name \"\": Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Name \"\": Caught \u2014 %s%n", e.getMessage());
        }

        try {
            validateName(null);
            System.out.println("Name null: Valid");
        } catch (IllegalArgumentException e) {
            System.out.printf("Name null: Caught \u2014 %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- divide ---");
        try {
            System.out.printf("10 / 3 = %s%n", String.format("%.2f", divide(10, 3)));
        } catch (ArithmeticException e) {
            System.out.printf("10 / 3: Caught \u2014 %s%n", e.getMessage());
        }

        try {
            double res = divide(10, 0);
            System.out.printf("10 / 0 = %s%n", res);
        } catch (ArithmeticException e) {
            System.out.printf("10 / 0: Caught \u2014 %s%n", e.getMessage());
        }
    }
}
