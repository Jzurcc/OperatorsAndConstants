package com.school.exceptions;

public class OrderProcessor {
    static String[] products = {"Laptop", "Mouse", "Keyboard"};
    static int[] stock = {5, 20, 15};
    static double[] prices = {45999.0, 599.0, 1299.0};

    public static void validateQuantity(int qty) throws InvalidQuantityException {
        if (qty <= 0) {
            throw new InvalidQuantityException(qty);
        }
    }

    public static int findProduct(String name) throws IllegalArgumentException {
        for (int i = 0; i < products.length; i++) {
            if (products[i].equals(name)) {
                return i;
            }
        }
        throw new IllegalArgumentException("Product not found: " + name);
    }

    public static void checkStock(int index, int qty) throws OutOfStockException {
        if (qty > stock[index]) {
            throw new OutOfStockException(products[index], qty, stock[index]);
        }
    }

    public static void processPayment(double amount, boolean hasEnoughFunds) throws PaymentFailedException {
        if (!hasEnoughFunds) {
            throw new PaymentFailedException("Insufficient funds.");
        }
    }

    public static void placeOrder(String product, int qty, boolean hasEnoughFunds) {
        try {
            System.out.print("Validating quantity... ");
            validateQuantity(qty);
            System.out.println("OK");

            System.out.print("Finding product... ");
            int index = findProduct(product);
            System.out.printf("Found at index %s%n", index);

            System.out.print("Checking stock... ");
            checkStock(index, qty);
            System.out.printf("%s available, %s requested \u2014 OK%n", stock[index], qty);

            double amount = prices[index] * qty;
            System.out.print("Processing payment of " + amount + "... ");
            processPayment(amount, hasEnoughFunds);
            System.out.println("OK");

            stock[index] -= qty;
            System.out.printf("Order placed! Remaining stock: %s%n", stock[index]);
        } catch (InvalidQuantityException e) {
            System.out.printf("\nInvalidQuantityException: %s%n", e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.printf("\n%s%n", e.getMessage());
        } catch (OutOfStockException e) {
            System.out.printf("\nOutOfStockException: %s%n", e.getMessage());
        } catch (PaymentFailedException e) {
            System.out.printf("\nPaymentFailedException: %s%n", e.getMessage());
        } finally {
            System.out.println("[finally] Order processing complete.");
        }
    }
}
