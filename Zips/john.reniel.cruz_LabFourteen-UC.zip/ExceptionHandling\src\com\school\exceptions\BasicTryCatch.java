package com.school.exceptions;

public class BasicTryCatch {
    public static void main(String[] args) {
        System.out.println("--- Test 1: Division by zero ---");
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.printf("Caught: %s \u2014 %s%n", e.getClass().getSimpleName(), e.getMessage());
        }
        System.out.println();

        System.out.println("--- Test 2: Array index out of bounds ---");
        try {
            int[] arr = new int[5];
            int val = arr[10];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.printf("Caught: %s \u2014 %s%n", e.getClass().getSimpleName(), e.getMessage());
        }
        System.out.println();

        System.out.println("--- Test 3: Number format ---");
        try {
            int num = Integer.parseInt("abc");
        } catch (NumberFormatException e) {
            System.out.printf("Caught: %s \u2014 %s%n", e.getClass().getSimpleName(), e.getMessage());
        }
        System.out.println();

        System.out.println("Program continues normally.");
    }
}
