package com.school.exceptions;

public class TestGradeBook {
    public static void main(String[] args) {
        String[] students = {"Alice", "Bob", "Charlie"};
        double[] grades = {88.5, 92.0, 79.5};
        GradeBook book = new GradeBook(students, grades);

        System.out.println("--- Get grade for Alice ---");
        try {
            double grade = book.getGrade("Alice");
            System.out.printf("Alice's grade: %s%n", grade);
        } catch (StudentNotFoundException e) {
            System.out.printf("StudentNotFoundException: %s%n", e.getMessage());
        } finally {
            System.out.println("[finally] Lookup complete.");
        }
        System.out.println();

        System.out.println("--- Get grade for Zara ---");
        try {
            double grade = book.getGrade("Zara");
            System.out.printf("Zara's grade: %s%n", grade);
        } catch (StudentNotFoundException e) {
            System.out.printf("StudentNotFoundException: %s%n", e.getMessage());
        } finally {
            System.out.println("[finally] Lookup complete.");
        }
        System.out.println();

        System.out.println("--- Update Bob's grade to 95.0 ---");
        try {
            book.addGrade("Bob", 95.0);
            System.out.println("Bob's grade updated to 95.0");
        } catch (Exception e) {
            System.out.printf("%s: %s%n", e.getClass().getSimpleName(), e.getMessage());
        } finally {
            System.out.println("[finally] Update operation complete.");
        }
        System.out.println();

        System.out.println("--- Update Charlie's grade to 150.0 ---");
        try {
            book.addGrade("Charlie", 150.0);
            System.out.println("Charlie's grade updated to 150.0");
        } catch (Exception e) {
            System.out.printf("%s: %s%n", e.getClass().getSimpleName(), e.getMessage());
        } finally {
            System.out.println("[finally] Update operation complete.");
        }
        System.out.println();

        System.out.println("--- Update Zara's grade to 80.0 ---");
        try {
            book.addGrade("Zara", 80.0);
            System.out.println("Zara's grade updated to 80.0");
        } catch (Exception e) {
            System.out.printf("%s: %s%n", e.getClass().getSimpleName(), e.getMessage());
        } finally {
            System.out.println("[finally] Update operation complete.");
        }
    }
}
