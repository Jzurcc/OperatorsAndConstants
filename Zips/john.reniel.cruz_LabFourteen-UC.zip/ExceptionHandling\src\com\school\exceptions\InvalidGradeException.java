package com.school.exceptions;

public class InvalidGradeException extends Exception {
    public InvalidGradeException(double grade) {
        super("Grade " + grade + " is invalid. Must be between 0 and 100.");
    }
}
