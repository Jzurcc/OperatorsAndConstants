package com.school.exceptions;

public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String name) {
        super("Student '" + name + "' was not found.");
    }
}
