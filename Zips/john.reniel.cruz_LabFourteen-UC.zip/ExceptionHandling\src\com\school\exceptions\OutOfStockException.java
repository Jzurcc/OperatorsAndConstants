package com.school.exceptions;

public class OutOfStockException extends Exception {
    String product;
    int requested;
    int available;

    public OutOfStockException(String product, int requested, int available) {
        super("Not enough " + product + " in stock. Requested: " + requested + ", Available: " + available);
        this.product = product;
        this.requested = requested;
        this.available = available;
    }
}
