package com.school.exceptions;

public class FinallyBlock {
    public static void main(String[] args) {
        System.out.println("--- Scenario 1: No exception ---");
        try {
            int result = 10 / 2;
            System.out.printf("Result: %s%n", result);
        } catch (ArithmeticException e) {
            System.out.printf("Caught: %s \u2014 %s%n", e.getClass().getSimpleName(), e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
        System.out.println();

        System.out.println("--- Scenario 2: Exception caught ---");
        try {
            int result = 10 / 0;
            System.out.printf("Result: %s%n", result);
        } catch (ArithmeticException e) {
            System.out.printf("Caught: %s \u2014 %s%n", e.getClass().getSimpleName(), e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
        System.out.println();

        System.out.println("--- Scenario 3: Resource cleanup ---");
        try {
            System.out.println("Opening connection...");
            throw new Exception("Something went wrong!");
        } catch (Exception e) {
            System.out.printf("Caught: %s%n", e.getMessage());
        } finally {
            System.out.println("Closing connection... (cleanup)");
        }
    }
}
