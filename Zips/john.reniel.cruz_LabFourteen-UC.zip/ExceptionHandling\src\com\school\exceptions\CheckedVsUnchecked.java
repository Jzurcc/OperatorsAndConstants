package com.school.exceptions;

public class CheckedVsUnchecked {
    public static void riskyOperation() throws Exception {
        throw new Exception("Simulated checked exception");
    }

    public static void main(String[] args) {
        System.out.println("--- Unchecked exceptions (runtime) ---");
        try {
            String str = null;
            str.length();
        } catch (NullPointerException e) {
            System.out.printf("NullPointerException: %s%n", e.getMessage());
        }

        try {
            String str = "test";
            str.charAt(50);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.printf("StringIndexOutOfBoundsException: %s%n", e.getMessage());
        }

        try {
            Object obj = "hello";
            Integer num = (Integer) obj;
        } catch (ClassCastException e) {
            System.out.printf("ClassCastException: %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- Checked exception (compile-time) ---");
        try {
            riskyOperation();
        } catch (Exception e) {
            System.out.printf("Caught checked exception: %s%n", e.getMessage());
        }
        System.out.println("(This would NOT compile without try-catch or throws!)");
    }
}
