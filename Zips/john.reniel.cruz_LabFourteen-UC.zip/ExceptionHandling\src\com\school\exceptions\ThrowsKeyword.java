package com.school.exceptions;

public class ThrowsKeyword {
    public static int parseAge(String input) throws NumberFormatException {
        return Integer.parseInt(input);
    }

    public static void checkEligibility(int age) throws Exception {
        if (age < 18) {
            throw new Exception("Must be 18 or older.");
        }
    }

    public static void processApplication(String ageInput) throws Exception {
        int age = parseAge(ageInput);
        System.out.printf("Age: %s%n", age);
        checkEligibility(age);
        System.out.println("Application accepted!");
    }

    public static void main(String[] args) {
        System.out.println("--- Application 1: \"25\" ---");
        try {
            processApplication("25");
        } catch (NumberFormatException e) {
            System.out.printf("Error: Invalid age input \u2014 %s%n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("Rejected: %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- Application 2: \"15\" ---");
        try {
            processApplication("15");
        } catch (NumberFormatException e) {
            System.out.printf("Error: Invalid age input \u2014 %s%n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("Rejected: %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- Application 3: \"abc\" ---");
        try {
            processApplication("abc");
        } catch (NumberFormatException e) {
            System.out.printf("Error: Invalid age input \u2014 %s%n", e.getMessage());
        } catch (Exception e) {
            System.out.printf("Rejected: %s%n", e.getMessage());
        }
    }
}
