package com.school.staticdemo;

public class TestStudent {
    public static void main(String[] args) {
        Student alice = new Student("Alice", 20, 3.5);
        Student bob = new Student("Bob", 21, 2.8);
        Student charlie = new Student("Charlie", 19, 3.9);

        System.out.println("--- Before change ---");
        alice.displayInfo();
        bob.displayInfo();
        charlie.displayInfo();

        System.out.println();
        System.out.println("Changing Bob's GPA to 3.1...");
        bob.gpa = 3.1;
        System.out.println();

        System.out.println("--- After change ---");
        alice.displayInfo();
        bob.displayInfo();
        charlie.displayInfo();
    }
}
