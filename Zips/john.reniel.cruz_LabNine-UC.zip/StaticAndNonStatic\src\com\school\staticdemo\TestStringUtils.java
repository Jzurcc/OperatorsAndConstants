package com.school.staticdemo;

public class TestStringUtils {
    public static void main(String[] args) {
        System.out.printf("reverse(\"Hello\") = %s%n", StringUtils.reverse("Hello"));
        System.out.printf("countVowels(\"Programming\") = %s%n", StringUtils.countVowels("Programming"));
        System.out.printf("capitalize(\"java\") = %s%n", StringUtils.capitalize("java"));
        System.out.printf("isPalindrome(\"Racecar\") = %s%n", StringUtils.isPalindrome("Racecar"));
        System.out.printf("isPalindrome(\"Hello\") = %s%n", StringUtils.isPalindrome("Hello"));
    }
}
