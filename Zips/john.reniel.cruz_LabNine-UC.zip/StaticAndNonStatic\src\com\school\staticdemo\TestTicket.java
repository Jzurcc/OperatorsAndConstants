package com.school.staticdemo;

public class TestTicket {
    public static void main(String[] args) {
        Ticket t1 = new Ticket("Java Conference", "Alice", 1500.0);
        Ticket t2 = new Ticket("Java Conference", "Bob", 1500.0);
        Ticket t3 = new Ticket("Music Festival", "Charlie", 2500.0);
        Ticket t4 = new Ticket("Music Festival", "Diana", 2500.0);

        t1.displayTicket();
        t2.displayTicket();
        t3.displayTicket();
        t4.displayTicket();

        Ticket.displaySalesSummary();
    }
}
