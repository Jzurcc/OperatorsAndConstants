package com.school.staticdemo;

public class Config {
    static final String APP_NAME = "SchoolSystem";
    static final String VERSION = "2.1.0";
    static final int MAX_STUDENTS = 50;
    static final double TAX_RATE = 0.12;
    static int currentStudentCount = 0;

    public static void enrollStudent() {
        if (currentStudentCount < MAX_STUDENTS) {
            currentStudentCount++;
            System.out.printf("Enrolling student... Current: %s%n", currentStudentCount);
        } else {
            System.out.println("Error: Maximum students reached.");
        }
    }

    public static int getRemainingSlots() {
        return MAX_STUDENTS - currentStudentCount;
    }

    public static void displayConfig() {
        System.out.println("--- System Configuration ---");
        System.out.printf("App: %s v%s%n", APP_NAME, VERSION);
        System.out.printf("Max students: %s%n", MAX_STUDENTS);
        System.out.printf("Tax rate: %s%%%n", (TAX_RATE * 100));
    }
}
