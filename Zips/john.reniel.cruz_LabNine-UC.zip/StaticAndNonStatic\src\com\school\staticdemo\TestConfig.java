package com.school.staticdemo;

public class TestConfig {
    public static void main(String[] args) {
        Config.displayConfig();
        System.out.println();

        Config.enrollStudent();
        Config.enrollStudent();
        Config.enrollStudent();
        System.out.println();

        System.out.printf("Remaining slots: %s%n", Config.getRemainingSlots());
    }
}
