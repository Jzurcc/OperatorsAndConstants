package com.school.staticdemo;

public class TestClassroom {
    public static void main(String[] args) {
        Classroom room1 = new Classroom("Mr. Garcia", "Java Programming");
        room1.enroll("Alice");
        room1.enroll("Bob");
        room1.enroll("Charlie");

        Classroom room2 = new Classroom("Ms. Reyes", "Data Structures");
        room2.enroll("Diana");
        room2.enroll("Edward");
        room2.enroll("Fiona");
        room2.enroll("George");
        room2.enroll("Hannah");

        room1.displayClassInfo();
        room2.displayClassInfo();

        System.out.println("Attempting to enroll \"Ivan\" in Classroom #2...");
        room2.enroll("Ivan");
        System.out.println();

        Classroom.displaySchoolSummary();
    }
}
