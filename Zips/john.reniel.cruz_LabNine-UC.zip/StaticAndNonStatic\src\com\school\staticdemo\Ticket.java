package com.school.staticdemo;

public class Ticket {
    static int nextTicketNumber = 1000;
    static double totalRevenue = 0;
    static int totalTicketsSold = 0;

    int ticketNumber;
    String eventName;
    String buyerName;
    double price;

    public Ticket(String eventName, String buyerName, double price) {
        nextTicketNumber++;
        this.ticketNumber = nextTicketNumber;
        this.eventName = eventName;
        this.buyerName = buyerName;
        this.price = price;
        totalRevenue += price;
        totalTicketsSold++;
    }

    public void displayTicket() {
        System.out.printf("--- Ticket #%s ---%n", ticketNumber);
        System.out.printf("Event: %s%n", eventName);
        System.out.printf("Buyer: %s%n", buyerName);
        System.out.printf("Price: %s%n", price);
        System.out.println();
    }

    public static void displaySalesSummary() {
        System.out.println("=== Sales Summary ===");
        System.out.printf("Total tickets sold: %s%n", totalTicketsSold);
        System.out.printf("Total revenue: %s%n", totalRevenue);
    }
}
