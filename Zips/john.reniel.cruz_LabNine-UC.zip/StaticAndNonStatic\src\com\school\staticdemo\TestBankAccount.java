package com.school.staticdemo;

public class TestBankAccount {
    public static void main(String[] args) {
        System.out.println("--- Individual accounts ---");
        BankAccount a1 = new BankAccount("Alice", 10000.0);
        BankAccount a2 = new BankAccount("Bob", 25000.0);
        BankAccount a3 = new BankAccount("Charlie", 5000.0);

        a1.displayInfo();
        a2.displayInfo();
        a3.displayInfo();
        System.out.println();

        System.out.println("Alice deposits 5000.0...");
        a1.deposit(5000.0);
        System.out.println();

        System.out.println("--- After deposit ---");
        a1.displayInfo();
        System.out.println();

        System.out.println("--- Bank summary (static) ---");
        BankAccount.displayBankSummary();
    }
}
