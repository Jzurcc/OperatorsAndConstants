package com.school.staticdemo;

public class Counter {
    static int count = 0;
    String label;

    public Counter(String label) {
        this.label = label;
        count++;
    }
}
