package com.school.staticdemo;

public class TestMathHelper {
    public static void main(String[] args) {
        System.out.printf("MathHelper.add(10, 5) = %s%n", MathHelper.add(10, 5));
        System.out.printf("MathHelper.subtract(10, 5) = %s%n", MathHelper.subtract(10, 5));
        System.out.printf("MathHelper.multiply(10, 5) = %s%n", MathHelper.multiply(10, 5));
        System.out.printf("MathHelper.divide(10, 5) = %s%n", MathHelper.divide(10, 5));
        System.out.printf("MathHelper.divide(10, 0) = %s%n", MathHelper.divide(10, 0));
        System.out.printf("MathHelper.max(10, 5) = %s%n", MathHelper.max(10, 5));
        System.out.printf("MathHelper.min(10, 5) = %s%n", MathHelper.min(10, 5));
    }
}
