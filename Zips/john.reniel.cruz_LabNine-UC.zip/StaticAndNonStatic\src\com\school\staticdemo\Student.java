package com.school.staticdemo;

public class Student {
    String name;
    int age;
    double gpa;

    public Student(String name, int age, double gpa) {
        this.name = name;
        this.age = age;
        this.gpa = gpa;
    }

    public void displayInfo() {
        System.out.printf("%s, Age %s, GPA: %s%n", name, age, gpa);
    }
}
