package com.school.staticdemo;

public class Dog {
    String name;
    String breed;
    int energy;

    public Dog(String name, String breed) {
        this.name = name;
        this.breed = breed;
        this.energy = 100;
    }

    public void play() {
        if (energy < 20) {
            System.out.println("Too tired to play!");
        } else {
            energy -= 20;
            System.out.printf("%s plays!%n", name);
        }
    }

    public void eat() {
        energy += 30;
        if (energy > 100) energy = 100;
        System.out.printf("%s eats!%n", name);
    }

    public void displayStatus() {
        System.out.printf("%s (%s): Energy = %s%n", name, breed, energy);
    }
}
