package com.school.staticdemo;

public class TestCounter {
    public static void main(String[] args) {
        Counter alpha = new Counter("Alpha");
        System.out.printf("Created: Alpha \u2014 Count: %s%n", Counter.count);

        Counter beta = new Counter("Beta");
        System.out.printf("Created: Beta \u2014 Count: %s%n", Counter.count);

        Counter gamma = new Counter("Gamma");
        System.out.printf("Created: Gamma \u2014 Count: %s%n", Counter.count);

        Counter delta = new Counter("Delta");
        System.out.printf("Created: Delta \u2014 Count: %s%n", Counter.count);

        System.out.println();
        System.out.printf("Accessing count via class name: Counter.count = %s%n", Counter.count);
        System.out.printf("Accessing count via object: %s (same value \u2014 it's shared)%n", delta.count);
    }
}
