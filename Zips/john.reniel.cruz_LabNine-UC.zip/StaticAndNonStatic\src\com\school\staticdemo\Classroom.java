package com.school.staticdemo;

public class Classroom {
    static String schoolName = "Greenfield Academy";
    static int totalClassrooms = 0;
    static int totalStudentsEnrolled = 0;
    static final int MAX_PER_CLASS = 5;

    int classroomId;
    String teacher;
    String subject;
    String[] students;
    int studentCount;

    public Classroom(String teacher, String subject) {
        totalClassrooms++;
        this.classroomId = totalClassrooms;
        this.teacher = teacher;
        this.subject = subject;
        this.students = new String[MAX_PER_CLASS];
        this.studentCount = 0;
    }

    public void enroll(String name) {
        if (!isFull()) {
            students[studentCount] = name;
            studentCount++;
            totalStudentsEnrolled++;
        } else {
            System.out.println("Error: Classroom is full.");
        }
    }

    public boolean isFull() {
        return studentCount == MAX_PER_CLASS;
    }

    public void displayClassInfo() {
        System.out.println("========================================");
        System.out.printf("  Classroom #%s \u2014 %s%n", classroomId, subject);
        System.out.println("========================================");
        System.out.printf("Teacher: %s%n", teacher);
        System.out.println("Students:");
        for (int i = 0; i < studentCount; i++) {
            System.out.printf("  %s. %s%n", (i + 1), students[i]);
        }
        System.out.printf("Enrolled: %s/%s | Full: %s%n", studentCount, MAX_PER_CLASS, isFull());
        System.out.println();
    }

    public static void displaySchoolSummary() {
        System.out.println("========================================");
        System.out.println("  SCHOOL SUMMARY (static)");
        System.out.println("========================================");
        System.out.printf("School: %s%n", schoolName);
        System.out.printf("Total classrooms: %s%n", totalClassrooms);
        System.out.printf("Total students enrolled: %s%n", totalStudentsEnrolled);
        System.out.println("========================================");
    }
}
