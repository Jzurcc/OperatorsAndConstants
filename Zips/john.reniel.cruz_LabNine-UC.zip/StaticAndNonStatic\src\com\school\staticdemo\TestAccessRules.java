package com.school.staticdemo;

public class TestAccessRules {
    public static void main(String[] args) {
        System.out.println("--- Static method accessing static variable ---");
        AccessRules.staticMethod();
        System.out.println();

        System.out.println("--- Instance method accessing both ---");
        AccessRules obj = new AccessRules();
        obj.instanceMethod();
        System.out.println();

        System.out.println("--- Instance method calling static method ---");
        obj.callStaticMethod();
    }
}
