package com.school.staticdemo;

public class BankAccount {
    static String bankName = "Java National Bank";
    static int totalAccounts = 0;
    static double totalDeposits = 0;

    String owner;
    double balance;

    public BankAccount(String owner, double balance) {
        this.owner = owner;
        this.balance = balance;
        totalAccounts++;
        totalDeposits += balance;
    }

    public void deposit(double amount) {
        balance += amount;
        totalDeposits += amount;
    }

    public void displayInfo() {
        System.out.printf("Owner: %s \u2014 Balance: %s%n", owner, balance);
    }

    public static void displayBankSummary() {
        System.out.printf("Bank: %s%n", bankName);
        System.out.printf("Total accounts: %s%n", totalAccounts);
        System.out.printf("Total deposits: %s%n", totalDeposits);
    }
}
