package com.school.staticdemo;

public class AccessRules {
    static String className = "AccessRules";
    String instanceName = "Object-Level";

    public static void staticMethod() {
        System.out.printf("Class name: %s%n", className);
        // System.out.println(instanceName); // inside staticMethod(): instanceName → ERROR: non-static variable instanceName cannot be referenced from a static context
    }

    public void instanceMethod() {
        System.out.printf("Class name: %s%n", className);
        System.out.printf("Instance name: %s%n", instanceName);
    }

    public static void callInstanceMethod() {
        // instanceMethod(); // Inside callInstanceMethod(): instanceMethod() → ERROR: non-static method instanceMethod() cannot be referenced from a static context
    }

    public void callStaticMethod() {
        staticMethod();
    }
}
