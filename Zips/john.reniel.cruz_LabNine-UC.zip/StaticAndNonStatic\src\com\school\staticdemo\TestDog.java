package com.school.staticdemo;

public class TestDog {
    public static void main(String[] args) {
        Dog bantay = new Dog("Bantay", "Aspin");
        Dog coco = new Dog("Coco", "Poodle");

        System.out.println("--- Initial status ---");
        bantay.displayStatus();
        coco.displayStatus();
        System.out.println();

        bantay.play();
        bantay.displayStatus();
        bantay.play();
        bantay.displayStatus();
        System.out.println();

        coco.eat();
        coco.displayStatus();
        System.out.println();

        bantay.eat();
        bantay.displayStatus();
        System.out.println();

        coco.play();
        coco.displayStatus();
    }
}
