package com.school.loops;

public class CountdownTimer {
    public static void main(String[] args) {
        int minutes = 0;
        int seconds = 10;
        while (seconds > 0) {
            System.out.println(String.format("%d:%02d", minutes, seconds));
            seconds--;
        }
        System.out.println("Time's up!");
    }
}
