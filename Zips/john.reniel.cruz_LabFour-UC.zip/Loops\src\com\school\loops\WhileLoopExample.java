package com.school.loops;

public class WhileLoopExample {
    public static void main(String[] args) {
        int count = 10;
        while (count > 0) {
            System.out.println(count);
            count--;
        }
        System.out.println("Go!");
    }
}
