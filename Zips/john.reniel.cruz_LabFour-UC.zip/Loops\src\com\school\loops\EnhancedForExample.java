package com.school.loops;

public class EnhancedForExample {
    public static void main(String[] args) {
        String[] fruits = { "Apple", "Banana", "Cherry", "Durian", "Elderberry" };
        int count = 0;
        for (String fruit : fruits) {
            count++;
            System.out.printf("%s. %s%n", count, fruit);
        }
        System.out.printf("Total fruits: %s%n", count);
    }
}
