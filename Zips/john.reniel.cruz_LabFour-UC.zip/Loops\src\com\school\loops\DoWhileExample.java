package com.school.loops;

public class DoWhileExample {
    public static void main(String[] args) {
        int attempt = 1;
        int maxAttempts = 3;
        do {
            System.out.printf("Attempt %s: Processing...%n", attempt);
            attempt++;
        } while (attempt <= maxAttempts);
        System.out.println("All attempts completed.");
    }
}
