package com.school.loops;

public class GradeReport {
    static final double PASSING_GRADE = 75.0;

    public static void main(String[] args) {
        String[] subjects = {"Math", "Science", "English", "History", "PE"};
        double[] grades = {88.5, 72.0, 91.0, 68.5, 95.0};
        
        System.out.println("=== GRADE REPORT ===");
        for (int i = 0; i < subjects.length; i++) {
            String status = grades[i] >= PASSING_GRADE ? "Passed" : "Failed";
            System.out.printf("%-9s%s - %s\n", subjects[i] + ":", grades[i], status);
        }
        System.out.println();
        
        double total = 0;
        for (double grade : grades) {
            total += grade;
        }
        double average = total / grades.length;
        System.out.printf("Overall average: %s%n", average);
        
        int failedCount = 0;
        int index = 0;
        while (index < grades.length) {
            if (grades[index] < PASSING_GRADE) {
                failedCount++;
            }
            index++;
        }
        System.out.printf("Subjects failed: %s%n", failedCount);
        
        if (failedCount > 0) {
            System.out.println("Status: Conditional");
        } else {
            System.out.println("Status: Clear");
        }
    }
}
