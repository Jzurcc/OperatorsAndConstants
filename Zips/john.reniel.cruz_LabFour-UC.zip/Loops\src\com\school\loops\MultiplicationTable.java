package com.school.loops;

public class MultiplicationTable {
    public static void main(String[] args) {
        int num = 7;
        for (int i = 1; i <= 10; i++) {
            System.out.printf("%s x %s = %s%n", num, i, (num * i));
        }
    }
}
