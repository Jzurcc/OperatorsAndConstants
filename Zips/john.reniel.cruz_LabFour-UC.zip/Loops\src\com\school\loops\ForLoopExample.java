package com.school.loops;

public class ForLoopExample {
    public static void main(String[] args) {
        int count = 0;
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
            count++;
        }
        System.out.printf("Total numbers printed: %s%n", count);
    }
}
