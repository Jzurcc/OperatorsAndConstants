package com.school.loops;

public class FactorialCalculator {
    public static void main(String[] args) {
        int n = 6;
        long factorial = 1;
        System.out.printf("Calculating %s!%n", n);
        int current = n;
        do {
            long prev = factorial;
            factorial *= current;
            System.out.printf("Step: factorial = %s x %s = %s%n", prev, current, factorial);
            current--;
        } while (current > 0);
        System.out.printf("Result: 6! = %s%n", factorial);
    }
}
