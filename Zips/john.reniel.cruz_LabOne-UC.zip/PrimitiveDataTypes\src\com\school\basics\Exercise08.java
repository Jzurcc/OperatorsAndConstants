package com.school.basics;

public class Exercise08 {
    public static void main(String[] args) {
        int myInt = 100;
        double myDouble = myInt;
        System.out.printf("int value: %s -> double value: %s%n", myInt, myDouble);

        double price = 9.99;
        int wholePrice = (int) price;
        System.out.printf("double value: %s -> int value: %s%n", price, wholePrice);

        char letter = 'Z';
        int asciiValue = (int) letter;
        System.out.printf("char value: %s -> ASCII value: %s%n", letter, asciiValue);
    }
}
