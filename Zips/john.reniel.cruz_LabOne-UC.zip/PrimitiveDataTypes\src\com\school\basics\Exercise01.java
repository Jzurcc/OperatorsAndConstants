package com.school.basics;

public class Exercise01 {
    public static void main(String[] args) {
        byte myByte = 120;
        short myShort = 30000;
        int myInt = 1500000;
        long myLong = 9876543210L;

        System.out.printf("byte value: %s%n", myByte);
        System.out.printf("short value: %s%n", myShort);
        System.out.printf("int value: %s%n", myInt);
        System.out.printf("long value: %s%n", myLong);
    }
}
