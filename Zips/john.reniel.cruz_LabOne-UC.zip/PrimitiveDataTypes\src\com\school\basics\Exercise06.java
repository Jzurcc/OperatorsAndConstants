package com.school.basics;

public class Exercise06 {
    static String appName = "StudentTracker";
    static int version = 1;

    public static void main(String[] args) {
        String userName = "Admin";
        boolean isLoggedIn = true;

        System.out.printf("[static] App name: %s%n", appName);
        System.out.printf("[static] Version: %s%n", version);
        System.out.printf("[local] User: %s%n", userName);
        System.out.printf("[local] Logged in: %s%n", isLoggedIn);
    }
}
