package com.school.basics;

public class Exercise05 {
    static String schoolName = "Greenfield Academy";
    static int foundedYear = 1998;
    static double tuitionFee = 45000.50;
    static boolean isOpen = true;

    public static void main(String[] args) {
        System.out.printf("School: %s%n", schoolName);
        System.out.printf("Founded: %s%n", foundedYear);
        System.out.printf("Tuition fee: %s%n", tuitionFee);
        System.out.printf("Open: %s%n", isOpen);
    }
}
