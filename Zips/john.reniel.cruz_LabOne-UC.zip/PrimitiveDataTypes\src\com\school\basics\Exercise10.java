package com.school.basics;

public class Exercise10 {
    static String schoolName = "Greenfield Academy";
    static String semester = "1st Semester, 2025-2026";
    static char passingGrade = 'D';

    public static void main(String[] args) {
        String studentName = "John Reniel Cruz";
        int studentId = 20240001;
        double mathGrade = 89.5;
        double scienceGrade = 92.0;
        double englishGrade = 85.75;

        double average = (mathGrade + scienceGrade + englishGrade) / 3;

        char finalGrade;
        if (average >= 90) {
            finalGrade = 'A';
        } else if (average >= 80) {
            finalGrade = 'B';
        } else if (average >= 70) {
            finalGrade = 'C';
        } else {
            finalGrade = 'F';
        }

        boolean passed = (finalGrade != 'F');

        System.out.println("=============================");
        System.out.println("       REPORT CARD");
        System.out.println("=============================");
        System.out.printf("School: %s%n", schoolName);
        System.out.printf("Semester: %s%n", semester);
        System.out.println();
        System.out.printf("Student: %s%n", studentName);
        System.out.printf("ID: %s%n", studentId);
        System.out.println();
        System.out.printf("Math:    %s%n", mathGrade);
        System.out.printf("Science: %s%n", scienceGrade);
        System.out.printf("English: %s%n", englishGrade);
        System.out.println();
        System.out.printf("Average: %.2f%n", average);
        System.out.printf("Grade: %s%n", finalGrade);
        System.out.printf("Passed: %s%n", passed);
        System.out.println("=============================");
    }
}
