package com.school.basics;

public class Exercise02 {
    public static void main(String[] args) {
        float pi = 3.1416f;
        double gravity = 9.80665;
        double sum = pi + gravity;

        System.out.printf("float pi: %.4f%n", pi);
        System.out.printf("double gravity: %.5f%n", gravity);
        System.out.printf("sum: %.5f%n", sum);
    }
}
