package com.school.basics;

public class Exercise07 {
    public static void main(String[] args) {
        int a = 25;
        int b = 7;
        
        int addition = a + b;
        int subtraction = a - b;
        int multiplication = a * b;
        int division = a / b;
        int modulus = a % b;

        System.out.printf("25 + 7 = %s%n", addition);
        System.out.printf("25 - 7 = %s%n", subtraction);
        System.out.printf("25 * 7 = %s%n", multiplication);
        System.out.printf("25 / 7 = %s%n", division);
        System.out.printf("25 %% 7 = %s%n", modulus);
    }
}
