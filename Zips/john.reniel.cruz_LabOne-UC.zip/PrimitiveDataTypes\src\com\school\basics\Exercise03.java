package com.school.basics;

public class Exercise03 {
    public static void main(String[] args) {
        char initial = 'J';
        char grade = 'A';
        boolean isPassing = true;
        boolean isAbsent = false;

        System.out.printf("initial: %s%n", initial);
        System.out.printf("grade: %s%n", grade);
        System.out.printf("isPassing: %s%n", isPassing);
        System.out.printf("isAbsent: %s%n", isAbsent);
    }
}
