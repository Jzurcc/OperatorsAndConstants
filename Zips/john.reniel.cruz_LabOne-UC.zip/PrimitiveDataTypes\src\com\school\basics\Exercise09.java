package com.school.basics;

public class Exercise09 {
    static final double PI = 3.14159;
    static final int MAX_STUDENTS = 40;
    static final char PASSING_GRADE = 'C';
    static final String SCHOOL_MOTTO = "Learn. Grow. Succeed.";

    public static void main(String[] args) {
        System.out.printf("PI: %s%n", PI);
        System.out.printf("Max students: %s%n", MAX_STUDENTS);
        System.out.printf("Passing grade: %s%n", PASSING_GRADE);
        System.out.printf("Motto: %s%n", SCHOOL_MOTTO);

        double radius = 5.0;
        double area = PI * radius * radius;
        System.out.printf("Area of circle with radius 5.0: %s%n", area);
    }
}
