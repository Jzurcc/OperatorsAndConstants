package com.school.basics;

public class Exercise04 {
    public static void main(String[] args) {
        byte myByte = 101;
        short myShort = 420;
        int myInt = 300000;
        long myLong = 6666699999L;
        float myFloat = 6.7f;
        double myDouble = 2.2569;
        char myChar = 'Z';
        boolean myBoolean = false;

        System.out.printf("byte: %s%n", myByte);
        System.out.printf("short: %s%n", myShort);
        System.out.printf("int: %s%n", myInt);
        System.out.printf("long: %s%n", myLong);
        System.out.printf("float: %s%n", myFloat);
        System.out.printf("double: %s%n", myDouble);
        System.out.printf("char: %s%n", myChar);
        System.out.printf("boolean: %s%n", myBoolean);
    }
}
