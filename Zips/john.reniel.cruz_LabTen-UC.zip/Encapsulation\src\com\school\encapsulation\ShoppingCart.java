package com.school.encapsulation;

public class ShoppingCart {
    private String customerName;
    private String[] itemNames;
    private double[] itemPrices;
    private int itemCount;

    public ShoppingCart(String customerName) {
        this.customerName = customerName;
        this.itemNames = new String[5];
        this.itemPrices = new double[5];
        this.itemCount = 0;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void addItem(String name, double price) {
        if (itemCount >= 5) {
            System.out.println("Error: Cart is full (max 5 items).");
            return;
        }
        if (name == null || name.isEmpty()) {
            System.out.println("Error: Item name cannot be empty.");
            return;
        }
        if (price <= 0) {
            System.out.println("Error: Price must be positive.");
            return;
        }
        itemNames[itemCount] = name;
        itemPrices[itemCount] = price;
        itemCount++;
    }

    public double getTotal() {
        double total = 0;
        for (int i = 0; i < itemCount; i++) {
            total += itemPrices[i];
        }
        return total;
    }

    public void displayCart() {
        System.out.println("========================================");
        System.out.printf("  Shopping Cart \u2014 %s%n", customerName);
        System.out.println("========================================");
        for (int i = 0; i < itemCount; i++) {
            System.out.printf("%d. %-15s - %.2f%n", (i + 1), itemNames[i], itemPrices[i]);
        }
        System.out.println("----------------------------------------");
        System.out.printf("Items: %s%n", itemCount);
        System.out.printf("Total: %.2f%n", getTotal());
        System.out.println("========================================");
    }
}
