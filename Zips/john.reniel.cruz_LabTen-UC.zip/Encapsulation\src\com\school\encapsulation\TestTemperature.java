package com.school.encapsulation;

public class TestTemperature {
    public static void main(String[] args) {
        Temperature temp = new Temperature();
        
        temp.setCelsius(0.0);
        System.out.printf("Celsius: %s%n", temp.getCelsius());
        System.out.printf("Fahrenheit: %s%n", temp.getFahrenheit());
        System.out.printf("Kelvin: %s%n", temp.getKelvin());
        System.out.println();

        temp.setCelsius(100.0);
        System.out.printf("Celsius: %s%n", temp.getCelsius());
        System.out.printf("Fahrenheit: %s%n", temp.getFahrenheit());
        System.out.printf("Kelvin: %s%n", temp.getKelvin());
        System.out.println();

        temp.setCelsius(37.0);
        System.out.printf("Celsius: %s%n", temp.getCelsius());
        System.out.printf("Fahrenheit: %s%n", temp.getFahrenheit());
        System.out.printf("Kelvin: %s%n", temp.getKelvin());
    }
}
