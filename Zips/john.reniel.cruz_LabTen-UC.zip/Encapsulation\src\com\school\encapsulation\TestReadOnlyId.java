package com.school.encapsulation;

public class TestReadOnlyId {
    public static void main(String[] args) {
        ReadOnlyId r1 = new ReadOnlyId("Widget A");
        ReadOnlyId r2 = new ReadOnlyId("Widget B");
        ReadOnlyId r3 = new ReadOnlyId("Widget C");

        System.out.printf("Item: %s (ID: %s)%n", r1.getLabel(), r1.getId());
        System.out.printf("Item: %s (ID: %s)%n", r2.getLabel(), r2.getId());
        System.out.printf("Item: %s (ID: %s)%n", r3.getLabel(), r3.getId());
    }
}
