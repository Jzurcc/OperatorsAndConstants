package com.school.encapsulation;

public class TestEmployee {
    public static void main(String[] args) {
        System.out.println("--- Employee 1 (no-arg constructor) ---");
        Employee e1 = new Employee();
        e1.displayInfo();
        System.out.println();

        System.out.println("--- Employee 2 (name only) ---");
        Employee e2 = new Employee("Ana Reyes");
        e2.displayInfo();
        System.out.println();

        System.out.println("--- Employee 3 (full constructor) ---");
        Employee e3 = new Employee("Carlos Garcia", "Engineering", 85000.0);
        e3.displayInfo();
    }
}
