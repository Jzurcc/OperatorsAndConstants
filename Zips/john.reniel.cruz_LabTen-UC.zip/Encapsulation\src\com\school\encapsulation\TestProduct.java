package com.school.encapsulation;

public class TestProduct {
    public static void main(String[] args) {
        System.out.println("--- Valid product ---");
        Product p1 = new Product("Laptop", 45999.0, 10);
        System.out.printf("Product: %s%n", p1.getProductName());
        System.out.printf("Price: %s%n", p1.getPrice());
        System.out.printf("Quantity: %s%n", p1.getQuantity());
        System.out.printf("Total value: %s%n", p1.getTotalValue());
        System.out.println();

        System.out.println("--- Invalid product (bad inputs corrected) ---");
        Product p2 = new Product("", -500.0, -5);
        System.out.printf("Product: %s%n", p2.getProductName());
        System.out.printf("Price: %s%n", p2.getPrice());
        System.out.printf("Quantity: %s%n", p2.getQuantity());
        System.out.printf("Total value: %s%n", p2.getTotalValue());
    }
}
