package com.school.encapsulation;

public class TestShoppingCart {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart("Maria Santos");
        cart.addItem("Laptop", 45999.00);
        cart.addItem("Mouse", 599.00);
        cart.addItem("Keyboard", 1299.00);
        cart.addItem("Monitor", 12500.00);
        cart.addItem("USB Hub", 450.00);
        
        cart.displayCart();
        System.out.println();
        
        System.out.println("Attempting to add another item...");
        cart.addItem("Headset", 1500.00);
        System.out.println();
        
        System.out.println("Attempting to add item with empty name...");
        cart.addItem("", 100.00);
        System.out.println();
        
        System.out.println("Attempting to add item with negative price...");
        cart.addItem("Invalid", -50.00);
    }
}
