package com.school.encapsulation;

public class TestRectangle {
    public static void main(String[] args) {
        System.out.println("--- Rectangle ---");
        Rectangle r1 = new Rectangle(8.0, 5.0);
        System.out.printf("Width: %s%n", r1.getWidth());
        System.out.printf("Height: %s%n", r1.getHeight());
        System.out.printf("Area: %s%n", r1.getArea());
        System.out.printf("Perimeter: %s%n", r1.getPerimeter());
        System.out.printf("Is square: %s%n", r1.isSquare());
        System.out.println();

        System.out.println("--- Square ---");
        Rectangle r2 = new Rectangle(6.0, 6.0);
        System.out.printf("Width: %s%n", r2.getWidth());
        System.out.printf("Height: %s%n", r2.getHeight());
        System.out.printf("Area: %s%n", r2.getArea());
        System.out.printf("Perimeter: %s%n", r2.getPerimeter());
        System.out.printf("Is square: %s%n", r2.isSquare());
        System.out.println();

        System.out.println("--- Invalid dimensions (corrected to 1.0) ---");
        Rectangle r3 = new Rectangle(0.0, -5.0);
        System.out.printf("Width: %s%n", r3.getWidth());
        System.out.printf("Height: %s%n", r3.getHeight());
    }
}
