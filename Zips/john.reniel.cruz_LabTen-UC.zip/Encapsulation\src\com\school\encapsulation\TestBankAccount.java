package com.school.encapsulation;

public class TestBankAccount {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        account.setAccountHolder("Juan Dela Cruz");
        account.setBalance(10000.0);

        System.out.printf("Account holder: %s%n", account.getAccountHolder());
        System.out.printf("Balance: %s%n", account.getBalance());
        System.out.println();

        System.out.println("Depositing 5000.0...");
        account.deposit(5000.0);
        System.out.printf("Balance: %s%n", account.getBalance());
        System.out.println();

        System.out.println("Withdrawing 3000.0...");
        account.withdraw(3000.0);
        System.out.printf("Balance: %s%n", account.getBalance());
        System.out.println();

        System.out.println("Attempting to withdraw 50000.0...");
        account.withdraw(50000.0);
        System.out.println();

        System.out.println("Attempting to set balance to -500.0...");
        account.setBalance(-500.0);
        System.out.printf("Balance: %s%n", account.getBalance());
        System.out.println();

        System.out.println("Attempting to set name to \"\"...");
        account.setAccountHolder("");
    }
}
