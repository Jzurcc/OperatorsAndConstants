package com.school.encapsulation;

public class Employee {
    private String name;
    private String department;
    private double salary;

    public Employee() {
        this("New Employee", "Unassigned", 0.0);
    }

    public Employee(String name) {
        this(name, "Unassigned", 0.0);
    }

    public Employee(String name, String department, double salary) {
        setName(name);
        setDepartment(department);
        setSalary(salary);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        if (salary >= 0) {
            this.salary = salary;
        } else {
            this.salary = 0.0;
        }
    }

    public void displayInfo() {
        System.out.printf("Name: %s%n", name);
        System.out.printf("Department: %s%n", department);
        System.out.printf("Salary: %s%n", salary);
    }
}
