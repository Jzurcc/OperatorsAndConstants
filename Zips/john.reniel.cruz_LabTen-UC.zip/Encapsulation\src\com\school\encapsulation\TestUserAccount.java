package com.school.encapsulation;

public class TestUserAccount {
    public static void main(String[] args) {
        System.out.println("--- Account created ---");
        UserAccount account = new UserAccount("maria_santos", "secret123", "maria@email.com");
        System.out.printf("Username: %s%n", account.getUsername());
        System.out.printf("Password: %s%n", account.getPassword());
        System.out.printf("Email: %s%n", account.getEmail());
        System.out.println();

        System.out.println("--- Attempting invalid updates ---");
        account.setUsername("ab");
        account.setPassword("12345");
        account.setEmail("mariaemail.com");
        System.out.println();

        System.out.println("--- Values unchanged ---");
        System.out.printf("Username: %s%n", account.getUsername());
        System.out.printf("Password: %s%n", account.getPassword());
        System.out.printf("Email: %s%n", account.getEmail());
    }
}
