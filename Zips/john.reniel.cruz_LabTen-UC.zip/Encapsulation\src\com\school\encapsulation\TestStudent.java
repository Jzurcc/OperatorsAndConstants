package com.school.encapsulation;

public class TestStudent {
    public static void main(String[] args) {
        Student alice = new Student("Alice", 20240001, 3.8);
        System.out.printf("Student: %s (ID: %s)%n", alice.getName(), alice.getStudentId());
        System.out.printf("GPA: %s%n", alice.getGpa());
        System.out.printf("Status: %s%n", alice.getStatus());
        System.out.println();

        Student bob = new Student("Bob", 20240002, 1.5);
        System.out.printf("Student: %s (ID: %s)%n", bob.getName(), bob.getStudentId());
        System.out.printf("GPA: %s%n", bob.getGpa());
        System.out.printf("Status: %s%n", bob.getStatus());
    }
}
