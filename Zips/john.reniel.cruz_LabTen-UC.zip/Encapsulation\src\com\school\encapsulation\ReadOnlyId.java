package com.school.encapsulation;

public class ReadOnlyId {
    private static int nextId = 1000;
    private int id;
    private String label;

    public ReadOnlyId(String label) {
        nextId++;
        this.id = nextId;
        this.label = label;
    }

    public int getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
