package com.school.encapsulation;

public class TestPerson {
    public static void main(String[] args) {
        Person person = new Person();
        person.setName("Maria Santos");
        person.setAge(25);
        person.setEmail("maria.santos@email.com");

        System.out.printf("Name: %s%n", person.getName());
        System.out.printf("Age: %s%n", person.getAge());
        System.out.printf("Email: %s%n", person.getEmail());
    }
}
