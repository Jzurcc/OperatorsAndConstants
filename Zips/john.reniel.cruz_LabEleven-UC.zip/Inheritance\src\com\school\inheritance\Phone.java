package com.school.inheritance;

public class Phone extends Device {
    double screenSize;
    int storage;

    public Phone(String brand, double price, double screenSize, int storage) {
        super(brand, price);
        this.screenSize = screenSize;
        this.storage = storage;
    }

    @Override
    public void powerOn() {
        System.out.println("Phone screen is on.");
    }

    public void makeCall(String number) {
        System.out.printf("Calling %s...%n", number);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Screen: %s\", Storage: %sGB%n", screenSize, storage);
    }
}
