package com.school.inheritance;

public class Laptop extends Device {
    int ram;
    String processor;

    public Laptop(String brand, double price, int ram, String processor) {
        super(brand, price);
        this.ram = ram;
        this.processor = processor;
    }

    @Override
    public void powerOn() {
        System.out.println("Laptop booting up...");
    }

    public void openApp(String appName) {
        System.out.printf("Opening %s...%n", appName);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("RAM: %sGB, Processor: %s%n", ram, processor);
    }
}
