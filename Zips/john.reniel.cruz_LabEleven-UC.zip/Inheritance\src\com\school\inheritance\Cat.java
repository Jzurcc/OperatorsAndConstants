package com.school.inheritance;

public class Cat extends Animal {
    boolean isIndoor;

    public Cat(String name, int age, boolean isIndoor) {
        super(name, age);
        this.isIndoor = isIndoor;
    }

    public void purr() {
        System.out.printf("%s is purring.%n", name);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Indoor: %s%n", isIndoor);
    }
}
