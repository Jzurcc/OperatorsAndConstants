package com.school.inheritance;

public class Vegetable extends Food {
    boolean isLeafy;

    public Vegetable(String name, int calories, boolean isLeafy) {
        super(name, calories);
        this.isLeafy = isLeafy;
    }

    @Override
    public void displayInfo() {
        System.out.print(name + " (" + calories + " cal, Leafy: " + isLeafy + ")");
    }
}
