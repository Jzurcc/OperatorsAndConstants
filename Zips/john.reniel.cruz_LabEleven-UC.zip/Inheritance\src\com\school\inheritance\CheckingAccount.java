package com.school.inheritance;

public class CheckingAccount extends BankAccount {
    double overdraftLimit;

    public CheckingAccount(String owner, double balance, double overdraftLimit) {
        super(owner, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= balance + overdraftLimit) {
            balance -= amount;
        } else {
            System.out.println("Error: Exceeds overdraft limit.");
        }
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Overdraft limit: %s%n", overdraftLimit);
    }
}
