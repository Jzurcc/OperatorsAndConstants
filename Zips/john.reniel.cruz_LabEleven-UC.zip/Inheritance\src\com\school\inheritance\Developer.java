package com.school.inheritance;

public class Developer extends Employee {
    int overtimeHours;
    static final double OVERTIME_RATE = 500.0;

    public Developer(String name, double baseSalary, int overtimeHours) {
        super(name, baseSalary);
        this.overtimeHours = overtimeHours;
    }

    @Override
    public double calculatePay() {
        return baseSalary + (overtimeHours * OVERTIME_RATE);
    }

    @Override
    public String getRole() {
        return "Developer";
    }

    @Override
    public void displayPayslip() {
        System.out.printf("[%s] %s%n", getRole(), name);
        System.out.printf("  Base: %s, OT: %s hrs x %s%n", baseSalary, overtimeHours, OVERTIME_RATE);
        System.out.printf("  Total pay: %s%n", calculatePay());
        System.out.println();
    }
}
