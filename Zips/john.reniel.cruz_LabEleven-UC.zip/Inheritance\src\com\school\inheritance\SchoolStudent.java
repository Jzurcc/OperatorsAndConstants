package com.school.inheritance;

public class SchoolStudent extends SchoolMember {
    String course;
    double gpa;
    double tuition;

    public SchoolStudent(String name, int age, String course, double gpa, double tuition) {
        super(name, age);
        this.course = course;
        this.gpa = gpa;
        this.tuition = tuition;
    }

    @Override
    public String getRole() {
        return "Student";
    }

    @Override
    public double getMonthlyPay() {
        return 0.0;
    }

    public String getStanding() {
        if (gpa >= 3.5) {
            return "Dean's List";
        } else if (gpa >= 2.0) {
            return "Regular";
        } else {
            return "Probation";
        }
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("  Course: %s, GPA: %s%n", course, gpa);
        System.out.printf("  Standing: %s%n", getStanding());
        System.out.printf("  Tuition: %s%n", tuition);
    }
}
