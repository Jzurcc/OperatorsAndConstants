package com.school.inheritance;

public class TestDevice {
    public static void main(String[] args) {
        System.out.println("--- Phone ---");
        Phone phone = new Phone("Samsung", 24990.0, 6.5, 128);
        phone.displayInfo();
        phone.powerOn();
        phone.makeCall("09171234567");
        System.out.println();

        System.out.println("--- Laptop ---");
        Laptop laptop = new Laptop("Lenovo", 45999.0, 16, "Intel i7");
        laptop.displayInfo();
        laptop.powerOn();
        laptop.openApp("IntelliJ IDEA");
    }
}
