package com.school.inheritance;

public class Teacher extends SchoolMember {
    String subject;
    double salary;

    public Teacher(String name, int age, String subject, double salary) {
        super(name, age);
        this.subject = subject;
        this.salary = salary;
    }

    @Override
    public String getRole() {
        return "Teacher";
    }

    @Override
    public double getMonthlyPay() {
        return salary;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("  Subject: %s%n", subject);
        System.out.printf("  Salary: %s%n", salary);
    }
}
