package com.school.inheritance;

public class ElectricCar extends Car {
    int batteryCapacity;
    int range;

    public ElectricCar(String brand, int year, int doors, int batteryCapacity, int range) {
        super(brand, year, doors, "Electric");
        this.batteryCapacity = batteryCapacity;
        this.range = range;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Battery: %s kWh%n", batteryCapacity);
        System.out.printf("Range: %s km%n", range);
    }
}
