package com.school.inheritance;

public class Refrigerator extends Appliance {
    double temperature;

    public Refrigerator(String brand, double price, double temperature) {
        super(brand, price);
        this.temperature = temperature;
    }

    @Override
    public void turnOn() {
        System.out.printf("Refrigerator is cooling to %s\u00B0C.%n", temperature);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Temp: %s\u00B0C%n", temperature);
    }
}
