package com.school.inheritance;

public class Manager extends Employee {
    double bonus;

    public Manager(String name, double baseSalary, double bonus) {
        super(name, baseSalary);
        this.bonus = bonus;
    }

    @Override
    public double calculatePay() {
        return baseSalary + bonus;
    }

    @Override
    public String getRole() {
        return "Manager";
    }

    @Override
    public void displayPayslip() {
        System.out.printf("[%s] %s%n", getRole(), name);
        System.out.printf("  Base: %s, Bonus: %s%n", baseSalary, bonus);
        System.out.printf("  Total pay: %s%n", calculatePay());
        System.out.println();
    }
}
