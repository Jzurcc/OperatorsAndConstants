package com.school.inheritance;

public class Fruit extends Food {
    String season;

    public Fruit(String name, int calories, String season) {
        super(name, calories);
        this.season = season;
    }

    @Override
    public void displayInfo() {
        System.out.print(name + " (" + calories + " cal, Season: " + season + ")");
    }
}
