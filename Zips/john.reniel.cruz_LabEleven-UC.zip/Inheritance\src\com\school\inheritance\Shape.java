package com.school.inheritance;

public class Shape {
    String color;

    public Shape(String color) {
        this.color = color;
    }

    public double getArea() {
        return 0.0;
    }

    public String getType() {
        return "Shape";
    }

    public void displayInfo() {
        System.out.printf("Type: %s%n", getType());
        System.out.printf("Color: %s%n", color);
        System.out.printf("Area: %s%n", String.format("%.2f", getArea()));
    }
}
