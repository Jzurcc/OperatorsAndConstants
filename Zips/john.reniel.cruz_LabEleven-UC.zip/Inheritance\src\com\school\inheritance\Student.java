package com.school.inheritance;

public class Student extends Person {
    String course;
    double gpa;

    public Student(String name, int age, String course, double gpa) {
        super(name, age);
        this.course = course;
        this.gpa = gpa;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Course: %s%n", course);
        System.out.printf("GPA: %s%n", gpa);
        System.out.printf("Standing: %s%n", getStanding());
    }

    public String getStanding() {
        if (gpa >= 3.5) {
            return "Dean's List";
        } else if (gpa >= 2.0) {
            return "Regular";
        } else {
            return "Probation";
        }
    }
}
