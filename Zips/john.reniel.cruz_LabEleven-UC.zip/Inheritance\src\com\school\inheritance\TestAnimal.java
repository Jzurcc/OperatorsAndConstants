package com.school.inheritance;

public class TestAnimal {
    public static void main(String[] args) {
        System.out.println("--- Dog ---");
        Dog dog = new Dog("Bantay", 3, "Aspin");
        dog.displayInfo();
        dog.eat();
        dog.sleep();
        dog.bark();
        System.out.println();

        System.out.println("--- Cat ---");
        Cat cat = new Cat("Mingming", 2, true);
        cat.displayInfo();
        cat.eat();
        cat.sleep();
        cat.purr();
    }
}
