package com.school.inheritance;

public class Food {
    String name;
    int calories;

    public Food(String name, int calories) {
        this.name = name;
        this.calories = calories;
    }

    public void displayInfo() {
        System.out.print(name + " (" + calories + " cal)");
    }
}
