package com.school.inheritance;

public class TestEmployee {
    public static void main(String[] args) {
        Employee[] employees = new Employee[3];
        employees[0] = new Manager("Alice Santos", 80000.0, 15000.0);
        employees[1] = new Developer("Bob Garcia", 55000.0, 20);
        employees[2] = new Developer("Charlie Reyes", 55000.0, 10);

        System.out.println("========================================");
        System.out.println("          PAYROLL REPORT");
        System.out.println("========================================");
        System.out.println();

        double totalPayroll = 0.0;
        for (Employee emp : employees) {
            emp.displayPayslip();
            totalPayroll += emp.calculatePay();
        }

        System.out.println("----------------------------------------");
        System.out.printf("Total payroll: %s%n", totalPayroll);
        System.out.println("========================================");
    }
}
