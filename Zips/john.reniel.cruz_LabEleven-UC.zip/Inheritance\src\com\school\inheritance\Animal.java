package com.school.inheritance;

public class Animal {
    String name;
    int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void eat() {
        System.out.printf("%s is eating.%n", name);
    }

    public void sleep() {
        System.out.printf("%s is sleeping.%n", name);
    }

    public void displayInfo() {
        System.out.print("Name: " + name + ", Age: " + age);
    }
}
