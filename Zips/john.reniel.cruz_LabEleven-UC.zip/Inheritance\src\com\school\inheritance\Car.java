package com.school.inheritance;

public class Car extends Vehicle {
    int doors;
    String fuelType;

    public Car(String brand, int year, int doors, String fuelType) {
        super(brand, year);
        this.doors = doors;
        this.fuelType = fuelType;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Doors: %s%n", doors);
        System.out.printf("Fuel: %s%n", fuelType);
    }
}
