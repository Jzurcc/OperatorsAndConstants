package com.school.inheritance;

public class SavingsAccount extends BankAccount {
    double interestRate;

    public SavingsAccount(String owner, double balance, double interestRate) {
        super(owner, balance);
        this.interestRate = interestRate;
    }

    public void applyInterest() {
        balance += (balance * interestRate / 100);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Interest: %s%%%n", interestRate);
    }
}
