package com.school.inheritance;

public class Vehicle {
    String brand;
    int year;

    public Vehicle(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }

    public void displayInfo() {
        System.out.printf("Brand: %s%n", brand);
        System.out.printf("Year: %s%n", year);
    }
}
