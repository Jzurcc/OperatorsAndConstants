package com.school.inheritance;

public class WashingMachine extends Appliance {
    int loadKg;

    public WashingMachine(String brand, double price, int loadKg) {
        super(brand, price);
        this.loadKg = loadKg;
    }

    @Override
    public void turnOn() {
        System.out.printf("Washing machine is running with %skg load.%n", loadKg);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Load: %skg%n", loadKg);
    }
}
