package com.school.inheritance;

public class TestBankAccount {
    public static void main(String[] args) {
        System.out.println("--- Savings Account ---");
        SavingsAccount sa = new SavingsAccount("Alice", 50000.0, 2.5);
        sa.displayInfo();
        System.out.println("Applying interest...");
        sa.applyInterest();
        sa.displayInfo();
        System.out.println();

        System.out.println("--- Checking Account ---");
        CheckingAccount ca = new CheckingAccount("Bob", 10000.0, 5000.0);
        ca.displayInfo();
        System.out.println("Withdrawing 12000.0...");
        ca.withdraw(12000.0);
        ca.displayInfo();
        System.out.println("Withdrawing 5000.0...");
        ca.withdraw(5000.0);
    }
}
