package com.school.inheritance;

public class TestSchoolSystem {
    public static void main(String[] args) {
        SchoolMember[] members = new SchoolMember[5];
        members[0] = new Teacher("Mr. Garcia", 35, "Java Programming", 45000.0);
        members[1] = new Teacher("Ms. Reyes", 40, "Data Structures", 48000.0);
        members[2] = new SchoolStudent("Alice", 20, "BSIT", 3.8, 35000.0);
        members[3] = new SchoolStudent("Bob", 21, "BSCS", 2.5, 35000.0);
        members[4] = new SchoolStudent("Charlie", 19, "BSIT", 1.8, 35000.0);

        System.out.println("========================================");
        System.out.println("      SCHOOL MEMBER DIRECTORY");
        System.out.println("========================================");
        System.out.println();

        int teacherCount = 0;
        int studentCount = 0;
        double totalMonthlyPayroll = 0.0;
        double totalTuitionRevenue = 0.0;

        for (SchoolMember member : members) {
            member.displayInfo();
            System.out.println();
            
            if (member instanceof Teacher) {
                teacherCount++;
            } else if (member instanceof SchoolStudent) {
                studentCount++;
                totalTuitionRevenue += ((SchoolStudent) member).tuition;
            }
            totalMonthlyPayroll += member.getMonthlyPay();
        }

        System.out.println("========================================");
        System.out.println("          SUMMARY");
        System.out.println("========================================");
        System.out.printf("Total members: %s%n", SchoolMember.totalMembers);
        System.out.printf("Teachers: %s%n", teacherCount);
        System.out.printf("Students: %s%n", studentCount);
        System.out.printf("Monthly payroll: %s%n", totalMonthlyPayroll);
        System.out.printf("Total tuition revenue: %s%n", totalTuitionRevenue);
        System.out.println("========================================");
    }
}
