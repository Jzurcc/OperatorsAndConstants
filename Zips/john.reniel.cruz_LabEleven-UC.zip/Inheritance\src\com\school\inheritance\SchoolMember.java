package com.school.inheritance;

public class SchoolMember {
    static int totalMembers = 0;
    int id;
    String name;
    int age;

    public SchoolMember(String name, int age) {
        totalMembers++;
        this.id = totalMembers;
        this.name = name;
        this.age = age;
    }

    public String getRole() {
        return "Member";
    }

    public double getMonthlyPay() {
        return 0.0;
    }

    public void displayInfo() {
        System.out.print("[ID: " + id + "] " + getRole() + " \u2014 " + name + ", Age: " + age + "\n");
    }
}
