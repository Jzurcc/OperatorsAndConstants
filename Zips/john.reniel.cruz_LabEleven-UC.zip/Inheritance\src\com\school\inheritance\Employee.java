package com.school.inheritance;

public class Employee {
    String name;
    double baseSalary;

    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public double calculatePay() {
        return baseSalary;
    }

    public String getRole() {
        return "Employee";
    }

    public void displayPayslip() {
        System.out.printf("[%s] %s%n", getRole(), name);
        System.out.printf("  Base: %s%n", baseSalary);
        System.out.printf("  Total pay: %s%n", calculatePay());
        System.out.println();
    }
}
