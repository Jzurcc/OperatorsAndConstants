package com.school.inheritance;

public class TestVehicle {
    public static void main(String[] args) {
        System.out.println("--- Vehicle ---");
        Vehicle v = new Vehicle("Generic Motors", 2020);
        v.displayInfo();
        System.out.println();

        System.out.println("--- Car ---");
        Car c = new Car("Toyota", 2023, 4, "Gasoline");
        c.displayInfo();
        System.out.println();

        System.out.println("--- Electric Car ---");
        ElectricCar ec = new ElectricCar("Tesla", 2024, 4, 75, 450);
        ec.displayInfo();
    }
}
