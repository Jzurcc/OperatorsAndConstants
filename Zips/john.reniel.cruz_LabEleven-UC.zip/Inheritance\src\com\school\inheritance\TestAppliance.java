package com.school.inheritance;

public class TestAppliance {
    public static void main(String[] args) {
        Appliance[] appliances = new Appliance[2];
        appliances[0] = new WashingMachine("Samsung", 18999.0, 8);
        appliances[1] = new Refrigerator("LG", 32500.0, 4.0);

        for (int i = 0; i < appliances.length; i++) {
            System.out.printf("--- Appliance %s ---%n", (i + 1));
            appliances[i].turnOn();
            appliances[i].displayInfo();
            if (i < appliances.length - 1) {
                System.out.println();
            }
        }
    }
}
