package com.school.inheritance;

public class TestFood {
    public static void main(String[] args) {
        Food[] foods = new Food[3];
        foods[0] = new Food("Rice", 200);
        foods[1] = new Fruit("Mango", 60, "Summer");
        foods[2] = new Vegetable("Broccoli", 55, true);

        System.out.println("--- Checking food items ---");
        System.out.println();

        for (Food f : foods) {
            f.displayInfo();
            System.out.printf(" \u2192 is Food: %s, is Fruit: %s, is Vegetable: %s%n", (f instanceof Food), (f instanceof Fruit), (f instanceof Vegetable));
            System.out.println();
        }
    }
}
