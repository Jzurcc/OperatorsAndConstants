package com.school.inheritance;

public class BankAccount {
    String owner;
    double balance;

    public BankAccount(String owner, double balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Error: Insufficient funds.");
        }
    }

    public void displayInfo() {
        System.out.print("Owner: " + owner + ", Balance: " + balance);
    }
}
