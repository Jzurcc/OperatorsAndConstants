package com.school.inheritance;

public class Appliance {
    String brand;
    double price;

    public Appliance(String brand, double price) {
        this.brand = brand;
        this.price = price;
    }

    public void turnOn() {
        System.out.println("Appliance is turning on.");
    }

    public void turnOff() {
        System.out.println("Appliance is turning off.");
    }

    public void displayInfo() {
        System.out.print("Brand: " + brand + ", Price: " + price);
    }
}
