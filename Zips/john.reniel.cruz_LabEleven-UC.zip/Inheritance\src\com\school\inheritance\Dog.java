package com.school.inheritance;

public class Dog extends Animal {
    String breed;

    public Dog(String name, int age, String breed) {
        super(name, age);
        this.breed = breed;
    }

    public void bark() {
        System.out.printf("%s says: Woof!%n", name);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf(", Breed: %s%n", breed);
    }
}
