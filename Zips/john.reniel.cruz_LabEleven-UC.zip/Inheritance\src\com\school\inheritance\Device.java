package com.school.inheritance;

public class Device {
    String brand;
    double price;

    public Device(String brand, double price) {
        this.brand = brand;
        this.price = price;
    }

    public void powerOn() {
        System.out.println("Device is turning on.");
    }

    public void powerOff() {
        System.out.println("Device is turning off.");
    }

    public void displayInfo() {
        System.out.printf("Brand: %s, Price: %s%n", brand, price);
    }
}
