package com.school.inheritance;

public class TestShape {
    public static void main(String[] args) {
        System.out.println("--- Shape 1 ---");
        Circle circle = new Circle("Red", 5.0);
        circle.displayInfo();
        System.out.println();

        System.out.println("--- Shape 2 ---");
        Rectangle rectangle = new Rectangle("Blue", 8.0, 5.0);
        rectangle.displayInfo();
    }
}
