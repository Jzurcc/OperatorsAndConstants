package com.school.inheritance;

public class TestPerson {
    public static void main(String[] args) {
        System.out.println("--- Person ---");
        Person person = new Person("Maria Santos", 45);
        person.displayInfo();
        System.out.println();

        System.out.println("--- Student 1 ---");
        Student student1 = new Student("Alice Reyes", 20, "BSIT", 3.8);
        student1.displayInfo();
        System.out.println();

        System.out.println("--- Student 2 ---");
        Student student2 = new Student("Bob Cruz", 22, "BSCS", 1.8);
        student2.displayInfo();
    }
}
