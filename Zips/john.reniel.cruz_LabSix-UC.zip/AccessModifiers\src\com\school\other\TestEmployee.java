package com.school.other;

import com.school.access.Employee;

public class TestEmployee {
    public static void main(String[] args) {
        Employee emp = new Employee();
        System.out.println("=== Access Modifier Test from com.school.other ===");
        System.out.println();
        // emp.department → ERROR: department has protected access in Employee (not a subclass)
        // emp.position   → ERROR: position is not public; cannot be accessed from outside package
        // emp.salary     → ERROR: salary has private access in Employee
        System.out.printf("[public] emp.name: %s  --> ACCESSIBLE%n", emp.name);
        System.out.println("[protected] emp.department          --> NOT ACCESSIBLE (not a subclass, different package)");
        System.out.println("[default] emp.position              --> NOT ACCESSIBLE (different package)");
        System.out.println("[private] emp.salary                --> NOT ACCESSIBLE (private to Employee class only)");
        System.out.println("[public] emp.displayInfo():");
        emp.displayInfo();
    }
}
