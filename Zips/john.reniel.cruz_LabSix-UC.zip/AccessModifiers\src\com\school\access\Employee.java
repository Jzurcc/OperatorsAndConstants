package com.school.access;

public class Employee {
    public String name = "Juan Dela Cruz";
    protected String department = "Engineering";
    String position = "Developer";
    private double salary = 75000.00;

    public void displayInfo() {
        System.out.println("=== Employee Info ===");
        System.out.printf("[public]    Name: %s%n", name);
        System.out.printf("[protected] Department: %s%n", department);
        System.out.printf("[default]   Position: %s%n", position);
        System.out.printf("[private]   Salary: %s%n", salary);
    }

    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.displayInfo();
    }
}
