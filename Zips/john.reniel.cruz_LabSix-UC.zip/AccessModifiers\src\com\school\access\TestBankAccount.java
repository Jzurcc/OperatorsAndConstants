package com.school.access;

public class TestBankAccount {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        // account.balance → ERROR: balance has private access in BankAccount
        // account.accountNumber → ERROR: accountNumber has private access in BankAccount
        System.out.printf("Account: %s%n", account.getAccountNumber());
        System.out.printf("Balance: %s%n", account.getBalance());
        account.deposit(10000.0);
    }
}
