package com.school.other;

import com.school.access.Person;
import com.school.access.Animal;

public class TestFromOutside {
    public static void main(String[] args) {
        System.out.println("--- Accessing Person from a different package ---");
        Person person = new Person();
        System.out.printf("Name: %s%n", person.name);
        System.out.printf("Age: %s%n", person.age);
        System.out.println(person.greet());

        System.out.println();
        System.out.println("--- Testing protected access from non-subclass in different package ---");
        Animal animal = new Animal();
        // animal.species   → ERROR: species has protected access in Animal
        // animal.describe() → ERROR: describe() has protected access in Animal
        System.out.println("Cannot access protected members from a non-subclass in a different package.");
    }
}
