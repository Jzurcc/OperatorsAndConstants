package com.school.access;

public class TestProduct {
    public static void main(String[] args) {
        Product product = new Product();
        System.out.printf("Product: %s%n", product.productName);
        System.out.printf("Price: %s%n", product.price);
        System.out.printf("Stock: %s%n", product.stock);
        System.out.printf("Info: %s%n", product.getInfo());
    }
}
