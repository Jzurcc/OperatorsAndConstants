package com.school.access.sub;

import com.school.access.Animal;

public class Dog extends Animal {
    public Dog() {
        species = "Dog";
        legs = 4;
    }

    @Override
    public String describe() {
        return super.describe();
    }

    public String bark() {
        return "Woof! I am a " + species;
    }
}
