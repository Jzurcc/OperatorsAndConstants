package com.school.access.sub;

public class TestDog {
    public static void main(String[] args) {
        Dog dog = new Dog();
        System.out.printf("Description: %s%n", dog.describe());
        System.out.printf("Bark: %s%n", dog.bark());
    }
}
