package com.school.access;

public class Product {
    String productName = "Laptop";
    double price = 45999.00;
    int stock = 15;

    String getInfo() {
        return productName + " - " + price + " (" + stock + " in stock)";
    }
}
