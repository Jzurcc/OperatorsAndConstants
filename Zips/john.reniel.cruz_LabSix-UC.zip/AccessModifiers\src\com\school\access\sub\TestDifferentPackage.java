package com.school.access.sub;

import com.school.access.Product;

public class TestDifferentPackage {
    public static void main(String[] args) {
        Product product = new Product();
        // product.productName → ERROR: productName is not public; cannot be accessed from outside package
        // product.price       → ERROR: price is not public; cannot be accessed from outside package
        // product.getInfo()   → ERROR: getInfo() is not public; cannot be accessed from outside package
        System.out.println("--- Testing default access from a different package ---");
        System.out.println("Cannot access default members from outside the package.");
        System.out.println("Default (package-private) members are only visible within com.school.access.");
    }
}
