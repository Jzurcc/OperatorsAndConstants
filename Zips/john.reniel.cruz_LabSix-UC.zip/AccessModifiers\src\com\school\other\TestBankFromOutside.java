package com.school.other;

import com.school.access.BankAccount;

public class TestBankFromOutside {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        // account.balance → ERROR: balance has private access in BankAccount
        System.out.println("--- Accessing BankAccount from a different package ---");
        System.out.printf("Account (via getter): %s%n", account.getAccountNumber());
        System.out.printf("Balance (via getter): %s%n", account.getBalance());
    }
}
