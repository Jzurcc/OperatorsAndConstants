package com.school.access;

public class TestSameClass {
    public static void main(String[] args) {
        Person person = new Person();
        System.out.printf("Name: %s%n", person.name);
        System.out.printf("Age: %s%n", person.age);
        System.out.println(person.greet());
    }
}
