package com.school.abstraction;

public class TestPayment {
    public static void main(String[] args) {
        System.out.println("--- Credit Card Payment ---");
        PaymentProcessor cc = new CreditCardPayment("Alice", 1500.0, "1234567890125678");
        cc.processPayment();
        System.out.println();

        System.out.println("--- GCash Payment ---");
        PaymentProcessor gcash = new GCashPayment("Bob", 850.0, "09171234567");
        gcash.processPayment();
        System.out.println();

        System.out.println("--- Invalid Credit Card ---");
        PaymentProcessor invalidCc = new CreditCardPayment("Charlie", 500.0, "12345");
        invalidCc.processPayment();
    }
}
