package com.school.abstraction;

public class ConsoleLogger implements Loggable {
    @Override
    public void log(String message) {
        System.out.printf("[CONSOLE] %s%n", message);
    }

    @Override
    public void logError(String message) {
        System.out.printf("!!! CONSOLE ERROR: %s !!!%n", message);
    }
}
