package com.school.abstraction;

public class Fish extends Animal implements Swimmable {
    public Fish(String name, String species) {
        super(name, species);
    }

    @Override
    public void makeSound() {
        System.out.println("Blub blub!");
    }

    @Override
    public void swim() {
        System.out.printf("%s is swimming. Max depth: %sm%n", name, getMaxDepthMeters());
    }

    @Override
    public int getMaxDepthMeters() {
        return 200;
    }
}
