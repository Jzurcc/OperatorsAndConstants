package com.school.abstraction;

public class FullTimeEmployee extends Employee implements Billable, Trackable {
    double monthlySalary;
    int hoursWorked;

    public FullTimeEmployee(String name, int id, double monthlySalary, int hoursWorked) {
        super(name, id);
        this.monthlySalary = monthlySalary;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateBill() {
        return monthlySalary;
    }

    @Override
    public String getBillingType() {
        return "Monthly Salary";
    }

    @Override
    public int getHoursWorked() {
        return hoursWorked;
    }
}
