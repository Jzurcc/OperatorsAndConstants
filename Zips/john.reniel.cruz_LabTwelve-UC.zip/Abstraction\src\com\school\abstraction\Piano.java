package com.school.abstraction;

public class Piano implements Playable {
    int keys;

    public Piano(int keys) {
        this.keys = keys;
    }

    @Override
    public void play() {
        System.out.printf("Playing %s (%s keys) \u2014 pressing keys...%n", getInstrumentName(), keys);
    }

    @Override
    public void stop() {
        System.out.printf("Stopping %s.%n", getInstrumentName());
    }

    @Override
    public String getInstrumentName() {
        return "Piano";
    }
}
