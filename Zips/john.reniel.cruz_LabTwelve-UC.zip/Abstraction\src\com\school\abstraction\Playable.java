package com.school.abstraction;

public interface Playable {
    void play();
    void stop();
    String getInstrumentName();
}
