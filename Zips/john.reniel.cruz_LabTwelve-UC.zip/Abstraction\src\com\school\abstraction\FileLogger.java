package com.school.abstraction;

public class FileLogger implements Loggable {
    @Override
    public void log(String message) {
        System.out.printf("[FILE] %s%n", message);
    }
}
