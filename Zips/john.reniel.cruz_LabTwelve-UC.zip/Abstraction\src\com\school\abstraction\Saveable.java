package com.school.abstraction;

public interface Saveable {
    void save(String filename);
    
    static String getDefaultPath() {
        return "/documents/reports/";
    }
    
    default void autoSave() {
        System.out.printf("Auto-saving to %sautosave.txt%n", getDefaultPath());
    }
}
