package com.school.abstraction;

public abstract class Animal {
    String name;
    String species;

    public Animal(String name, String species) {
        this.name = name;
        this.species = species;
    }

    public abstract void makeSound();

    public void displayInfo() {
        System.out.printf("Name: %s, Species: %s%n", name, species);
    }
}
