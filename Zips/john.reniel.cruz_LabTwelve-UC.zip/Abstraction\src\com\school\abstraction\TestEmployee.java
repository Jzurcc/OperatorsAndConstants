package com.school.abstraction;

public class TestEmployee {
    public static void main(String[] args) {
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Alice Santos", 1, 55000.0, 160);
        Freelancer freelancer = new Freelancer("Bob Garcia", 2, 400.0, 120);

        Billable[] billables = { fullTimeEmployee, freelancer };
        Trackable[] trackables = { fullTimeEmployee, freelancer };

        System.out.println("--- Billing ---");
        for (Billable b : billables) {
            System.out.println(b.formatBill());
        }
        System.out.println();

        System.out.println("--- Productivity ---");
        for (int i = 0; i < trackables.length; i++) {
            System.out.printf("%s (%s hrs): %s%n", ((Employee)trackables[i]).name, trackables[i].getHoursWorked(), trackables[i].getProductivityLevel());
        }
        System.out.println();

        System.out.println("--- Tax calculation (static method) ---");
        for (Billable b : billables) {
            System.out.printf("Tax on %s at %s: %s%n", b.calculateBill(), (b instanceof FullTimeEmployee ? "12%" : "10%"), String.format("%.2f", Billable.calculateTax(b.calculateBill(), b instanceof FullTimeEmployee ? 0.12 : 0.10)));
        }
        System.out.println();

        // Exercise 10: Putting it all together
        Employee[] team = { fullTimeEmployee, freelancer };

        System.out.println("========================================");
        System.out.println("       TEAM SUMMARY REPORT");
        System.out.println("========================================");
        System.out.println();

        double totalPayroll = 0.0;

        for (Employee emp : team) {
            emp.displayInfo();
            if (emp instanceof FullTimeEmployee) {
                System.out.println("  Type: Full-Time Employee");
                System.out.printf("  %s%n", ((FullTimeEmployee) emp).formatBill());
            } else if (emp instanceof Freelancer) {
                System.out.println("  Type: Freelancer");
                System.out.printf("  %s: PHP %s x %s hrs = PHP %s%n", ((Freelancer) emp).getBillingType(), String.format("%.2f", ((Freelancer) emp).hourlyRate), ((Freelancer) emp).getHoursWorked(), String.format("%.2f", ((Freelancer) emp).calculateBill()));
            }

            if (emp instanceof Trackable) {
                Trackable t = (Trackable) emp;
                System.out.printf("  Hours: %s | Productivity: %s%n", t.getHoursWorked(), t.getProductivityLevel());
            }
            System.out.println();

            if (emp instanceof Billable) {
                totalPayroll += ((Billable) emp).calculateBill();
            }
        }

        double totalTax = Billable.calculateTax(totalPayroll, 0.12);
        double netPayroll = totalPayroll - totalTax;

        System.out.println("========================================");
        System.out.printf("Total payroll: PHP %s%n", String.format("%.2f", totalPayroll));
        System.out.printf("Tax (12%%): PHP %s%n", String.format("%.2f", totalTax));
        System.out.printf("Net payroll: PHP %s%n", String.format("%.2f", netPayroll));
        System.out.println("========================================");
    }
}
