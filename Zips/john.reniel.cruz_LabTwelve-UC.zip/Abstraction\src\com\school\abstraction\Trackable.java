package com.school.abstraction;

public interface Trackable {
    int getHoursWorked();

    default String getProductivityLevel() {
        int hours = getHoursWorked();
        if (hours >= 160) {
            return "High";
        } else if (hours >= 120) {
            return "Normal";
        } else {
            return "Low";
        }
    }
}
