package com.school.abstraction;

public class TestLoggable {
    public static void main(String[] args) {
        System.out.println("--- FileLogger ---");
        FileLogger fileLogger = new FileLogger();
        fileLogger.log("System started.");
        fileLogger.logInfo("All services running.");
        fileLogger.logWarning("Disk space low.");
        fileLogger.logError("Connection timeout.");
        System.out.println();

        System.out.println("--- ConsoleLogger ---");
        ConsoleLogger consoleLogger = new ConsoleLogger();
        consoleLogger.log("System started.");
        consoleLogger.logInfo("All services running.");
        consoleLogger.logWarning("Disk space low.");
        consoleLogger.logError("Connection timeout.");
    }
}
