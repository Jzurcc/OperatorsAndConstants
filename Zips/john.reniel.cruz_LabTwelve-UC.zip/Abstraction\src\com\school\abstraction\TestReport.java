package com.school.abstraction;

public class TestReport {
    public static void main(String[] args) {
        Report report = new Report("Monthly Sales", "Sales increased by 15% this quarter.", "Maria Santos");
        report.print();
        System.out.println();
        report.save("monthly_sales.pdf");
        report.autoSave();
        System.out.printf("Default path: %s%n", Saveable.getDefaultPath());
    }
}
