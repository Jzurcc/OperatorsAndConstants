package com.school.abstraction;

public interface Loggable {
    void log(String message);
    
    default void logInfo(String message) {
        System.out.printf("[INFO] %s%n", message);
    }
    
    default void logWarning(String message) {
        System.out.printf("[WARNING] %s%n", message);
    }
    
    default void logError(String message) {
        System.out.printf("[ERROR] %s%n", message);
    }
}
