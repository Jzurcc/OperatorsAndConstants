package com.school.abstraction;

public interface Chargeable {
    void charge();

    default int getChargingTimeMinutes() {
        return 120;
    }

    static String getChargingStandard() {
        return "CCS Type 2";
    }
}
