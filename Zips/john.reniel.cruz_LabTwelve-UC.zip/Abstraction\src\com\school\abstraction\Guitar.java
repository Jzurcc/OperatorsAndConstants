package com.school.abstraction;

public class Guitar implements Playable {
    String type;

    public Guitar(String type) {
        this.type = type;
    }

    @Override
    public void play() {
        System.out.printf("Playing %s \u2014 strumming chords...%n", getInstrumentName());
    }

    @Override
    public void stop() {
        System.out.printf("Stopping %s.%n", getInstrumentName());
    }

    @Override
    public String getInstrumentName() {
        return type + " Guitar";
    }
}
