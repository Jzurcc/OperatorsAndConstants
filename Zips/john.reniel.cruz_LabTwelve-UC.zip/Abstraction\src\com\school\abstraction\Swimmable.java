package com.school.abstraction;

public interface Swimmable {
    void swim();
    
    default int getMaxDepthMeters() {
        return 10;
    }
}
