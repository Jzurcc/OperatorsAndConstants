package com.school.abstraction;

public class GCashPayment extends PaymentProcessor {
    String phoneNumber;

    public GCashPayment(String payerName, double amount, String phoneNumber) {
        super(payerName, amount);
        this.phoneNumber = phoneNumber;
    }

    @Override
    protected boolean authorize() {
        return phoneNumber != null && phoneNumber.startsWith("09") && phoneNumber.length() == 11;
    }

    @Override
    protected void executePayment() {
        System.out.printf("Sent to GCash %s.%n", phoneNumber);
    }

    @Override
    public String getPaymentMethod() {
        return "GCash";
    }
}
