package com.school.abstraction;

public class ElectricCar extends Vehicle implements Chargeable {
    public ElectricCar(String brand, double price, int fuelLevel) {
        super(brand, price, fuelLevel);
    }

    @Override
    public void drive() {
        if (fuelLevel >= 20) {
            fuelLevel -= 20;
            System.out.printf("Driving... Fuel level: %s%%%n", fuelLevel);
        } else {
            System.out.println("Not enough battery to drive.");
        }
    }

    @Override
    public String getFuelType() {
        return "Electric";
    }

    @Override
    public void charge() {
        fuelLevel = 100;
        System.out.printf("Charging... Fuel level: %s%%%n", fuelLevel);
        System.out.printf("Charging time: %s minutes%n", getChargingTimeMinutes());
    }

    @Override
    public int getChargingTimeMinutes() {
        return 45;
    }
}
