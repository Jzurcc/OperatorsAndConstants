package com.school.abstraction;

public class Freelancer extends Employee implements Billable, Trackable {
    double hourlyRate;
    int hoursWorked;

    public Freelancer(String name, int id, double hourlyRate, int hoursWorked) {
        super(name, id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateBill() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public String getBillingType() {
        return "Hourly Rate";
    }

    @Override
    public int getHoursWorked() {
        return hoursWorked;
    }
}
