package com.school.abstraction;

public abstract class Shape {
    String color;

    public Shape(String color) {
        this.color = color;
    }

    public abstract double getArea();
    public abstract double getPerimeter();

    public void displayInfo() {
        System.out.printf("Color: %s%n", color);
        System.out.printf("Area: %s%n", String.format("%.2f", getArea()));
        System.out.printf("Perimeter: %s%n", String.format("%.2f", getPerimeter()));
    }
}
