package com.school.abstraction;

public class AgeValidator implements Validator {
    @Override
    public boolean validate(String input) {
        try {
            int age = Integer.parseInt(input);
            if (age >= 0 && age <= 150) {
                return true;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return false;
    }

    @Override
    public String getValidationType() {
        return "Age";
    }
}
