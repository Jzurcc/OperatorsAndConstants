package com.school.abstraction;

public class GasCar extends Vehicle {
    public GasCar(String brand, double price, int fuelLevel) {
        super(brand, price, fuelLevel);
    }

    @Override
    public void drive() {
        if (fuelLevel >= 20) {
            fuelLevel -= 20;
            System.out.printf("Driving... Fuel level: %s%%%n", fuelLevel);
        } else {
            System.out.println("Not enough fuel to drive.");
        }
    }

    @Override
    public String getFuelType() {
        return "Gasoline";
    }

    public void refuel() {
        fuelLevel = 100;
        System.out.printf("Refueling... Fuel level: %s%%%n", fuelLevel);
    }
}
