package com.school.abstraction;

public interface Billable {
    double calculateBill();
    String getBillingType();

    default String formatBill() {
        return getBillingType() + ": PHP " + String.format("%.2f", calculateBill());
    }

    static double calculateTax(double amount, double rate) {
        return amount * rate;
    }
}
