package com.school.abstraction;

public class TestAnimal {
    public static void main(String[] args) {
        System.out.println("--- Duck ---");
        Duck duck = new Duck("Donald", "Duck");
        duck.displayInfo();
        duck.makeSound();
        duck.swim();
        duck.fly();
        System.out.println();

        System.out.println("--- Eagle ---");
        Eagle eagle = new Eagle("Aguila", "Eagle");
        eagle.displayInfo();
        eagle.makeSound();
        eagle.fly();
        System.out.println();

        System.out.println("--- Fish ---");
        Fish fish = new Fish("Nemo", "Clownfish");
        fish.displayInfo();
        fish.makeSound();
        fish.swim();
    }
}
