package com.school.abstraction;

public interface Validator {
    boolean validate(String input);
    String getValidationType();

    static void printResult(String type, String input, boolean result) {
        if (result) {
            System.out.printf("[%s] '%s' \u2192 VALID%n", type, input);
        } else {
            System.out.printf("[%s] '%s' \u2192 INVALID%n", type, input);
        }
    }

    default void validateAndPrint(String input) {
        boolean result = validate(input);
        printResult(getValidationType(), input, result);
    }
}
