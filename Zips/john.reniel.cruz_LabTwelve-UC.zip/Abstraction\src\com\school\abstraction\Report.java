package com.school.abstraction;

public class Report implements Printable, Saveable {
    String title;
    String content;
    String author;

    public Report(String title, String content, String author) {
        this.title = title;
        this.content = content;
        this.author = author;
    }

    @Override
    public void print() {
        printHeader();
        System.out.printf("Title: %s%n", title);
        System.out.printf("Author: %s%n", author);
        System.out.printf("Content: %s%n", content);
        printFooter();
    }

    @Override
    public void save(String filename) {
        System.out.printf("Saving report to %s...%n", filename);
    }
}
