package com.school.abstraction;

public interface Flyable {
    void fly();
    
    default int getMaxAltitudeMeters() {
        return 1000;
    }
}
