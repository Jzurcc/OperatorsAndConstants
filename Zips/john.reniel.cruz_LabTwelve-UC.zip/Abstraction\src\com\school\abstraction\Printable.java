package com.school.abstraction;

public interface Printable {
    void print();
    
    default void printHeader() {
        System.out.println("====== REPORT ======");
    }
    
    default void printFooter() {
        System.out.println("====== END ======");
    }
}
