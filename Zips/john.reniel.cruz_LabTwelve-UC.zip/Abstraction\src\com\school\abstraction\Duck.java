package com.school.abstraction;

public class Duck extends Animal implements Swimmable, Flyable {
    public Duck(String name, String species) {
        super(name, species);
    }

    @Override
    public void makeSound() {
        System.out.println("Quack quack!");
    }

    @Override
    public void swim() {
        System.out.printf("%s is swimming. Max depth: %sm%n", name, getMaxDepthMeters());
    }

    @Override
    public void fly() {
        System.out.printf("%s is flying. Max altitude: %sm%n", name, getMaxAltitudeMeters());
    }
}
