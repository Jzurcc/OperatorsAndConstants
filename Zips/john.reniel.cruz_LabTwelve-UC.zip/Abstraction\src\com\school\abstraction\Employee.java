package com.school.abstraction;

public abstract class Employee {
    String name;
    int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public void displayInfo() {
        System.out.printf("[ID: %s] %s%n", id, name);
    }
}
