package com.school.abstraction;

public class Eagle extends Animal implements Flyable {
    public Eagle(String name, String species) {
        super(name, species);
    }

    @Override
    public void makeSound() {
        System.out.println("Screech!");
    }

    @Override
    public void fly() {
        System.out.printf("%s is flying. Max altitude: %sm%n", name, getMaxAltitudeMeters());
    }

    @Override
    public int getMaxAltitudeMeters() {
        return 3000;
    }
}
