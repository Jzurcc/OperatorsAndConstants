package com.school.abstraction;

public class TestVehicle {
    public static void main(String[] args) {
        System.out.println("--- Gas Car ---");
        GasCar gasCar = new GasCar("Toyota", 950000.0, 50);
        gasCar.displayInfo();
        gasCar.drive();
        gasCar.refuel();
        System.out.println();

        System.out.println("--- Electric Car ---");
        ElectricCar electricCar = new ElectricCar("Tesla", 2500000.0, 40);
        electricCar.displayInfo();
        electricCar.drive();
        electricCar.charge();
        System.out.println();

        System.out.printf("Charging standard: %s%n", Chargeable.getChargingStandard());
    }
}
