package com.school.abstraction;

public class TestValidator {
    public static void main(String[] args) {
        System.out.println("--- Email validation ---");
        Validator emailVal = new EmailValidator();
        emailVal.validateAndPrint("alice@email.com");
        emailVal.validateAndPrint("not-an-email");
        emailVal.validateAndPrint("bob@test.org");
        System.out.println();

        System.out.println("--- Age validation ---");
        Validator ageVal = new AgeValidator();
        ageVal.validateAndPrint("25");
        ageVal.validateAndPrint("-5");
        ageVal.validateAndPrint("abc");
        ageVal.validateAndPrint("150");
        System.out.println();

        System.out.println("--- Using static method directly ---");
        Validator.printResult("Custom", "test", true);
    }
}
