package com.school.abstraction;

public class CreditCardPayment extends PaymentProcessor {
    String cardNumber;

    public CreditCardPayment(String payerName, double amount, String cardNumber) {
        super(payerName, amount);
        this.cardNumber = cardNumber;
    }

    @Override
    protected boolean authorize() {
        return cardNumber != null && cardNumber.length() == 16;
    }

    @Override
    protected void executePayment() {
        String last4 = cardNumber.substring(cardNumber.length() - 4);
        System.out.printf("Charged to card ending in %s.%n", last4);
    }

    @Override
    public String getPaymentMethod() {
        return "Credit Card";
    }
}
