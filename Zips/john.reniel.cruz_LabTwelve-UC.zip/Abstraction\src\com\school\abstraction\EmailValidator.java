package com.school.abstraction;

public class EmailValidator implements Validator {
    @Override
    public boolean validate(String input) {
        if (input != null && input.contains("@") && input.contains(".")) {
            return true;
        }
        return false;
    }

    @Override
    public String getValidationType() {
        return "Email";
    }
}
