package com.school.abstraction;

public class TestPlayable {
    public static void main(String[] args) {
        Playable[] instruments = new Playable[2];
        instruments[0] = new Guitar("Acoustic");
        instruments[1] = new Piano(88);

        for (Playable p : instruments) {
            p.play();
        }
        System.out.println();
        for (Playable p : instruments) {
            p.stop();
        }
    }
}
