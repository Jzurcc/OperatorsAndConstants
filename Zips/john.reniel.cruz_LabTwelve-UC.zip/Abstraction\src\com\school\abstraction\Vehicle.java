package com.school.abstraction;

public abstract class Vehicle {
    String brand;
    double price;
    int fuelLevel;

    public Vehicle(String brand, double price, int fuelLevel) {
        this.brand = brand;
        this.price = price;
        this.fuelLevel = fuelLevel;
    }

    public abstract void drive();
    public abstract String getFuelType();

    public void displayInfo() {
        System.out.printf("Brand: %s, Price: %s, Fuel: %s%n", brand, price, getFuelType());
        System.out.printf("Fuel level: %s%%%n", fuelLevel);
    }
}
