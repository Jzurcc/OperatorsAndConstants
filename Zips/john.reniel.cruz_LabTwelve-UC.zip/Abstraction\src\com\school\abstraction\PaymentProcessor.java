package com.school.abstraction;

public abstract class PaymentProcessor {
    String payerName;
    double amount;

    public PaymentProcessor(String payerName, double amount) {
        this.payerName = payerName;
        this.amount = amount;
    }

    protected abstract boolean authorize();
    protected abstract void executePayment();
    public abstract String getPaymentMethod();

    public final void processPayment() {
        System.out.printf("Processing %s payment of %s for %s...%n", getPaymentMethod(), amount, payerName);
        System.out.println("Authorizing...");
        if (!authorize()) {
            System.out.println("Authorization failed. Payment cancelled.");
            return;
        }
        executePayment();
        System.out.println("Payment successful!");
    }
}
