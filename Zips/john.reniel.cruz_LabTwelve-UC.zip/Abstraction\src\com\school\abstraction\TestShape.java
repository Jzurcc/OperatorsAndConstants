package com.school.abstraction;

public class TestShape {
    public static void main(String[] args) {
        // Shape s = new Shape("Red"); // \u2192 ERROR: Shape is abstract; cannot be instantiated

        System.out.println("--- Circle ---");
        Circle circle = new Circle("Red", 5.0);
        circle.displayInfo();
        System.out.println();

        System.out.println("--- Rectangle ---");
        Rectangle rectangle = new Rectangle("Blue", 8.0, 5.0);
        rectangle.displayInfo();
    }
}
