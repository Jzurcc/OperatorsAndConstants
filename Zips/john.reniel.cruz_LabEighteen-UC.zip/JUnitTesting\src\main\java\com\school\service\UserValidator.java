package com.school.service;

public class UserValidator {
    public boolean isValidUsername(String username) {
        if (username == null) return false;
        if (username.length() < 5 || username.length() > 15) return false;
        return username.matches("[a-zA-Z0-9]+");
    }

    public boolean isValidEmail(String email) {
        if (email == null) return false;
        int atIndex = email.indexOf('@');
        if (atIndex == -1 || atIndex != email.lastIndexOf('@')) return false;
        int dotIndex = email.indexOf('.', atIndex);
        return dotIndex > atIndex + 1 && dotIndex < email.length() - 1;
    }

    public boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasDigit = false;
        boolean hasUpper = false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) hasDigit = true;
            if (Character.isUpperCase(c)) hasUpper = true;
        }
        return hasDigit && hasUpper;
    }

    public boolean isValidAge(int age) {
        return age >= 18 && age <= 120;
    }
}
