package com.school.app;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ShoppingCartTest {
    private ShoppingCart cart;

    @BeforeEach
    void setUp() {
        cart = new ShoppingCart();
        cart.addItem("Apple", 1.50);
        cart.addItem("Bread", 2.00);
    }

    @AfterEach
    void tearDown() {
        cart.clear();
        System.out.println("Cart cleared after test.");
    }

    @Test
    void testAddItem() {
        cart.addItem("Milk", 3.00);
        assertEquals(3, cart.getItemCount());
        assertEquals(6.50, cart.getTotal(), 0.001);
    }

    @Test
    void testRemoveItem() {
        assertTrue(cart.removeItem("Apple"));
        assertEquals(1, cart.getItemCount());
    }

    @Test
    void testRemoveNonExistent() {
        assertFalse(cart.removeItem("Pizza"));
    }

    @Test
    void testGetTotal() {
        assertEquals(3.50, cart.getTotal(), 0.001);
    }

    @Test
    void testClear() {
        cart.clear();
        assertEquals(0, cart.getItemCount());
        assertEquals(0.0, cart.getTotal(), 0.001);
    }
}
