package com.school.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Calculator \u2014 Full Operation Suite")
class CalculatorDisplayTest {
    private Calculator calc;

    @BeforeEach
    void setUp() {
        calc = new Calculator();
    }

    @Test
    @DisplayName("3 + 4 should equal 7")
    void testAdd() {
        assertEquals(7, calc.add(3, 4));
    }

    @Test
    @DisplayName("-1 + 1 should equal 0")
    void testAddNegative() {
        assertEquals(0, calc.add(-1, 1));
    }

    @Test
    @DisplayName("10 - 3 should equal 7")
    void testSubtract() {
        assertEquals(7, calc.subtract(10, 3));
    }

    @Test
    @DisplayName("5 \u00d7 6 should equal 30")
    void testMultiply() {
        assertEquals(30, calc.multiply(5, 6));
    }

    @Test
    @DisplayName("10 \u00f7 2 should equal 5.0")
    void testDivide() {
        assertEquals(5.0, calc.divide(10, 2), 0.0001);
    }

    @Test
    @DisplayName("Dividing by zero should throw ArithmeticException")
    void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> calc.divide(5, 0));
    }

    @Test
    @Disabled("Feature not yet implemented \u2014 modulo for doubles")
    @DisplayName("Feature not yet implemented \u2014 modulo for doubles")
    void testModuloDoubles() {
    }
}
