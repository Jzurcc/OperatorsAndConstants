package com.school.service;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

class UserValidatorParamTest {
    private final UserValidator validator = new UserValidator();

    @ParameterizedTest
    @CsvSource({
        "alice99, true",
        "ab, false",
        "toolongusername123, false",
        "ValidName1, true",
        "'bad user!', false"
    })
    void testUsernameValidity(String username, boolean expected) {
        assertEquals(expected, validator.isValidUsername(username));
    }

    @ParameterizedTest
    @CsvSource({
        "user@example.com, true",
        "noatsign, false",
        "bad@, false",
        "hello@world.org, true"
    })
    void testEmailValidity(String email, boolean expected) {
        assertEquals(expected, validator.isValidEmail(email));
    }

    @ParameterizedTest
    @CsvSource({
        "Secure42!, true",
        "password, false",
        "Short1A, false",
        "GoodPass123, true"
    })
    void testPasswordValidity(String password, boolean expected) {
        assertEquals(expected, validator.isValidPassword(password));
    }

    @ParameterizedTest
    @ValueSource(ints = {18, 25, 99, 120})
    void testAgeValidTrue(int age) {
        assertTrue(validator.isValidAge(age));
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 17, 121, -5})
    void testAgeValidFalse(int age) {
        assertFalse(validator.isValidAge(age));
    }
}
