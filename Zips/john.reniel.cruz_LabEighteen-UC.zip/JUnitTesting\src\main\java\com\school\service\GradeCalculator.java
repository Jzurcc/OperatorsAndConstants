package com.school.service;

public class GradeCalculator {
    public double average(double[] scores) {
        if (scores == null || scores.length == 0) {
            throw new IllegalArgumentException("Scores array cannot be null or empty");
        }
        double sum = 0;
        for (double score : scores) {
            sum += score;
        }
        return sum / scores.length;
    }

    public String letterGrade(double score) {
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100");
        }
        if (score >= 90) return "A";
        if (score >= 80) return "B";
        if (score >= 70) return "C";
        if (score >= 60) return "D";
        return "F";
    }

    public boolean isPassing(double score) {
        return score >= 75;
    }

    public double highest(double[] scores) {
        if (scores == null || scores.length == 0) {
            throw new IllegalArgumentException("Scores array cannot be null or empty");
        }
        double max = scores[0];
        for (double score : scores) {
            if (score > max) max = score;
        }
        return max;
    }

    public double lowest(double[] scores) {
        if (scores == null || scores.length == 0) {
            throw new IllegalArgumentException("Scores array cannot be null or empty");
        }
        double min = scores[0];
        for (double score : scores) {
            if (score < min) min = score;
        }
        return min;
    }
}
