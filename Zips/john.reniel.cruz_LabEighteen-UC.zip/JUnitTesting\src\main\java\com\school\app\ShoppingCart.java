package com.school.app;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private static class Item {
        String name;
        double price;
        Item(String name, double price) {
            this.name = name;
            this.price = price;
        }
    }

    private List<Item> items = new ArrayList<>();

    public void addItem(String name, double price) {
        items.add(new Item(name, price));
    }

    public boolean removeItem(String name) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).name.equals(name)) {
                items.remove(i);
                return true;
            }
        }
        return false;
    }

    public double getTotal() {
        double total = 0;
        for (Item item : items) {
            total += item.price;
        }
        return total;
    }

    public int getItemCount() {
        return items.size();
    }

    public void clear() {
        items.clear();
    }
}
