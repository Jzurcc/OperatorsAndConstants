package com.school.app;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BankAccountTest {

    @Test
    void testInitialState() {
        BankAccount account = new BankAccount("Alice", 1000.0);
        assertAll("Initial State",
            () -> assertNotNull(account.getOwner()),
            () -> assertEquals("Alice", account.getOwner()),
            () -> assertEquals(1000.0, account.getBalance())
        );
    }

    @Test
    void testDeposit() {
        BankAccount account = new BankAccount("Bob", 1000.0);
        account.deposit(500.0);
        assertAll("Deposit State",
            () -> assertEquals(1500.0, account.getBalance()),
            () -> assertNotEquals(1000.0, account.getBalance()),
            () -> assertTrue(account.getBalance() >= 0)
        );
    }

    @Test
    void testWithdraw() {
        BankAccount account = new BankAccount("Charlie", 1000.0);
        account.withdraw(200.0);
        assertEquals(800.0, account.getBalance());
    }

    @Test
    void testDepositNegativeThrows() {
        BankAccount account = new BankAccount("Diana", 1000.0);
        assertThrows(IllegalArgumentException.class, () -> account.deposit(-100.0));
    }

    @Test
    void testOverdraftThrows() {
        BankAccount account = new BankAccount("Edward", 1000.0);
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(1500.0));
    }
}
