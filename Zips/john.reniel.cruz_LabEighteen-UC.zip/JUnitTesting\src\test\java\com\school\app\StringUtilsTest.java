package com.school.app;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    @Test
    void testIsPalindromeTrue() {
        assertTrue(StringUtils.isPalindrome("racecar"));
        assertTrue(StringUtils.isPalindrome("Madam"));
    }

    @Test
    void testIsPalindromeFalse() {
        assertFalse(StringUtils.isPalindrome("hello"));
    }

    @Test
    void testReverse() {
        assertEquals("avaJ", StringUtils.reverse("Java"));
    }

    @Test
    void testCountVowels() {
        assertEquals(3, StringUtils.countVowels("Hello World"));
    }

    @Test
    void testIsNullOrEmpty() {
        assertTrue(StringUtils.isNullOrEmpty(null));
        assertTrue(StringUtils.isNullOrEmpty(""));
        assertFalse(StringUtils.isNullOrEmpty("Hi"));
    }

    @Test
    void testCapitalize() {
        assertEquals("Java", StringUtils.capitalize("java"));
    }
}
