package com.school.service;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

class TemperatureConverterTest {
    private final TemperatureConverter converter = new TemperatureConverter();

    @ParameterizedTest
    @ValueSource(doubles = {0, 100, -40, 37})
    void testCelsiusToFahrenheitNotNull(double celsius) {
        double fahrenheit = converter.celsiusToFahrenheit(celsius);
        // It's primitive so not null, but checking it's greater than -500
        assertTrue(fahrenheit > -500);
    }

    @ParameterizedTest
    @CsvSource({
        "0, 32.0",
        "100, 212.0",
        "-40, -40.0"
    })
    void testCelsiusToFahrenheitExact(double celsius, double expectedFahrenheit) {
        assertEquals(expectedFahrenheit, converter.celsiusToFahrenheit(celsius), 0.001);
    }

    @ParameterizedTest
    @CsvSource({
        "32, 0.0",
        "212, 100.0",
        "98.6, 37.0"
    })
    void testFahrenheitToCelsiusExact(double fahrenheit, double expectedCelsius) {
        assertEquals(expectedCelsius, converter.fahrenheitToCelsius(fahrenheit), 0.001);
    }

    @ParameterizedTest
    @CsvSource({
        "0, 273.15",
        "100, 373.15"
    })
    void testCelsiusToKelvin(double celsius, double expectedKelvin) {
        assertEquals(expectedKelvin, converter.celsiusToKelvin(celsius), 0.001);
    }
}
