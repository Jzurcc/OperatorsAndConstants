package com.school.app;

import java.util.ArrayList;
import java.util.List;

public class Library {
    private static class Book {
        String title;
        String author;
        int year;

        Book(String title, String author, int year) {
            this.title = title;
            this.author = author;
            this.year = year;
        }
    }

    private List<Book> books = new ArrayList<>();

    public void addBook(String title, String author, int year) {
        if (title == null || title.isEmpty() || year < 1000) {
            throw new IllegalArgumentException("Invalid book data");
        }
        books.add(new Book(title, author, year));
    }

    public boolean removeBook(String title) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).title.equals(title)) {
                books.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean hasBook(String title) {
        for (Book b : books) {
            if (b.title.equals(title)) return true;
        }
        return false;
    }

    public int getBookCount() {
        return books.size();
    }

    public List<String> searchByAuthor(String author) {
        List<String> result = new ArrayList<>();
        if (author == null) return result;
        String search = author.toLowerCase();
        for (Book b : books) {
            if (b.author != null && b.author.toLowerCase().equals(search)) {
                result.add(b.title);
            }
        }
        return result;
    }

    public List<String> getBooksAfterYear(int year) {
        List<String> result = new ArrayList<>();
        for (Book b : books) {
            if (b.year > year) {
                result.add(b.title);
            }
        }
        return result;
    }
}
