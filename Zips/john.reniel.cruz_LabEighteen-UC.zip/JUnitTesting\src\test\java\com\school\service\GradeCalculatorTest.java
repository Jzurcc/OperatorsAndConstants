package com.school.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GradeCalculatorTest {
    private GradeCalculator calc;
    private double[] sampleScores;

    @BeforeEach
    void setUp() {
        calc = new GradeCalculator();
        sampleScores = new double[]{85, 92, 78, 60, 95};
    }

    @Test
    void testAverage() {
        assertEquals(82.0, calc.average(sampleScores), 0.001);
    }

    @Test
    void testAverageEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> calc.average(new double[]{}));
    }

    @Test
    void testLetterGrade() {
        assertEquals("A", calc.letterGrade(95));
        assertEquals("B", calc.letterGrade(82));
        assertEquals("F", calc.letterGrade(55));
    }

    @Test
    void testLetterGradeInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> calc.letterGrade(-1));
        assertThrows(IllegalArgumentException.class, () -> calc.letterGrade(101));
    }

    @Test
    void testIsPassing() {
        assertTrue(calc.isPassing(75));
        assertFalse(calc.isPassing(74));
    }

    @Test
    void testHighestAndLowest() {
        assertEquals(95.0, calc.highest(sampleScores), 0.001);
        assertEquals(60.0, calc.lowest(sampleScores), 0.001);
    }
}
