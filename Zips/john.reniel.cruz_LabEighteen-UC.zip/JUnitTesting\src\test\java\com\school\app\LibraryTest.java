package com.school.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LibraryTest {
    private Library library;

    @BeforeEach
    void setUp() {
        library = new Library();
        library.addBook("The Hobbit", "J.R.R. Tolkien", 1937);
        library.addBook("1984", "George Orwell", 1949);
        library.addBook("Animal Farm", "George Orwell", 1945);
        library.addBook("Dune", "Frank Herbert", 1965);
    }

    @Test
    @DisplayName("Adding a valid book should increase count")
    void testAddBook() {
        library.addBook("Foundation", "Isaac Asimov", 1951);
        assertEquals(5, library.getBookCount());
    }

    @Test
    void testAddBookInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> library.addBook(null, "Author", 2000));
        assertThrows(IllegalArgumentException.class, () -> library.addBook("", "Author", 2000));
        assertThrows(IllegalArgumentException.class, () -> library.addBook("Title", "Author", 999));
    }

    @Test
    void testRemoveBook() {
        assertTrue(library.removeBook("1984"));
        assertFalse(library.hasBook("1984"));
        assertEquals(3, library.getBookCount());
    }

    @Test
    void testRemoveNonExistentBook() {
        assertFalse(library.removeBook("Non Existent"));
    }

    @Test
    void testHasBook() {
        assertTrue(library.hasBook("Dune"));
        assertFalse(library.hasBook("Harry Potter"));
    }

    @ParameterizedTest
    @CsvSource({
        "'George Orwell', 2",
        "'J.R.R. Tolkien', 1",
        "'Unknown Author', 0"
    })
    void testSearchByAuthor(String author, int expectedCount) {
        List<String> books = library.searchByAuthor(author);
        assertEquals(expectedCount, books.size());
    }

    @Test
    void testGetBooksAfterYear() {
        List<String> recentBooks = library.getBooksAfterYear(1950);
        assertEquals(1, recentBooks.size());
        assertTrue(recentBooks.contains("Dune"));
    }

    @Test
    void testLibraryState() {
        assertAll("Library State Check",
            () -> assertEquals(4, library.getBookCount()),
            () -> assertTrue(library.hasBook("The Hobbit")),
            () -> assertFalse(library.hasBook("Unknown Book"))
        );
    }
}
