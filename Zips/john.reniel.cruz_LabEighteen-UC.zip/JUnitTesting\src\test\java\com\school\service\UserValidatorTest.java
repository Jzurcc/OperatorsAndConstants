package com.school.service;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserValidatorTest {
    private final UserValidator validator = new UserValidator();

    @BeforeAll
    static void setup() {
        System.out.println("=== UserValidator tests starting ===");
    }

    @AfterAll
    static void teardown() {
        System.out.println("=== UserValidator tests completed ===");
    }

    @Test
    void testValidUsername() {
        assertTrue(validator.isValidUsername("alice99"));
        assertFalse(validator.isValidUsername("ab"));
        assertFalse(validator.isValidUsername("this_user!name"));
    }

    @Test
    void testValidEmail() {
        assertTrue(validator.isValidEmail("user@example.com"));
        assertFalse(validator.isValidEmail("noatsign"));
        assertFalse(validator.isValidEmail("bad@"));
    }

    @Test
    void testValidPassword() {
        assertTrue(validator.isValidPassword("Secure42!"));
        assertFalse(validator.isValidPassword("password"));
        assertFalse(validator.isValidPassword("Short1A"));
    }

    @Test
    void testValidAge() {
        assertTrue(validator.isValidAge(25));
        assertTrue(validator.isValidAge(18));
        assertFalse(validator.isValidAge(17));
        assertFalse(validator.isValidAge(121));
    }
}
