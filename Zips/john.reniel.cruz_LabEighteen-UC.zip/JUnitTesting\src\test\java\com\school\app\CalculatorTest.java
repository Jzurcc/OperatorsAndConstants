package com.school.app;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {
    private final Calculator calc = new Calculator();

    @Test
    void testAdd() {
        assertEquals(7, calc.add(3, 4));
        assertEquals(0, calc.add(-1, 1));
    }

    @Test
    void testSubtract() {
        assertEquals(7, calc.subtract(10, 3));
    }

    @Test
    void testMultiply() {
        assertEquals(30, calc.multiply(5, 6));
        assertEquals(0, calc.multiply(0, 99));
    }

    @Test
    void testDivide() {
        assertEquals(5.0, calc.divide(10, 2), 0.0001);
    }

    @Test
    void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> calc.divide(5, 0));
    }

    @Test
    void testMod() {
        assertEquals(1, calc.mod(10, 3));
    }
}
