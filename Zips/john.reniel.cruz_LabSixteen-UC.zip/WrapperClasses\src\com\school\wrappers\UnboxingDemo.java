package com.school.wrappers;

public class UnboxingDemo {
    public static int addPrimitives(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        Integer wrapped = 42;
        int unwrapped = wrapped;

        System.out.println("--- Auto-unboxing ---");
        System.out.printf("Wrapped: %s (Integer)%n", wrapped);
        System.out.printf("Unwrapped: %s (int)%n", unwrapped);
        System.out.println();

        System.out.println("--- In arithmetic ---");
        Integer a = 50;
        int result = a * 2;
        System.out.printf("Integer a = %s%n", a);
        System.out.printf("a * 2 = %s%n", result);
        System.out.println();

        System.out.println("--- In conditional ---");
        Boolean flag = true;
        System.out.printf("Boolean flag = %s%n", flag);
        if (flag) {
            System.out.println("Flag is true!");
        }
        System.out.println();

        System.out.println("--- In method call ---");
        Integer num1 = 10;
        Integer num2 = 20;
        System.out.printf("addPrimitives(Integer %s, Integer %s) = %s%n", num1, num2, addPrimitives(num1, num2));
        System.out.println();

        System.out.println("--- Explicit unboxing ---");
        System.out.printf("Integer \u2192 intValue(): %s%n", wrapped.intValue());
        Double d = 3.14;
        System.out.printf("Double \u2192 doubleValue(): %s%n", d.doubleValue());
        System.out.printf("Boolean \u2192 booleanValue(): %s%n", flag.booleanValue());
    }
}
