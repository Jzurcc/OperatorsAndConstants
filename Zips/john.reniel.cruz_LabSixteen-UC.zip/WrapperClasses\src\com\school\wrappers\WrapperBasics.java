package com.school.wrappers;

public class WrapperBasics {
    public static void main(String[] args) {
        Byte myByte = Byte.valueOf((byte) 120);
        Short myShort = Short.valueOf((short) 30000);
        Integer myInt = Integer.valueOf(1500000);
        Long myLong = Long.valueOf(9876543210L);
        Float myFloat = Float.valueOf(3.14f);
        Double myDouble = Double.valueOf(9.80665);
        Character myChar = Character.valueOf('A');
        Boolean myBool = Boolean.valueOf(true);

        System.out.printf("Byte: %s (class: %s)%n", myByte, myByte.getClass().getSimpleName());
        System.out.printf("Short: %s (class: %s)%n", myShort, myShort.getClass().getSimpleName());
        System.out.printf("Integer: %s (class: %s)%n", myInt, myInt.getClass().getSimpleName());
        System.out.printf("Long: %s (class: %s)%n", myLong, myLong.getClass().getSimpleName());
        System.out.printf("Float: %s (class: %s)%n", myFloat, myFloat.getClass().getSimpleName());
        System.out.printf("Double: %s (class: %s)%n", myDouble, myDouble.getClass().getSimpleName());
        System.out.printf("Character: %s (class: %s)%n", myChar, myChar.getClass().getSimpleName());
        System.out.printf("Boolean: %s (class: %s)%n", myBool, myBool.getClass().getSimpleName());
    }
}
