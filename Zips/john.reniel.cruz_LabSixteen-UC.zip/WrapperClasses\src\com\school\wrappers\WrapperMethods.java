package com.school.wrappers;

public class WrapperMethods {
    public static void main(String[] args) {
        System.out.println("--- Integer methods ---");
        System.out.printf("MAX_VALUE: %s%n", Integer.MAX_VALUE);
        System.out.printf("MIN_VALUE: %s%n", Integer.MIN_VALUE);
        System.out.printf("42 in binary: %s%n", Integer.toBinaryString(42));
        System.out.printf("42 in octal: %s%n", Integer.toOctalString(42));
        System.out.printf("42 in hex: %s%n", Integer.toHexString(42));
        System.out.printf("max(10, 20): %s%n", Integer.max(10, 20));
        System.out.printf("min(10, 20): %s%n", Integer.min(10, 20));
        System.out.printf("sum(10, 20): %s%n", Integer.sum(10, 20));
        System.out.println();

        System.out.println("--- Double methods ---");
        System.out.printf("MAX_VALUE: %s%n", Double.MAX_VALUE);
        System.out.printf("MIN_VALUE: %s%n", Double.MIN_VALUE);
        System.out.printf("isNaN(0.0/0.0): %s%n", Double.isNaN(0.0 / 0.0));
        System.out.printf("isInfinite(1.0/0.0): %s%n", Double.isInfinite(1.0 / 0.0));
        System.out.println();

        System.out.println("--- Character methods ---");
        System.out.printf("isLetter('A'): %s%n", Character.isLetter('A'));
        System.out.printf("isDigit('5'): %s%n", Character.isDigit('5'));
        System.out.printf("isUpperCase('a'): %s%n", Character.isUpperCase('a'));
        System.out.printf("toUpperCase('a'): %s%n", Character.toUpperCase('a'));
        System.out.printf("toLowerCase('Z'): %s%n", Character.toLowerCase('Z'));
    }
}
