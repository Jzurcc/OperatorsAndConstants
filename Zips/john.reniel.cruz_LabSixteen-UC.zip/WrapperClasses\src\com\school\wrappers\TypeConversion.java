package com.school.wrappers;

public class TypeConversion {
    public static void main(String[] args) {
        System.out.println("--- Wrapper to different type ---");
        Integer num = 42;
        double d = num.doubleValue();
        System.out.printf("Integer 42 \u2192 doubleValue(): %s%n", d);

        Double price = 99.99;
        int rounded = price.intValue();
        System.out.printf("Double 99.99 \u2192 intValue(): %s (truncated!)%n", rounded);

        Float f = 3.14f;
        long l = f.longValue();
        System.out.printf("Float 3.14 \u2192 longValue(): %s%n", l);
        System.out.println();

        System.out.println("--- Number \u2194 String ---");
        String s = Integer.toString(42);
        System.out.printf("int 42 \u2192 String: \"%s\"%n", s);
        
        int n = Integer.parseInt("42");
        System.out.printf("String \"42\" \u2192 int: %s%n", n);

        int result = (int) Double.parseDouble("99.7");
        System.out.printf("String \"99.7\" \u2192 int: %s%n", result);
        System.out.println();

        System.out.println("--- Radix conversions ---");
        System.out.printf("42 \u2192 binary: \"%s\"%n", Integer.toBinaryString(42));
        System.out.printf("42 \u2192 hex: \"%s\"%n", Integer.toHexString(42));
        System.out.printf("binary \"101010\" \u2192 int: %s%n", Integer.parseInt("101010", 2));
        System.out.printf("hex \"2a\" \u2192 int: %s%n", Integer.parseInt("2a", 16));
    }
}
