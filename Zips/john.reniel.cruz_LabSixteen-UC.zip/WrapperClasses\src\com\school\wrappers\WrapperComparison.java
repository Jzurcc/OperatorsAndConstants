package com.school.wrappers;

public class WrapperComparison {
    public static void main(String[] args) {
        System.out.println("--- Integer caching trap ---");
        Integer a = 100;
        Integer b = 100;
        System.out.println("a = 100, b = 100");
        System.out.printf("a == b: %s (cached \u2014 same object)%n", (a == b));
        System.out.println();

        Integer c = 200;
        Integer d = 200;
        System.out.println("c = 200, d = 200");
        System.out.printf("c == d: %s (NOT cached \u2014 different objects!)%n", (c == d));
        System.out.println();

        System.out.println("--- Safe comparison with .equals() ---");
        System.out.printf("a.equals(b): %s%n", a.equals(b));
        System.out.printf("c.equals(d): %s%n", c.equals(d));
        System.out.println();

        System.out.println("--- compareTo() ---");
        Integer x = 10;
        Integer y = 20;
        Integer z = 10;
        System.out.printf("10.compareTo(20): %s (less than)%n", x.compareTo(y));
        System.out.printf("20.compareTo(10): %s (greater than)%n", y.compareTo(x));
        System.out.printf("10.compareTo(10): %s (equal)%n", x.compareTo(z));
    }
}
