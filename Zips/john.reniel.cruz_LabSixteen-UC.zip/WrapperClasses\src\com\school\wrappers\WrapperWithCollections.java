package com.school.wrappers;

import java.util.*;

public class WrapperWithCollections {
    public static void main(String[] args) {
        System.out.println("--- ArrayList<Integer> ---");
        ArrayList<Integer> scores = new ArrayList<>();
        scores.add(85);
        scores.add(92);
        scores.add(78);
        scores.add(95);
        scores.add(88);

        System.out.printf("Scores: %s%n", scores);
        int firstElement = scores.get(0);
        System.out.printf("Element at index 0: %s (auto-unboxed to int)%n", firstElement);
        System.out.println();

        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        System.out.printf("Sum: %s%n", sum);
        System.out.printf("Max: %s%n", Collections.max(scores));
        
        Collections.sort(scores);
        System.out.printf("Sorted: %s%n", scores);
        System.out.println();

        System.out.println("--- HashMap<String, Double> ---");
        HashMap<String, Double> prices = new HashMap<>();
        prices.put("Laptop", 45999.0);
        prices.put("Mouse", 599.0);
        prices.put("Keyboard", 1299.0);

        System.out.printf("Prices: %s%n", prices);
        double laptopPrice = prices.get("Laptop");
        System.out.printf("Laptop price: %s (auto-unboxed to double)%n", laptopPrice);
    }
}
