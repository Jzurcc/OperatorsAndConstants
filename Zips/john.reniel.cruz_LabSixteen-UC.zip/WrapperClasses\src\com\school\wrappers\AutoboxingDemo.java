package com.school.wrappers;

public class AutoboxingDemo {
    public static void main(String[] args) {
        Integer a = 100;
        Double b = 3.14;
        Boolean c = true;
        Character d = 'Z';

        System.out.println("--- Autoboxing ---");
        System.out.printf("a = %s (%s)%n", a, a.getClass().getSimpleName());
        System.out.printf("b = %s (%s)%n", b, b.getClass().getSimpleName());
        System.out.printf("c = %s (%s)%n", c, c.getClass().getSimpleName());
        System.out.printf("d = %s (%s)%n", d, d.getClass().getSimpleName());
        System.out.println();

        System.out.println("--- Autoboxing in expressions ---");
        Integer x = 10;
        Integer y = 20;
        Integer sum = x + y;
        System.out.printf("x = %s, y = %s%n", x, y);
        System.out.printf("x + y = %s (%s)%n", sum, sum.getClass().getSimpleName());
    }
}
