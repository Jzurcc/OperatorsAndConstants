package com.school.wrappers;

public class NullSafety {
    public static int safeUnbox(Integer value, int defaultValue) {
        if (value != null) {
            return value;
        }
        return defaultValue;
    }

    public static void main(String[] args) {
        System.out.println("--- Null unboxing trap ---");
        Integer num = null;
        System.out.println("Integer num = null");
        System.out.println("Attempting int value = num...");
        try {
            int value = num;
        } catch (NullPointerException e) {
            System.out.println("NullPointerException! Cannot unbox null to int.");
        }
        System.out.println();

        System.out.println("--- Null boolean trap ---");
        Boolean flag = null;
        System.out.println("Boolean flag = null");
        System.out.println("Attempting if (flag)...");
        try {
            if (flag) {
                System.out.println("Flag is true");
            }
        } catch (NullPointerException e) {
            System.out.println("NullPointerException! Cannot unbox null to boolean.");
        }
        System.out.println();

        System.out.println("--- Safe unboxing ---");
        System.out.printf("safeUnbox(42, 0) = %s%n", safeUnbox(42, 0));
        System.out.printf("safeUnbox(null, 0) = %s%n", safeUnbox(null, 0));
        System.out.printf("safeUnbox(null, -1) = %s%n", safeUnbox(null, -1));
    }
}
