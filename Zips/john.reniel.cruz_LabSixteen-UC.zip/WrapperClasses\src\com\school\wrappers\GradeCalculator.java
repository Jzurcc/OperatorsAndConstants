package com.school.wrappers;

import java.util.ArrayList;
import java.util.Collections;

public class GradeCalculator {
    public static void main(String[] args) {
        String[] inputs = {"88.5", "92", "abc", "76.0", "", "95", null, "81.5"};
        ArrayList<Double> validGrades = new ArrayList<>();

        System.out.println("--- Parsing grades ---");
        for (int i = 0; i < inputs.length; i++) {
            String input = inputs[i];
            if (input == null) {
                System.out.printf("[%s] null \u2192 WARNING: Null input, skipped%n", i);
                continue;
            }
            if (input.isEmpty()) {
                System.out.printf("[%s] \"\" \u2192 WARNING: Empty input, skipped%n", i);
                continue;
            }

            try {
                double grade = Double.parseDouble(input);
                validGrades.add(grade);
                System.out.printf("[%s] \"%s\" \u2192 %s \u2713%n", i, input, grade);
            } catch (NumberFormatException e) {
                System.out.printf("[%s] \"%s\" \u2192 ERROR: Invalid number%n", i, input);
            }
        }
        System.out.println();
        System.out.printf("Valid grades: %s%n", validGrades);
        System.out.printf("Total parsed: %s of %s%n", validGrades.size(), inputs.length);
        System.out.println();

        System.out.println("========================================");
        System.out.println("         GRADE REPORT");
        System.out.println("========================================");

        double sum = 0;
        for (double grade : validGrades) {
            sum += grade;
        }
        int count = validGrades.size();
        double average = sum / count;
        Double max = Collections.max(validGrades);
        Double min = Collections.min(validGrades);

        System.out.printf("Sum: %s%n", sum);
        System.out.printf("Count: %s%n", count);
        System.out.printf("Average: %s%n", average);
        System.out.printf("Highest: %s%n", max);
        System.out.printf("Lowest: %s%n", min);

        Double avgObj = average;
        Double threshold = 85.0;
        String above85 = (avgObj.compareTo(threshold) > 0) ? "Yes" : "No";
        System.out.printf("Above 85 average? %s%n", above85);

        Collections.sort(validGrades);
        System.out.printf("Sorted: %s%n", validGrades);
        System.out.println("========================================");
    }
}
