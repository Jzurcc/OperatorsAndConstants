package com.school.wrappers;

public class ParsingStrings {
    public static void main(String[] args) {
        int age = Integer.parseInt("25");
        double price = Double.parseDouble("1299.99");
        long population = Long.parseLong("7900000000");
        float rate = Float.parseFloat("4.5");
        boolean active = Boolean.parseBoolean("true");

        System.out.println("--- Parsing strings ---");
        System.out.printf("\"25\" \u2192 int: %s%n", age);
        System.out.printf("\"1299.99\" \u2192 double: %s%n", price);
        System.out.printf("\"7900000000\" \u2192 long: %s%n", population);
        System.out.printf("\"4.5\" \u2192 float: %s%n", rate);
        System.out.printf("\"true\" \u2192 boolean: %s%n", active);
        System.out.println();

        System.out.println("--- Parsing errors ---");
        try {
            int err1 = Integer.parseInt("abc");
        } catch (NumberFormatException e) {
            System.out.printf("\"abc\" \u2192 NumberFormatException: %s%n", e.getMessage());
        }

        try {
            int err2 = Integer.parseInt("12.5");
        } catch (NumberFormatException e) {
            System.out.printf("\"12.5\" \u2192 NumberFormatException: %s%n", e.getMessage());
        }

        try {
            int err3 = Integer.parseInt("");
        } catch (NumberFormatException e) {
            System.out.printf("\"\" \u2192 NumberFormatException: %s%n", e.getMessage());
        }
        System.out.println();

        System.out.println("--- Number to string ---");
        System.out.printf("String.valueOf(42): \"%s\"%n", String.valueOf(42));
        System.out.printf("Integer.toString(42): \"%s\"%n", Integer.toString(42));
        System.out.printf("\"\" + 42: \"%s\"%n", ("" + 42));
    }
}
