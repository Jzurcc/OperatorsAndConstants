package com.school.operators;

public class UnaryOperators {
    public static void main(String[] args) {
        int x = 10;
        boolean isActive = false;

        System.out.printf("Unary plus: +10 = %s%n", (+x));
        System.out.printf("Unary minus: -10 = %s%n", (-x));
        
        System.out.printf("Pre-increment: ++x = %s, x is now %s%n", (++x), x);
        System.out.printf("Post-increment: x++ = %s, x is now %s%n", (x++), x);
        System.out.printf("Pre-decrement: --x = %s, x is now %s%n", (--x), x);
        System.out.printf("Post-decrement: x-- = %s, x is now %s%n", (x--), x);
        
        System.out.printf("NOT isActive: %s%n", (!isActive));
    }
}
