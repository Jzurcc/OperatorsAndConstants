package com.school.operators;

public class MiniCalculator {
    static final double DISCOUNT_RATE = 0.10;

    public static void main(String[] args) {
        double itemPrice = 2500.00;
        int quantity = 3;
        
        double subtotal = itemPrice * quantity;
        double discount = subtotal * DISCOUNT_RATE;
        double total = subtotal - discount;
        
        String note = total > 5000 ? "Premium purchase" : "Standard purchase";
        boolean isExpensive = total > 5000;
        
        System.out.printf("Item price: %s%n", itemPrice);
        System.out.printf("Quantity: %s%n", quantity);
        System.out.printf("Subtotal: %s%n", subtotal);
        System.out.printf("Discount (10%%): %s%n", discount);
        System.out.printf("Total: %s%n", total);
        System.out.printf("Note: %s%n", note);
        System.out.printf("Is expensive: %s%n", isExpensive);
    }
}
