package com.school.operators;

public class ArithmeticOperators {
    public static void main(String[] args) {
        int a = 48;
        int b = 13;
        System.out.printf("48 + 13 = %d%n", (a + b));
        System.out.printf("48 - 13 = %d%n", (a - b));
        System.out.printf("48 * 13 = %d%n", (a * b));
        System.out.printf("48 / 13 = %d%n", (a / b));
        System.out.printf("48 %% 13 = %d%n", (a % b));
    }
}
