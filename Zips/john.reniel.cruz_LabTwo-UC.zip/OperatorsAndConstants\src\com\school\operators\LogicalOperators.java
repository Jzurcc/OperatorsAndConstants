package com.school.operators;

public class LogicalOperators {
    public static void main(String[] args) {
        boolean hasID = true;
        boolean hasTicket = false;
        boolean isVIP = true;

        System.out.printf("hasID && hasTicket: %s%n", (hasID && hasTicket));
        System.out.printf("hasID || hasTicket: %s%n", (hasID || hasTicket));
        System.out.printf("!hasTicket: %s%n", (!hasTicket));
        System.out.printf("(hasID && hasTicket) || isVIP: %s%n", ((hasID && hasTicket) || isVIP));
        System.out.printf("!(hasID && isVIP): %s%n", (!(hasID && isVIP)));
    }
}
