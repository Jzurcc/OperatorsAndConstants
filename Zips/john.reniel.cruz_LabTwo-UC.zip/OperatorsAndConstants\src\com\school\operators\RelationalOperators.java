package com.school.operators;

public class RelationalOperators {
    public static void main(String[] args) {
        int a = 20;
        int b = 35;
        
        System.out.printf("a == b: %s%n", (a == b));
        System.out.printf("a != b: %s%n", (a != b));
        System.out.printf("a > b: %s%n", (a > b));
        System.out.printf("a < b: %s%n", (a < b));
        System.out.printf("a >= b: %s%n", (a >= b));
        System.out.printf("a <= b: %s%n", (a <= b));
    }
}
