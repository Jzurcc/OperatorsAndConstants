package com.school.operators;

public class TernaryOperator {
    public static void main(String[] args) {
        int age = 17;
        int score = 82;
        int temperature = 30;

        String category = age >= 18 ? "Adult" : "Minor";
        String result = score >= 75 ? "Passed" : "Failed";
        String weather = temperature >= 30 ? "Hot" : "Cool";

        System.out.printf("Age 17: %s%n", category);
        System.out.printf("Score 82: %s%n", result);
        System.out.printf("Temperature 30: %s%n", weather);
    }
}
