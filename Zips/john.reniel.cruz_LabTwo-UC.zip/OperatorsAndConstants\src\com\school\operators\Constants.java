package com.school.operators;

public class Constants {
    static final double TAX_RATE = 0.12;
    static final int PASSING_SCORE = 75;
    static final String CURRENCY = "PHP";

    public static void main(String[] args) {
        double price = 1500.00;
        double taxAmount = price * TAX_RATE;
        double total = price + taxAmount;
        
        System.out.printf("Price: %s %s%n", price, CURRENCY);
        System.out.printf("Tax rate: %s%n", TAX_RATE);
        System.out.printf("Tax amount: %s %s%n", taxAmount, CURRENCY);
        System.out.printf("Total: %s %s%n", total, CURRENCY);
        System.out.printf("Passing score: %s%n", PASSING_SCORE);
    }
}
