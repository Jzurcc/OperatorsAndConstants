package com.school.operators;

public class BitwiseOperators {
    public static void main(String[] args) {
        int a = 12;
        int b = 10;
        
        System.out.printf("12 & 10 = %s%n", (a & b));
        System.out.printf("12 | 10 = %s%n", (a | b));
        System.out.printf("12 ^ 10 = %s%n", (a ^ b));
        System.out.printf("~12 = %s%n", (~a));
        System.out.printf("12 << 2 = %s%n", (a << 2));
        System.out.printf("12 >> 2 = %s%n", (a >> 2));
    }
}
