package com.school.operators;

public class AssignmentOperators {
    public static void main(String[] args) {
        int score = 100;
        System.out.printf("Initial score: %s%n", score);
        score += 10;
        System.out.printf("After += 10: %s%n", score);
        score -= 25;
        System.out.printf("After -= 25: %s%n", score);
        score *= 2;
        System.out.printf("After *= 2: %s%n", score);
        score /= 5;
        System.out.printf("After /= 5: %s%n", score);
        score %= 7;
        System.out.printf("After %= 7: %s%n", score);
    }
}
