package com.school.operators;

public class OperatorPrecedence {
    public static void main(String[] args) {
        int r1 = 10 + 5 * 3;
        int r2 = (10 + 5) * 3;
        int r3 = 20 - 4 / 2 + 1;
        int r4 = 20 - 4 % 3 + 2;
        boolean r5 = 5 > 3 && 10 < 20;
        boolean r6 = 5 > 3 || 10 > 20;

        System.out.printf("10 + 5 * 3 = %s%n", r1);
        System.out.printf("(10 + 5) * 3 = %s%n", r2);
        System.out.printf("20 - 4 / 2 + 1 = %s%n", r3);
        System.out.printf("20 - 4 %% 3 + 2 = %s%n", r4);
        System.out.printf("5 > 3 && 10 < 20 = %s%n", r5);
        System.out.printf("5 > 3 || 10 > 20 = %s%n", r6);
    }
}
