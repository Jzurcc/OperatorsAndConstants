package com.school.arrays;

public class ArraySearch {
    public static void main(String[] args) {
        String[] names = {"Alice", "Bob", "Charlie", "Diana", "Edward", "Fiona"};
        String searchName = "Diana";
        String notFoundName = "Zara";

        search(names, searchName);
        System.out.println();
        search(names, notFoundName);
    }

    static void search(String[] names, String target) {
        System.out.printf("Searching for \"%s\"...%n", target);
        boolean found = false;
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(target)) {
                System.out.printf("Found \"%s\" at index %s.%n", target, i);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.printf("\"%s\" was not found in the array.%n", target);
        }
    }
}
