package com.school.arrays;

import java.util.Arrays;

public class ArraySort {
    public static void main(String[] args) {
        int[] scores = {72, 95, 48, 81, 67, 90, 55};
        String[] fruits = {"Mango", "Apple", "Cherry", "Banana", "Elderberry"};

        System.out.println("--- Before sorting ---");
        System.out.printf("Scores: %s%n", Arrays.toString(scores));
        System.out.printf("Fruits: %s%n", Arrays.toString(fruits));
        System.out.println();

        Arrays.sort(scores);
        Arrays.sort(fruits);

        System.out.println("--- After sorting ---");
        System.out.printf("Scores: %s%n", Arrays.toString(scores));
        System.out.printf("Fruits: %s%n", Arrays.toString(fruits));
    }
}
