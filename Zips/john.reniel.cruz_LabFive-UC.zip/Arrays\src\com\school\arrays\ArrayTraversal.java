package com.school.arrays;

public class ArrayTraversal {
    public static void main(String[] args) {
        double[] prices = {129.99, 249.50, 89.00, 549.99, 199.75};

        System.out.println("--- Using for loop ---");
        for (int i = 0; i < prices.length; i++) {
            System.out.printf("prices[%s] = %s%n", i, prices[i]);
        }
        System.out.println();

        System.out.println("--- Using enhanced for loop ---");
        for (double price : prices) {
            System.out.printf("Price: %s%n", price);
        }
    }
}
