package com.school.arrays;

public class ArrayDeclaration {
    public static void main(String[] args) {
        int[] numbers = new int[5];
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;

        System.out.println("--- numbers[] ---");
        for (int i = 0; i < numbers.length; i++) {
            System.out.printf("numbers[%s] = %s%n", i, numbers[i]);
        }

        System.out.println();

        String[] colors = {"Red", "Green", "Blue", "Yellow", "White"};

        System.out.println("--- colors[] ---");
        for (int i = 0; i < colors.length; i++) {
            System.out.printf("colors[%s] = %s%n", i, colors[i]);
        }
    }
}
