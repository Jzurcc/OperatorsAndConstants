package com.school.arrays;

public class ArrayInitialization {
    public static void main(String[] args) {
        int[] intArr = new int[3];
        double[] doubleArr = new double[3];
        boolean[] boolArr = new boolean[3];
        char[] charArr = new char[3];
        String[] strArr = new String[3];

        System.out.println("--- int defaults ---");
        for (int i = 0; i < intArr.length; i++) {
            System.out.printf("intArr[%s] = %s%n", i, intArr[i]);
        }
        System.out.println();

        System.out.println("--- double defaults ---");
        for (int i = 0; i < doubleArr.length; i++) {
            System.out.printf("doubleArr[%s] = %s%n", i, doubleArr[i]);
        }
        System.out.println();

        System.out.println("--- boolean defaults ---");
        for (int i = 0; i < boolArr.length; i++) {
            System.out.printf("boolArr[%s] = %s%n", i, boolArr[i]);
        }
        System.out.println();

        System.out.println("--- char defaults ---");
        for (int i = 0; i < charArr.length; i++) {
            System.out.printf("charArr[%s] = %s%n", i, charArr[i]);
        }
        System.out.println();

        System.out.println("--- String defaults ---");
        for (int i = 0; i < strArr.length; i++) {
            System.out.printf("strArr[%s] = %s%n", i, strArr[i]);
        }
    }
}
