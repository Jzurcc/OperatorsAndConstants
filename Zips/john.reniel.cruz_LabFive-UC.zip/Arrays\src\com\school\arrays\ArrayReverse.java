package com.school.arrays;

public class ArrayReverse {
    public static void main(String[] args) {
        int[] original = {10, 20, 30, 40, 50, 60};

        System.out.print("Original: ");
        for (int n : original) System.out.print(n + " ");
        System.out.println();

        int[] reversed = new int[original.length];
        for (int i = 0; i < original.length; i++) {
            reversed[i] = original[original.length - 1 - i];
        }

        System.out.print("Reversed: ");
        for (int n : reversed) System.out.print(n + " ");
        System.out.println();
    }
}
