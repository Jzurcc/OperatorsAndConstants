package com.school.arrays;

public class ArrayMinMax {
    public static void main(String[] args) {
        int[] temperatures = {32, 28, 35, 41, 27, 39, 33};

        System.out.println("Daily temperatures:");
        for (int i = 0; i < temperatures.length; i++) {
            System.out.printf("  Day %s: %s\u00b0C%n", i, temperatures[i]);
        }
        System.out.println();

        int maxTemp = temperatures[0], maxDay = 0;
        int minTemp = temperatures[0], minDay = 0;

        for (int i = 1; i < temperatures.length; i++) {
            if (temperatures[i] > maxTemp) { maxTemp = temperatures[i]; maxDay = i; }
            if (temperatures[i] < minTemp) { minTemp = temperatures[i]; minDay = i; }
        }

        System.out.printf("Highest: %s\u00b0C (Day %s)%n", maxTemp, maxDay);
        System.out.printf("Lowest: %s\u00b0C (Day %s)%n", minTemp, minDay);
        System.out.printf("Difference: %s\u00b0C%n", (maxTemp - minTemp));
    }
}
