package com.school.arrays;

import java.util.Arrays;

public class StudentGrades {
    static final double PASSING_GRADE = 75.0;

    public static void main(String[] args) {
        String[] students = {"Alice", "Bob", "Charlie", "Diana", "Edward"};
        double[] grades = {88.5, 62.0, 91.0, 74.5, 95.5};

        System.out.println("========================================");
        System.out.println("         STUDENT GRADES REPORT");
        System.out.println("========================================");
        System.out.println();
        System.out.printf("%-13s%-9s%s%n", "Name", "Grade", "Status");
        System.out.printf("%-13s%-9s%s%n", "----", "-----", "------");

        for (int i = 0; i < students.length; i++) {
            String status = grades[i] >= PASSING_GRADE ? "Passed" : "Failed";
            System.out.printf("%-13s%-9s%s%n", students[i], grades[i], status);
        }
        System.out.println();

        double total = 0;
        for (double g : grades) total += g;
        double avg = total / grades.length;
        System.out.printf("Class average: %s%n", avg);

        double highest = grades[0]; int highIdx = 0;
        double lowest  = grades[0]; int lowIdx  = 0;
        for (int i = 1; i < grades.length; i++) {
            if (grades[i] > highest) { highest = grades[i]; highIdx = i; }
            if (grades[i] < lowest)  { lowest  = grades[i]; lowIdx  = i; }
        }
        System.out.printf("Highest grade: %s (%s)%n", highest, students[highIdx]);
        System.out.printf("Lowest grade: %s (%s)%n", lowest, students[lowIdx]);
        System.out.println();

        int passed = 0, failed = 0;
        for (double g : grades) {
            if (g >= PASSING_GRADE) passed++; else failed++;
        }
        System.out.printf("Passed: %s student(s)%n", passed);
        System.out.printf("Failed: %s student(s)%n", failed);
        System.out.println();

        double[] sortedGrades = Arrays.copyOf(grades, grades.length);
        Arrays.sort(sortedGrades);
        System.out.printf("Grades sorted: %s%n", Arrays.toString(sortedGrades));
        System.out.println("========================================");
    }
}
