package com.school.arrays;

public class ArrayModify {
    public static void main(String[] args) {
        int[] scores = {78, 55, 92, 41, 88};
        int bonusPoints = 10;

        System.out.println("--- Original scores ---");
        for (int s : scores) System.out.print(s + " ");
        System.out.println();
        System.out.println();

        for (int i = 0; i < scores.length; i++) {
            scores[i] += bonusPoints;
        }

        System.out.println("--- After adding 10 bonus points ---");
        for (int s : scores) System.out.print(s + " ");
        System.out.println();
        System.out.println();

        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > 100) scores[i] = 100;
        }

        System.out.println("--- After capping at 100 ---");
        for (int s : scores) System.out.print(s + " ");
        System.out.println();
    }
}
