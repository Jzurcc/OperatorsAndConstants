package com.school.arrays;

public class ArrayLength {
    public static void main(String[] args) {
        int[] sales = {12000, 15500, 9800, 21000, 17300, 11200};

        System.out.println("Monthly sales data:");
        int sum = 0;
        for (int i = 0; i < sales.length; i++) {
            System.out.printf("  Month %s: %s%n", (i + 1), sales[i]);
            sum += sales[i];
        }
        System.out.println();
        System.out.printf("Total months: %s%n", sales.length);
        System.out.printf("Total sales: %s%n", sum);
        System.out.printf("Average monthly sales: %s%n", (sum / sales.length));
    }
}
