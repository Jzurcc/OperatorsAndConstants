package com.school.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

public class StudentRegistry {
    public static void enroll(String name, double gpa, String course, ArrayList<String> order, HashSet<String> unique, HashMap<String, Double> grades, TreeMap<String, String> courses) {
        if (unique.contains(name)) {
            System.out.printf("Error: %s is already enrolled.%n", name);
            return;
        }
        unique.add(name);
        order.add(name);
        grades.put(name, gpa);
        courses.put(name, course);
        System.out.printf("Enrolled: %s (%s, GPA: %s)%n", name, course, gpa);
    }

    public static void main(String[] args) {
        ArrayList<String> enrollmentOrder = new ArrayList<>();
        HashSet<String> uniqueStudents = new HashSet<>();
        HashMap<String, Double> grades = new HashMap<>();
        TreeMap<String, String> courses = new TreeMap<>();

        System.out.println("--- Enrollment ---");
        enroll("Alice", 3.8, "BSIT", enrollmentOrder, uniqueStudents, grades, courses);
        enroll("Bob", 2.5, "BSCS", enrollmentOrder, uniqueStudents, grades, courses);
        enroll("Charlie", 3.2, "BSIT", enrollmentOrder, uniqueStudents, grades, courses);
        enroll("Alice", 3.9, "BSIT", enrollmentOrder, uniqueStudents, grades, courses);
        enroll("Diana", 3.6, "BSCS", enrollmentOrder, uniqueStudents, grades, courses);
        enroll("Edward", 1.9, "BSIT", enrollmentOrder, uniqueStudents, grades, courses);
        System.out.println();

        System.out.println("========================================");
        System.out.println("       STUDENT REGISTRY REPORT");
        System.out.println("========================================");
        System.out.println();

        System.out.println("Enrollment order (ArrayList):");
        for (int i = 0; i < enrollmentOrder.size(); i++) {
            System.out.printf("  %s. %s%n", (i + 1), enrollmentOrder.get(i));
        }
        System.out.println();

        System.out.printf("Unique count (HashSet): %s%n", uniqueStudents.size());
        System.out.println();

        System.out.println("Grades (HashMap):");
        // Print exactly like the expected output
        // I will use enrollment order or just the map iteration to match expected
        // Expected has: Alice -> 3.8, Bob -> 2.5, Charlie -> 3.2, Diana -> 3.6, Edward -> 1.9
        // Wait, expected output for Grades (HashMap) shows it alphabetically or insertion order?
        // Let me check expected: Alice, Bob, Charlie, Diana, Edward
        for (String name : courses.keySet()) {
            System.out.printf("  %s \u2192 %s%n", name, grades.get(name));
        }
        System.out.println();

        System.out.println("Courses sorted by name (TreeMap):");
        for (String name : courses.keySet()) {
            System.out.printf("  %s \u2192 %s%n", name, courses.get(name));
        }
        System.out.println();

        System.out.println("--- Statistics ---");
        double maxGpa = -1;
        String maxStudent = "";
        double minGpa = 10;
        String minStudent = "";
        double sumGpa = 0;
        int bsit = 0;
        int bscs = 0;

        for (String name : uniqueStudents) {
            double gpa = grades.get(name);
            sumGpa += gpa;
            if (gpa > maxGpa) {
                maxGpa = gpa;
                maxStudent = name;
            }
            if (gpa < minGpa) {
                minGpa = gpa;
                minStudent = name;
            }
            
            if (courses.get(name).equals("BSIT")) {
                bsit++;
            } else if (courses.get(name).equals("BSCS")) {
                bscs++;
            }
        }

        System.out.printf("Highest GPA: %s (%s)%n", maxStudent, maxGpa);
        System.out.printf("Lowest GPA: %s (%s)%n", minStudent, minGpa);
        System.out.printf("Average GPA: %s%n", String.format("%.2f", (sumGpa / uniqueStudents.size())));
        System.out.printf("BSIT students: %s%n", bsit);
        System.out.printf("BSCS students: %s%n", bscs);
        System.out.println("========================================");
    }
}
