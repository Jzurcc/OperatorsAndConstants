package com.school.collections;

import java.util.TreeMap;

public class TreeMapDemo {
    public static void main(String[] args) {
        TreeMap<String, Double> products = new TreeMap<>();
        products.put("Laptop", 45999.0);
        products.put("Mouse", 599.0);
        products.put("Keyboard", 1299.0);
        products.put("Monitor", 12500.0);
        products.put("Headset", 2499.0);

        System.out.println("Products (sorted by name):");
        for (String key : products.keySet()) {
            System.out.printf("  %s: %s%n", key, products.get(key));
        }
        System.out.println();

        System.out.printf("First key: %s%n", products.firstKey());
        System.out.printf("Last key: %s%n", products.lastKey());
        System.out.printf("Before \"Laptop\": %s%n", products.headMap("Laptop"));
        System.out.printf("\"Laptop\" and after: %s%n", products.tailMap("Laptop"));

        double total = 0;
        for (double price : products.values()) {
            total += price;
        }
        System.out.printf("Total price: %s%n", total);
    }
}
