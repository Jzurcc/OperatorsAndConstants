package com.school.collections;

import java.util.HashMap;
import java.util.Map;

public class MapIteration {
    public static void main(String[] args) {
        HashMap<String, String> capitals = new HashMap<>();
        capitals.put("Philippines", "Manila");
        capitals.put("Japan", "Tokyo");
        capitals.put("South Korea", "Seoul");
        capitals.put("Thailand", "Bangkok");
        capitals.put("Vietnam", "Hanoi");

        System.out.println("--- 1. entrySet() ---");
        for (Map.Entry<String, String> entry : capitals.entrySet()) {
            System.out.printf("%s \u2192 %s%n", entry.getKey(), entry.getValue());
        }
        System.out.println();

        System.out.println("--- 2. keySet() ---");
        for (String country : capitals.keySet()) {
            System.out.printf("%s \u2192 %s%n", country, capitals.get(country));
        }
        System.out.println();

        System.out.println("--- 3. forEach lambda ---");
        capitals.forEach((country, capital) -> System.out.printf("%s \u2192 %s%n", country, capital));
        System.out.println();

        System.out.printf("Keys: %s%n", capitals.keySet());
        System.out.printf("Values: %s%n", capitals.values());
    }
}
