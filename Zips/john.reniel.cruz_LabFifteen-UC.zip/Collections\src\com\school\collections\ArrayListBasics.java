package com.school.collections;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListBasics {
    public static void main(String[] args) {
        ArrayList<String> fruits = new ArrayList<>();
        fruits.add("Mango");
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");
        fruits.add("Apple");

        System.out.printf("Original: %s%n", fruits);
        System.out.printf("Size: %s%n", fruits.size());
        System.out.printf("Element at index 2: %s%n", fruits.get(2));

        fruits.set(1, "Avocado");
        System.out.printf("After set(1, \"Avocado\"): %s%n", fruits);

        fruits.remove("Cherry");
        System.out.printf("After remove(\"Cherry\"): %s%n", fruits);

        System.out.printf("Contains \"Mango\"? %s%n", fruits.contains("Mango"));
        System.out.printf("Index of \"Banana\": %s%n", fruits.indexOf("Banana"));

        Collections.sort(fruits);
        System.out.printf("After sort: %s%n", fruits);
    }
}
