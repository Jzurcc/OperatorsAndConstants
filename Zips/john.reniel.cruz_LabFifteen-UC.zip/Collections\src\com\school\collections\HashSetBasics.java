package com.school.collections;

import java.util.HashSet;

public class HashSetBasics {
    public static void main(String[] args) {
        HashSet<String> emails = new HashSet<>();
        emails.add("alice@email.com");
        emails.add("bob@email.com");
        emails.add("charlie@email.com");
        emails.add("alice@email.com");
        emails.add("bob@email.com");

        System.out.printf("Emails: %s%n", emails);
        System.out.printf("Size: %s (duplicates ignored)%n", emails.size());
        System.out.printf("Contains alice@email.com? %s%n", emails.contains("alice@email.com"));

        emails.remove("charlie@email.com");
        System.out.printf("After remove: %s%n", emails);
        System.out.println();

        HashSet<String> set2 = new HashSet<>();
        set2.add("bob@email.com");
        set2.add("diana@email.com");
        set2.add("edward@email.com");

        System.out.printf("Set 2: %s%n", set2);
        System.out.println();

        HashSet<String> union = new HashSet<>(emails);
        union.addAll(set2);
        System.out.printf("Union: %s%n", union);

        HashSet<String> intersection = new HashSet<>(emails);
        intersection.retainAll(set2);
        System.out.printf("Intersection: %s%n", intersection);
    }
}
