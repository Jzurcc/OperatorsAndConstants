package com.school.collections;

import java.util.LinkedList;

public class LinkedListDemo {
    public static void main(String[] args) {
        LinkedList<String> queue = new LinkedList<>();
        queue.add("Task A");
        queue.add("Task B");
        queue.add("Task C");

        queue.addFirst("Urgent Task");
        queue.addLast("Low Priority");

        System.out.printf("Queue: %s%n", queue);
        System.out.printf("Size: %s%n", queue.size());
        System.out.printf("First: %s%n", queue.getFirst());
        System.out.printf("Last: %s%n", queue.getLast());

        System.out.printf("Removed first: %s%n", queue.removeFirst());
        System.out.printf("Removed last: %s%n", queue.removeLast());

        System.out.printf("Final queue: %s%n", queue);
    }
}
