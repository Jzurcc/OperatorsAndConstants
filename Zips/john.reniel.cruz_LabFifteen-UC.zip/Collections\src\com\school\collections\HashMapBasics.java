package com.school.collections;

import java.util.HashMap;

public class HashMapBasics {
    public static void main(String[] args) {
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 92);
        scores.put("Bob", 78);
        scores.put("Charlie", 85);
        scores.put("Diana", 90);

        System.out.printf("Scores: %s%n", scores);
        System.out.printf("Size: %s%n", scores.size());
        System.out.printf("Alice's score: %s%n", scores.get("Alice"));
        System.out.printf("Contains \"Edward\"? %s%n", scores.containsKey("Edward"));
        System.out.printf("Contains value 85? %s%n", scores.containsValue(85));

        scores.put("Bob", 88);
        System.out.printf("After update Bob: %s%n", scores);

        scores.remove("Charlie");
        System.out.printf("After remove Charlie: %s%n", scores);

        System.out.printf("Edward's score (default): %s%n", scores.getOrDefault("Edward", 0));

        scores.putIfAbsent("Edward", 75);
        System.out.printf("After putIfAbsent Edward: %s%n", scores);
    }
}
