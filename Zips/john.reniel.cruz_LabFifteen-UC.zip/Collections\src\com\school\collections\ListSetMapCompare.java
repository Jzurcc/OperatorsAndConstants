package com.school.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

public class ListSetMapCompare {
    public static void main(String[] args) {
        String[] names = {"Alice", "Bob", "Charlie", "Alice", "Diana", "Bob", "Edward", "Charlie"};

        ArrayList<String> list = new ArrayList<>();
        for (String name : names) {
            list.add(name);
        }
        System.out.println("--- ArrayList (ordered, with duplicates) ---");
        System.out.println(list);
        System.out.printf("Size: %s%n", list.size());
        System.out.println();

        HashSet<String> hashSet = new HashSet<>();
        for (String name : names) {
            hashSet.add(name);
        }
        System.out.println("--- HashSet (no duplicates, unordered) ---");
        System.out.println(hashSet);
        System.out.printf("Size: %s%n", hashSet.size());
        System.out.println();

        TreeSet<String> treeSet = new TreeSet<>();
        for (String name : names) {
            treeSet.add(name);
        }
        System.out.println("--- TreeSet (no duplicates, sorted) ---");
        System.out.println(treeSet);
        System.out.printf("Size: %s%n", treeSet.size());
        System.out.println();

        System.out.println("--- HashMap (frequency count) ---");
        HashMap<String, Integer> counts = new HashMap<>();
        for (String name : names) {
            counts.put(name, counts.getOrDefault(name, 0) + 1);
        }
        for (String name : treeSet) {
            System.out.printf("%s: %s%n", name, counts.get(name));
        }
        System.out.println();

        String mostFrequentName = "";
        int maxCount = 0;
        for (String name : counts.keySet()) {
            int count = counts.get(name);
            if (count > maxCount) {
                maxCount = count;
                mostFrequentName = name;
            }
        }
        System.out.printf("Most frequent: %s (%s times)%n", mostFrequentName, maxCount);
    }
}
