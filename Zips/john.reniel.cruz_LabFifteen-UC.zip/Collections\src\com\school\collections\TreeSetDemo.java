package com.school.collections;

import java.util.TreeSet;

public class TreeSetDemo {
    public static void main(String[] args) {
        TreeSet<Integer> scores = new TreeSet<>();
        scores.add(88);
        scores.add(72);
        scores.add(95);
        scores.add(88);
        scores.add(65);
        scores.add(100);
        scores.add(72);
        scores.add(81);

        System.out.printf("Scores: %s%n", scores);
        System.out.printf("Size: %s (8 added, 2 duplicates removed)%n", scores.size());
        System.out.printf("Lowest: %s%n", scores.first());
        System.out.printf("Highest: %s%n", scores.last());
        System.out.printf("Scores below 85: %s%n", scores.headSet(85));
        System.out.printf("Scores 85 and above: %s%n", scores.tailSet(85));
        System.out.printf("Scores between 70 and 90: %s%n", scores.subSet(70, 90));
        System.out.println();

        TreeSet<String> names = new TreeSet<>();
        names.add("Edward");
        names.add("Alice");
        names.add("Diana");
        names.add("Bob");
        names.add("Charlie");

        System.out.printf("Names: %s%n", names);
    }
}
