package com.school.keywords;

public class TestSchoolSystem {
    public static void main(String[] args) {
        SchoolMember[] members = new SchoolMember[5];
        members[0] = new Teacher("Maria Santos", 35, "Java Programming");
        members[1] = new Teacher("Carlos Garcia", 40, "Data Structures");
        members[2] = new Student("Alice Reyes", 20, "BSIT", 3.8);
        members[3] = new Student("Bob Cruz", 21, "BSCS", 3.2);
        members[4] = new Student("Charlie Tan", 19, "BSIT", 2.9);

        System.out.println("========================================");
        System.out.println("       SCHOOL MEMBER DIRECTORY");
        System.out.println("========================================");
        System.out.println();

        for (SchoolMember member : members) {
            member.displayInfo();
            System.out.println();
        }

        System.out.println("========================================");
        System.out.printf("Total members: %s%n", members.length);
        System.out.println("========================================");
    }
}
