package com.school.keywords;

public class Vehicle {
    String type = "Generic Vehicle";

    public void showType() {
        System.out.println(type);
    }
}
