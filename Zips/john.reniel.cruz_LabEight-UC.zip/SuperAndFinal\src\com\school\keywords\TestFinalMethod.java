package com.school.keywords;

public class TestFinalMethod {
    public static void main(String[] args) {
        Circle circle = new Circle("Red", 5.0);
        System.out.printf("Color: %s%n", circle.getColor());
        System.out.printf("Area: %s%n", String.format("%.2f", circle.getArea()));
    }
}
