package com.school.keywords;

public class Dog extends Animal {
    String breed;

    public Dog(String name, int age, String breed) {
        super(name, age);
        this.breed = breed;
        System.out.println("Dog constructor called");
    }

    public void displayDogInfo() {
        displayInfo();
        System.out.printf("Breed: %s%n", breed);
    }
}
