package com.school.keywords;

public class TestSuperChain {
    public static void main(String[] args) {
        WashingMachine wm = new WashingMachine("Samsung", 24999.0, 8, true);
        wm.displayInfo();
    }
}
