package com.school.keywords;

public class SchoolMember {
    final int id;
    String name;
    int age;
    static int nextId = 1000;

    public SchoolMember(String name, int age) {
        nextId++;
        this.id = nextId;
        this.name = name;
        this.age = age;
    }

    public final int getId() {
        return id;
    }

    public void displayInfo() {
        System.out.printf("[ID: %s] %s, Age: %s%n", id, name, age);
    }
}
