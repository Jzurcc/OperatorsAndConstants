package com.school.keywords;

public class TestFinalClass {
    public static void main(String[] args) {
        System.out.printf("DB Host: %s%n", Config.DB_HOST);
        System.out.printf("DB Port: %s%n", Config.DB_PORT);
        System.out.printf("DB Name: %s%n", Config.DB_NAME);
        System.out.printf("Connection: %s%n", Config.getConnectionString());

        // class MyConfig extends Config {} // → ERROR: cannot inherit from final Config
    }
}
