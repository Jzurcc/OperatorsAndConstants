package com.school.keywords;

public class Circle extends Shape {
    double radius;

    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Cannot override getColor() → ERROR: getColor() in Circle cannot override getColor() in Shape; overridden method is final
    /*
    @Override
    public String getColor() {
        return super.getColor();
    }
    */
}
