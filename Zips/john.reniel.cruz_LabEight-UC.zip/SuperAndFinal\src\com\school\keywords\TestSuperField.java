package com.school.keywords;

public class TestSuperField {
    public static void main(String[] args) {
        Car car = new Car();
        car.showBothTypes();
    }
}
