package com.school.keywords;

public class Appliance {
    String brand;
    double price;

    public Appliance(String brand, double price) {
        this.brand = brand;
        this.price = price;
        System.out.printf("Appliance constructor: %s%n", brand);
    }

    public void displayInfo() {
        System.out.printf("Brand: %s%n", brand);
        System.out.printf("Price: %s%n", price);
    }
}
