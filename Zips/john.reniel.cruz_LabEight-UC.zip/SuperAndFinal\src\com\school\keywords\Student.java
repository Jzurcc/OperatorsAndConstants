package com.school.keywords;

public class Student extends SchoolMember {
    String course;
    double gpa;
    final String role = "Student";

    public Student(String name, int age, String course, double gpa) {
        super(name, age);
        this.course = course;
        this.gpa = gpa;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Role: %s%n", role);
        System.out.printf("Course: %s%n", course);
        System.out.printf("GPA: %s%n", gpa);
    }
}
