package com.school.keywords;

public class Car extends Vehicle {
    String type = "Car";

    public void showBothTypes() {
        System.out.printf("Child type (this.type): %s%n", this.type);
        System.out.printf("Parent type (super.type): %s%n", super.type);
    }
}
