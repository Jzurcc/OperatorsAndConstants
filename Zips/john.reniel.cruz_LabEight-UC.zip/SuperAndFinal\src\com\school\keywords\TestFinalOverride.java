package com.school.keywords;

public class TestFinalOverride {
    public static void main(String[] args) {
        System.out.println("--- Board Game ---");
        BoardGame bg = new BoardGame("Chess", 2, 8);
        bg.play();
        bg.showRules();
    }
}
