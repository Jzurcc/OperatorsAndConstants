package com.school.keywords;

public class SavingsAccount extends BankAccount {
    double interestRate;

    public SavingsAccount(String accountNumber, String owner, double balance, double interestRate) {
        super(accountNumber, owner, balance);
        this.interestRate = interestRate;
    }

    public double calculateInterest() {
        return balance * (interestRate / 100);
    }

    @Override
    public void displayInfo() {
        System.out.println("--- Savings Account ---");
        super.displayInfo();
        System.out.printf("Interest rate: %s%%%n", interestRate);
        System.out.printf("Annual interest: %s%n", calculateInterest());
    }
}
