package com.school.keywords;

public class Teacher extends SchoolMember {
    String subject;
    final String role = "Teacher";

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("Role: %s%n", role);
        System.out.printf("Subject: %s%n", subject);
    }
}
