package com.school.keywords;

public class BankAccount {
    final String accountNumber;
    String owner;
    double balance;

    public BankAccount(String accountNumber, String owner, double balance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }

    public final String getAccountNumber() {
        return accountNumber;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void displayInfo() {
        System.out.printf("Account: %s%n", accountNumber);
        System.out.printf("Owner: %s%n", owner);
        System.out.printf("Balance: %s%n", balance);
    }
}
