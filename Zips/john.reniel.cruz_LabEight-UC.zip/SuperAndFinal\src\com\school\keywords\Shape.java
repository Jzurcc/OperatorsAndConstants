package com.school.keywords;

public class Shape {
    String color;

    public Shape(String color) {
        this.color = color;
    }

    public final String getColor() {
        return color;
    }

    public double getArea() {
        return 0.0;
    }
}
