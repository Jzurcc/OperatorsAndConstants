package com.school.keywords;

public class Game {
    String title;
    int maxPlayers;

    public Game(String title, int maxPlayers) {
        this.title = title;
        this.maxPlayers = maxPlayers;
    }

    public final void showRules() {
        System.out.println("All players must follow the official rules.");
    }

    public void play() {
        System.out.printf("Playing %s...%n", title);
    }
}
