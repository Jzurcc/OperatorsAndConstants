package com.school.keywords;

public class TestSuperAndFinal {
    public static void main(String[] args) {
        SavingsAccount sa = new SavingsAccount("ACC-2024-001", "Maria Santos", 50000.0, 2.5);
        sa.displayInfo();
        System.out.println();
        System.out.println("Depositing 10000.0...");
        sa.deposit(10000.0);
        System.out.printf("Balance: %s%n", sa.balance);
        System.out.printf("New annual interest: %s%n", sa.calculateInterest());
    }
}
