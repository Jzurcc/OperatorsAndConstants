package com.school.keywords;

public class Person {
    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void introduce() {
        System.out.printf("Hi, I'm %s, age %s.%n", name, age);
    }
}
