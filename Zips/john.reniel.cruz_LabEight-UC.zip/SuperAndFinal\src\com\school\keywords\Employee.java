package com.school.keywords;

public class Employee extends Person {
    String company;
    String position;

    public Employee(String name, int age, String company, String position) {
        super(name, age);
        this.company = company;
        this.position = position;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.printf("Company: %s%n", company);
        System.out.printf("Position: %s%n", position);
    }
}
