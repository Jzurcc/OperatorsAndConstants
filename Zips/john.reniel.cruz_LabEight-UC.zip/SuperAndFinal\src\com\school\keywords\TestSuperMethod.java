package com.school.keywords;

public class TestSuperMethod {
    public static void main(String[] args) {
        System.out.println("--- Person ---");
        Person person = new Person("Maria Santos", 30);
        person.introduce();
        System.out.println();
        
        System.out.println("--- Employee ---");
        Employee employee = new Employee("Carlos Garcia", 28, "Accenture", "Java Developer");
        employee.introduce();
    }
}
