package com.school.keywords;

public class TestSuperConstructor {
    public static void main(String[] args) {
        Dog dog = new Dog("Bantay", 3, "Aspin");
        System.out.println();
        dog.displayDogInfo();
    }
}
