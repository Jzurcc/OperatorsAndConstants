package com.school.keywords;

public class WashingMachine extends Appliance {
    int loadCapacityKg;
    boolean isFrontLoad;

    public WashingMachine(String brand, double price, int loadCapacityKg, boolean isFrontLoad) {
        super(brand, price);
        this.loadCapacityKg = loadCapacityKg;
        this.isFrontLoad = isFrontLoad;
        System.out.printf("WashingMachine constructor: %skg%n", loadCapacityKg);
    }

    @Override
    public void displayInfo() {
        System.out.println("\n--- Washing Machine Info ---");
        super.displayInfo();
        System.out.printf("Load capacity: %skg%n", loadCapacityKg);
        System.out.printf("Front load: %s%n", isFrontLoad);
    }
}
