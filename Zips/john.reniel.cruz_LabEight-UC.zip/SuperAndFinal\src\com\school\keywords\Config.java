package com.school.keywords;

public final class Config {
    static final String DB_HOST = "localhost";
    static final int DB_PORT = 3306;
    static final String DB_NAME = "school_db";

    public static String getConnectionString() {
        return "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME;
    }
}
