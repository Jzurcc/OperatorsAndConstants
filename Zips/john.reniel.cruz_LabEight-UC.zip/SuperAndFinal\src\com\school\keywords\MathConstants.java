package com.school.keywords;

public class MathConstants {
    static final double PI = 3.14159;
    static final double EULER = 2.71828;
    static final int MAX_ARRAY_SIZE = 100;
    static final String APP_NAME = "MathHelper";
}
