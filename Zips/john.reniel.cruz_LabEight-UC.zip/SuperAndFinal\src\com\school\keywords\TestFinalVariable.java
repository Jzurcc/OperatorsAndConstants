package com.school.keywords;

public class TestFinalVariable {
    public static void main(String[] args) {
        System.out.printf("PI: %s%n", MathConstants.PI);
        System.out.printf("Euler: %s%n", MathConstants.EULER);
        System.out.printf("Max array size: %s%n", MathConstants.MAX_ARRAY_SIZE);
        System.out.printf("App name: %s%n", MathConstants.APP_NAME);

        final int x = 10;
        System.out.printf("Local final x: %s%n", x);

        // x = 20; // → ERROR: cannot assign a value to final variable x
    }
}
