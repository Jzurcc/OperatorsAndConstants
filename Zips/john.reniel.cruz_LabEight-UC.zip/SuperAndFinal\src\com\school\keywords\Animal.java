package com.school.keywords;

public class Animal {
    String name;
    int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println("Animal constructor called");
    }

    public void displayInfo() {
        System.out.printf("Name: %s%n", name);
        System.out.printf("Age: %s%n", age);
    }
}
