package com.school.keywords;

public class BoardGame extends Game {
    int boardSize;

    public BoardGame(String title, int maxPlayers, int boardSize) {
        super(title, maxPlayers);
        this.boardSize = boardSize;
    }

    @Override
    public void play() {
        super.play();
        System.out.printf("Board size: %sx%s%n", boardSize, boardSize);
    }

    // Cannot override showRules() → ERROR: showRules() in BoardGame cannot override showRules() in Game; overridden method is final
    /*
    @Override
    public void showRules() {
        System.out.println("Board game rules apply.");
    }
    */
}
