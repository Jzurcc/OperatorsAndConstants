package com.school.polymorphism;

public class Triangle extends Shape {
    double base;
    double height;

    public Triangle(String color, double base, double height) {
        super(color);
        this.base = base;
        this.height = height;
    }

    @Override
    public double getArea() {
        return 0.5 * base * height;
    }

    @Override
    public String getShapeName() {
        return "Triangle";
    }
}
