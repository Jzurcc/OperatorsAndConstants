package com.school.polymorphism;

public class Printer {
    public void display(String message) {
        System.out.println(message);
    }

    public void display(String message, int times) {
        for (int i = 0; i < times; i++) {
            System.out.print(message + (i < times - 1 ? " " : ""));
        }
        System.out.println();
    }

    public void display(String message, String prefix) {
        System.out.printf("[%s] %s%n", prefix, message);
    }

    public void display(int number) {
        System.out.printf("Number: %s%n", number);
    }

    public void display(double number) {
        System.out.printf("Decimal: %s%n", number);
    }

    public void display(boolean value) {
        System.out.printf("Boolean: %s%n", value);
    }
}
