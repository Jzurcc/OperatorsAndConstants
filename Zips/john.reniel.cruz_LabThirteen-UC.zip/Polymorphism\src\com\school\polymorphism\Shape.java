package com.school.polymorphism;

public abstract class Shape {
    String color;

    public Shape(String color) {
        this.color = color;
    }

    public abstract double getArea();
    public abstract String getShapeName();

    public void printDetails() {
        System.out.printf("Shape: %s | Color: %s | Area: %s%n", getShapeName(), color, String.format("%.2f", getArea()));
    }
}
