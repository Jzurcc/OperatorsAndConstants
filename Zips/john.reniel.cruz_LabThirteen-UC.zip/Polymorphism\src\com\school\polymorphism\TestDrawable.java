package com.school.polymorphism;

public class TestDrawable {
    public static void main(String[] args) {
        CircleUI circle = new CircleUI(5.0);
        RectangleUI rectangle = new RectangleUI(10.0, 6.0);

        Drawable[] drawables = { circle, rectangle };
        Resizable[] resizables = { circle, rectangle };

        System.out.println("--- Drawing (via Drawable[]) ---");
        for (Drawable d : drawables) {
            d.draw();
        }
        System.out.println();

        System.out.println("--- Resizing (via Resizable[]) ---");
        for (Resizable r : resizables) {
            if (r instanceof CircleUI) {
                r.resize(2.0);
            } else if (r instanceof RectangleUI) {
                r.resize(1.5);
            }
        }
        System.out.println();

        System.out.println("--- Erasing (default method) ---");
        for (Drawable d : drawables) {
            d.erase();
        }
    }
}
