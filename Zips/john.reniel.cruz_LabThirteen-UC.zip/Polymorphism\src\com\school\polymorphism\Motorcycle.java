package com.school.polymorphism;

public class Motorcycle extends Vehicle {
    boolean hasSidecar;

    public Motorcycle(String brand, int speed, boolean hasSidecar) {
        super(brand, speed);
        this.hasSidecar = hasSidecar;
    }

    @Override
    public void drive() {
        System.out.printf("Motorcycle is zooming at %s km/h.%n", speed);
    }

    public void wheelie() {
        System.out.println("Doing a wheelie!");
    }
}
