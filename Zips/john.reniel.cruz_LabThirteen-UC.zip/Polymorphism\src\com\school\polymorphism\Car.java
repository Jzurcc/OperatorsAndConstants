package com.school.polymorphism;

public class Car extends Vehicle {
    int doors;

    public Car(String brand, int speed, int doors) {
        super(brand, speed);
        this.doors = doors;
    }

    @Override
    public void drive() {
        System.out.printf("Car is driving smoothly at %s km/h.%n", speed);
    }

    public void openTrunk() {
        System.out.println("Opening trunk.");
    }
}
