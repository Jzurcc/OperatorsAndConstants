package com.school.polymorphism;

public interface Drawable {
    void draw();
    String getShapeName();

    default void erase() {
        System.out.printf("Erasing %s%n", getShapeName());
    }
}
