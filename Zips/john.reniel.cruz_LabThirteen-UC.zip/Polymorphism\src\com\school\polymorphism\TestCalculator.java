package com.school.polymorphism;

public class TestCalculator {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        System.out.printf("add(10, 20) = %s%n", calc.add(10, 20));
        System.out.printf("add(10, 20, 30) = %s%n", calc.add(10, 20, 30));
        System.out.printf("add(3.14, 2.86) = %s%n", calc.add(3.14, 2.86));
        System.out.printf("add(\"Hello\", \" World\") = %s%n", calc.add("Hello", " World"));
        System.out.printf("multiply(5, 4) = %s%n", calc.multiply(5, 4));
        System.out.printf("multiply(2.5, 3.0) = %s%n", calc.multiply(2.5, 3.0));
    }
}
