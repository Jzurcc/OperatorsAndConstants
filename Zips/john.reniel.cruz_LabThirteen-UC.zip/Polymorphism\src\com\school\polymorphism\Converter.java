package com.school.polymorphism;

public class Converter {
    public double convert(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    public double convert(double value, String fromUnit) {
        switch (fromUnit.toLowerCase()) {
            case "km":
                return value * 0.621371;
            case "kg":
                return value * 2.20462;
            case "l":
                return value * 0.264172;
            default:
                return value;
        }
    }

    public String convert(int number) {
        return Integer.toBinaryString(number);
    }

    public String convert(int number, int base) {
        return Integer.toString(number, base);
    }

    public String getConverterType() {
        return "Basic Converter";
    }
}

class ScientificConverter extends Converter {
    @Override
    public String getConverterType() {
        return "Scientific Converter";
    }

    @Override
    public double convert(double celsius) {
        double fahrenheit = super.convert(celsius);
        double kelvin = celsius + 273.15;
        System.out.printf("%s\u00B0C = %s\u00B0F = %sK%n", celsius, fahrenheit, kelvin);
        return fahrenheit;
    }
}
