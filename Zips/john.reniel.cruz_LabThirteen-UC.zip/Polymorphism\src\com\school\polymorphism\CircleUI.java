package com.school.polymorphism;

public class CircleUI implements Drawable, Resizable {
    double radius;

    public CircleUI(double radius) {
        this.radius = radius;
    }

    @Override
    public void draw() {
        System.out.printf("Drawing Circle with radius %s%n", radius);
    }

    @Override
    public String getShapeName() {
        return "Circle";
    }

    @Override
    public void resize(double factor) {
        radius *= factor;
        System.out.printf("Resizing Circle by %sx \u2192 new radius: %s%n", factor, radius);
    }
}
