package com.school.polymorphism;

public class TestAnimal {
    public static void main(String[] args) {
        Animal[] animals = new Animal[3];
        animals[0] = new Dog("Bantay");
        animals[1] = new Cat("Mingming");
        animals[2] = new Bird("Tweety");

        for (Animal animal : animals) {
            animal.displayInfo();
        }
    }
}
