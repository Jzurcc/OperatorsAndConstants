package com.school.polymorphism;

public abstract class Notification {
    String recipient;
    String message;

    public Notification(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;
    }

    public abstract void send();
    public abstract String getChannel();
    public abstract double getCost();

    public void displayInfo() {
        System.out.printf("Sending %s to %s: \"%s\"%n", getChannel(), recipient, message);
    }
}
