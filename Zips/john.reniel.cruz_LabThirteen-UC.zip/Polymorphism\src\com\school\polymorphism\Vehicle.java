package com.school.polymorphism;

public class Vehicle {
    String brand;
    int speed;

    public Vehicle(String brand, int speed) {
        this.brand = brand;
        this.speed = speed;
    }

    public void drive() {
        System.out.println("Vehicle is driving.");
    }

    public void displayInfo() {
        System.out.printf("[%s] %s at %s km/h%n", getClass().getSimpleName(), brand, speed);
    }
}
