package com.school.polymorphism;

public class TestCasting {
    public static void main(String[] args) {
        System.out.println("--- Upcasting ---");
        Vehicle v = new Car("Toyota", 120, 4);
        v.drive();
        // v.openTrunk(); // \u2192 ERROR: cannot find symbol method openTrunk() \u2014 reference is Vehicle
        System.out.println();

        System.out.println("--- Downcasting ---");
        Car c = (Car) v;
        c.openTrunk();
        System.out.println();

        System.out.println("--- Safe downcasting with instanceof ---");
        Vehicle[] vehicles = new Vehicle[3];
        vehicles[0] = new Car("Toyota", 120, 4);
        vehicles[1] = new Motorcycle("Kawasaki", 90, false);
        vehicles[2] = new Truck("Isuzu", 80, 5.0);

        for (Vehicle vehicle : vehicles) {
            System.out.print("[" + vehicle.getClass().getSimpleName() + "] " + vehicle.brand + " at " + vehicle.speed + " km/h \u2192 ");
            if (vehicle instanceof Car) {
                ((Car) vehicle).openTrunk();
            } else if (vehicle instanceof Motorcycle) {
                ((Motorcycle) vehicle).wheelie();
            } else if (vehicle instanceof Truck) {
                ((Truck) vehicle).loadCargo();
            }
        }

        // Car invalidCar = (Car) new Motorcycle("Honda", 100, false); // \u2192 ClassCastException: Motorcycle cannot be cast to Car
    }
}
