package com.school.polymorphism;

public class Developer extends Employee {
    double salary;
    String language;

    public Developer(String name, int id, double salary, String language) {
        super(name, id);
        this.salary = salary;
        this.language = language;
    }

    @Override
    public String getRole() {
        return "Developer";
    }

    @Override
    public double getSalary() {
        return salary;
    }

    public void writeCode() {
        System.out.printf("\u2192 Writing code in %s.%n", language);
    }
}
