package com.school.polymorphism;

public interface Payable {
    double calculatePay();

    default String formatPay() {
        return "PHP " + String.format("%.2f", calculatePay());
    }

    static double calculateTotalPay(Payable[] payables) {
        double total = 0;
        for (Payable p : payables) {
            total += p.calculatePay();
        }
        return total;
    }
}
