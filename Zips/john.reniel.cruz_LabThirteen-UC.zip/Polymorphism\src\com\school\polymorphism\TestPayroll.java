package com.school.polymorphism;

public class TestPayroll {
    public static void main(String[] args) {
        Employee[] employees = new Employee[4];
        employees[0] = new Manager("Alice Santos", 1, 80000.0, 15000.0);
        employees[1] = new Developer("Bob Garcia", 2, 55000.0, "Java");
        employees[2] = new Developer("Charlie Reyes", 3, 52000.0, "Python");
        employees[3] = new Intern("Diana Cruz", 4, 8000.0);

        System.out.println("========================================");
        System.out.println("       EMPLOYEE DIRECTORY");
        System.out.println("========================================");
        System.out.println();

        int managersCount = 0;
        int developersCount = 0;
        int internsCount = 0;
        double totalPayroll = 0;

        for (Employee emp : employees) {
            emp.displayInfo();
            if (emp instanceof Manager) {
                Manager m = (Manager) emp;
                System.out.printf("  Salary: %s + Bonus: %s = %s%n", m.salary, m.bonus, m.getSalary());
                m.conductMeeting();
                managersCount++;
            } else if (emp instanceof Developer) {
                Developer d = (Developer) emp;
                System.out.printf("  Salary: %s | Language: %s%n", d.salary, d.language);
                d.writeCode();
                developersCount++;
            } else if (emp instanceof Intern) {
                Intern i = (Intern) emp;
                System.out.printf("  Allowance: %s%n", i.allowance);
                i.learnSkill("Spring Boot");
                internsCount++;
            }
            totalPayroll += emp.getSalary();
            System.out.println();
        }

        System.out.println("========================================");
        System.out.printf("Managers: %s | Developers: %s | Interns: %s%n", managersCount, developersCount, internsCount);
        System.out.printf("Total payroll: %s%n", totalPayroll);
        System.out.println("========================================");
        System.out.println();

        // Exercise 10 part
        Payable[] payables = new Payable[employees.length];
        Reportable[] reportables = new Reportable[employees.length];

        for (int i = 0; i < employees.length; i++) {
            payables[i] = (Payable) employees[i];
            reportables[i] = (Reportable) employees[i];
        }

        System.out.println("========================================");
        System.out.println("       PAYROLL REPORT");
        System.out.println("========================================");
        System.out.println();

        System.out.println("--- Pay (via Payable[]) ---");
        for (Payable p : payables) {
            System.out.println(p.formatPay());
        }
        System.out.println();

        System.out.println("--- Reports (via Reportable[]) ---");
        for (Reportable r : reportables) {
            System.out.println(r.generateReport());
        }
        System.out.println();

        System.out.println("--- Total (via static method) ---");
        System.out.printf("Total payroll: PHP %s%n", String.format("%.2f", Payable.calculateTotalPay(payables)));
        System.out.println();
        System.out.println("========================================");
    }
}
