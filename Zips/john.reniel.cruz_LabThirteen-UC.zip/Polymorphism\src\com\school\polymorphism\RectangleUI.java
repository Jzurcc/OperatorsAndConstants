package com.school.polymorphism;

public class RectangleUI implements Drawable, Resizable {
    double width;
    double height;

    public RectangleUI(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public void draw() {
        System.out.printf("Drawing Rectangle %s x %s%n", width, height);
    }

    @Override
    public String getShapeName() {
        return "Rectangle";
    }

    @Override
    public void resize(double factor) {
        width *= factor;
        height *= factor;
        System.out.printf("Resizing Rectangle by %sx \u2192 new size: %s x %s%n", factor, width, height);
    }
}
