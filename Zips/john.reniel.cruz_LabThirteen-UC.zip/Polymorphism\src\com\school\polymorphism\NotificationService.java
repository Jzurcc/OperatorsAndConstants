package com.school.polymorphism;

public class NotificationService {
    public static void sendAll(Notification[] notifications) {
        double totalCost = 0;
        int emailCount = 0;
        int smsCount = 0;
        int pushCount = 0;

        for (Notification n : notifications) {
            n.send();
            totalCost += n.getCost();

            if (n instanceof EmailNotification) {
                emailCount++;
            } else if (n instanceof SmsNotification) {
                smsCount++;
            } else if (n instanceof PushNotification) {
                pushCount++;
            }
        }

        System.out.println();
        System.out.println("--- Summary ---");
        System.out.printf("Total notifications: %s%n", notifications.length);
        System.out.printf("Total cost: PHP %s%n", String.format("%.2f", totalCost));
        System.out.printf("Email: %s, SMS: %s, Push: %s%n", emailCount, smsCount, pushCount);
    }
}
