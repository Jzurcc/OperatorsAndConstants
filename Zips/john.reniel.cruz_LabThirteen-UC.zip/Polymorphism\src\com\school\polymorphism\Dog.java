package com.school.polymorphism;

public class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    @Override
    public String makeSound() {
        return "Woof!";
    }

    @Override
    public String getType() {
        return "Dog";
    }
}
