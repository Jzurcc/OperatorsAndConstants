package com.school.polymorphism;

public class TestConverter {
    public static void main(String[] args) {
        System.out.println("--- Overloading (Basic Converter) ---");
        Converter basic = new Converter();
        System.out.printf("Type: %s%n", basic.getConverterType());
        System.out.printf("100.0\u00B0C = %s\u00B0F%n", basic.convert(100.0));
        System.out.printf("10.0 km = %s miles%n", String.format("%.2f", basic.convert(10.0, "km")));
        System.out.printf("5.0 kg = %s lbs%n", String.format("%.2f", basic.convert(5.0, "kg")));
        System.out.printf("3.785 L = %s gallons%n", String.format("%.1f", basic.convert(3.785, "L")));
        System.out.printf("42 in binary = %s%n", basic.convert(42));
        System.out.printf("42 in octal = %s%n", basic.convert(42, 8));
        System.out.printf("42 in hex = %s%n", basic.convert(42, 16));
        System.out.println();

        System.out.println("--- Overriding (Scientific Converter) ---");
        Converter scientific = new ScientificConverter();
        System.out.printf("Type: %s%n", scientific.getConverterType());
        scientific.convert(100.0);
    }
}
