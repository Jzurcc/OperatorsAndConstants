package com.school.polymorphism;

public class SmsNotification extends Notification {
    double ratePerSms;

    public SmsNotification(String recipient, String message, double ratePerSms) {
        super(recipient, message);
        this.ratePerSms = ratePerSms;
    }

    @Override
    public void send() {
        displayInfo();
    }

    @Override
    public String getChannel() {
        return "SMS";
    }

    @Override
    public double getCost() {
        return ratePerSms;
    }
}
