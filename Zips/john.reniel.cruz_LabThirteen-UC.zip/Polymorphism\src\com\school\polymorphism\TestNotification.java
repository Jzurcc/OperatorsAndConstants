package com.school.polymorphism;

public class TestNotification {
    public static void main(String[] args) {
        Notification[] notifications = new Notification[4];
        notifications[0] = new EmailNotification("alice@email.com", "Meeting at 3pm");
        notifications[1] = new SmsNotification("09171234567", "Your code is 4521", 1.50);
        notifications[2] = new PushNotification("bob_user", "New update available");
        notifications[3] = new SmsNotification("09189876543", "Delivery arriving soon", 1.50);

        NotificationService.sendAll(notifications);
    }
}
