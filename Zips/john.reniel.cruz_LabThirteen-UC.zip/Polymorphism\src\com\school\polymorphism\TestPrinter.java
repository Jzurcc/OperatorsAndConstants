package com.school.polymorphism;

public class TestPrinter {
    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.display("Hello World");
        printer.display("Hello!", 3);
        printer.display("System started", "INFO");
        printer.display(42);
        printer.display(3.14);
        printer.display(true);
    }
}
