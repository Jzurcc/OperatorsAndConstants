package com.school.polymorphism;

public class PushNotification extends Notification {
    public PushNotification(String recipient, String message) {
        super(recipient, message);
    }

    @Override
    public void send() {
        displayInfo();
    }

    @Override
    public String getChannel() {
        return "Push";
    }

    @Override
    public double getCost() {
        return 0.0;
    }
}
