package com.school.polymorphism;

public interface Reportable {
    String generateReport();
}
