package com.school.polymorphism;

public class Employee implements Payable, Reportable {
    String name;
    int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getRole() {
        return "Employee";
    }

    public double getSalary() {
        return 0;
    }

    public void displayInfo() {
        System.out.printf("[%s] %s (ID: %s)%n", getRole(), name, id);
    }

    @Override
    public double calculatePay() {
        return getSalary();
    }

    @Override
    public String generateReport() {
        return getRole() + " " + name + " | Pay: PHP " + String.format("%.2f", calculatePay());
    }
}
