package com.school.polymorphism;

public class TestShape {
    public static void describeShape(Shape s) {
        s.printDetails();
    }

    public static void main(String[] args) {
        System.out.println("--- Passing Circle ---");
        describeShape(new Circle("Red", 5.0));
        System.out.println();

        System.out.println("--- Passing Rectangle ---");
        describeShape(new Rectangle("Blue", 8.0, 5.0));
        System.out.println();

        System.out.println("--- Passing Triangle ---");
        describeShape(new Triangle("Green", 10.0, 5.0));
    }
}
