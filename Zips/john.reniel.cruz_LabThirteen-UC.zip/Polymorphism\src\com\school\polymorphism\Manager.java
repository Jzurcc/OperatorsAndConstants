package com.school.polymorphism;

public class Manager extends Employee {
    double salary;
    double bonus;

    public Manager(String name, int id, double salary, double bonus) {
        super(name, id);
        this.salary = salary;
        this.bonus = bonus;
    }

    @Override
    public String getRole() {
        return "Manager";
    }

    @Override
    public double getSalary() {
        return salary + bonus;
    }

    public void conductMeeting() {
        System.out.println("\u2192 Conducting a team meeting.");
    }
}
