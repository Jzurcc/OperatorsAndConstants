package com.school.polymorphism;

public interface Resizable {
    void resize(double factor);
}
