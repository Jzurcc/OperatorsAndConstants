package com.school.polymorphism;

public class Intern extends Employee {
    double allowance;

    public Intern(String name, int id, double allowance) {
        super(name, id);
        this.allowance = allowance;
    }

    @Override
    public String getRole() {
        return "Intern";
    }

    @Override
    public double getSalary() {
        return allowance;
    }

    public void learnSkill(String skill) {
        System.out.printf("\u2192 Learning %s.%n", skill);
    }
}
