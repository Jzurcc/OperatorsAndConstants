package com.school.polymorphism;

public class EmailNotification extends Notification {
    public EmailNotification(String recipient, String message) {
        super(recipient, message);
    }

    @Override
    public void send() {
        displayInfo();
    }

    @Override
    public String getChannel() {
        return "Email";
    }

    @Override
    public double getCost() {
        return 0.0;
    }
}
