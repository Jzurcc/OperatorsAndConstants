package com.school.polymorphism;

public class Truck extends Vehicle {
    double cargoTons;

    public Truck(String brand, int speed, double cargoTons) {
        super(brand, speed);
        this.cargoTons = cargoTons;
    }

    @Override
    public void drive() {
        System.out.printf("Truck is hauling at %s km/h.%n", speed);
    }

    public void loadCargo() {
        System.out.printf("Loading %s tons of cargo.%n", cargoTons);
    }
}
