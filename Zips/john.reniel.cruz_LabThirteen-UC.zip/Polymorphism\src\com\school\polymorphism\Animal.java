package com.school.polymorphism;

public class Animal {
    String name;

    public Animal(String name) {
        this.name = name;
    }

    public String makeSound() {
        return "...";
    }

    public String getType() {
        return "Animal";
    }

    public void displayInfo() {
        System.out.printf("[%s] %s says: %s%n", getType(), name, makeSound());
    }
}
