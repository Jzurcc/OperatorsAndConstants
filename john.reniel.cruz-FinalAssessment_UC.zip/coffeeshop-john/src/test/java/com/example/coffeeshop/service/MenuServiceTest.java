package com.example.coffeeshop.service;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

import com.example.coffeeshop.exception.MenuItemNotFoundException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.repository.MenuItemRepository;

class MenuServiceTest {

    @Mock
    MenuItemRepository repo;

    @InjectMocks
    MenuService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetItemById_whenPresent_returnsItem() {
        MenuItem item = new MenuItem("Espresso", "Coffee", new BigDecimal("2.50"), true);
        when(repo.findById(1L)).thenReturn(Optional.of(item));

        MenuItem result = service.getItemById(1L);

        assertEquals("Espresso", result.getName());
        verify(repo).findById(1L);
    }

    @Test
    void testGetItemById_whenEmpty_throwsException() {
        when(repo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(MenuItemNotFoundException.class, () -> service.getItemById(1L));
        verify(repo).findById(1L);
    }

    @Test
    void testCreateItem_savesAndReturns() {
        MenuItem item = new MenuItem("Latte", "Coffee", new BigDecimal("3.00"), true);
        when(repo.save(any(MenuItem.class))).thenReturn(item);

        MenuItem result = service.createItem(item);

        assertEquals("Lattes", result.getName());
        verify(repo).save(item);
    }
}
