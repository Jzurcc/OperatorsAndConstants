package com.example.coffeeshop.agent.controller;

import com.example.coffeeshop.agent.service.AgentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/agent")
public class AgentController {

    private final AgentService agentService;
    public AgentController(AgentService agentService) { this.agentService = agentService; }

    @PostMapping
    public String runAgent(@RequestBody String request) {
        return agentService.run(request);
    }
}
