package com.example.coffeeshop.controller;

import com.example.coffeeshop.dto.*;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.service.MenuService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.coffeeshop.dto.MenuItemResponse;
import com.example.coffeeshop.dto.MenuItemRequest;

@RestController
@RequestMapping("/menu")
public class MenuController {

    private final MenuService service;

    public MenuController(MenuService service) {
        this.service = service;
    }

    @GetMapping
    public List<MenuItemResponse> getAll() {
        return service.getAllItems().stream()
                .map(MenuItemResponse::from)
                .toList();
    }

    @GetMapping("/{id}")
    public MenuItemResponse getById(@PathVariable Long id) {
        return MenuItemResponse.from(service.getItemById(id));
    }

    @PostMapping
    public ResponseEntity<MenuItemResponse> create(@Valid @RequestBody MenuItemRequest request) {
        MenuItem item = new MenuItem(request.getName(), request.getCategory(), request.getPrice(), request.isAvailable());
        MenuItem created = service.createItem(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(MenuItemResponse.from(created));
    }

    @PutMapping("/{id}")
    public MenuItemResponse update(@PathVariable Long id, @Valid @RequestBody MenuItemRequest request) {
        MenuItem updated = new MenuItem(request.getName(), request.getCategory(), request.getPrice(), request.isAvailable());
        MenuItem saved = service.updateItem(id, updated);
        return MenuItemResponse.from(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteItem(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/category/{category}")
    public List<MenuItemResponse> getByCategory(@PathVariable String category) {
        return service.getByCategory(category).stream()
                .map(MenuItemResponse::from)
                .toList();
    }

    @GetMapping("/available")
    public List<MenuItemResponse> getAvailable() {
        return service.getAvailableItems().stream()
                .map(MenuItemResponse::from)
                .toList();
    }
}
