package com.example.coffeeshop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.coffeeshop.model.MenuItem;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

    List<MenuItem> findByCategoryIgnoreCase(String category);

    List<MenuItem> findByAvailableTrue();
}
