package com.example.coffeeshop.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")  // "order" is a reserved SQL word
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // itemIds — the menu-item IDs in this order, stored in a side table
    @ElementCollection
    private List<Long> itemIds = new ArrayList<>();

    // status — stored as text ("PENDING"), defaulting to PENDING
    @Enumerated(EnumType.STRING)
    private OrderStatus status = OrderStatus.PENDING;

    // total — computed from item prices when the order is created
    private BigDecimal total = BigDecimal.ZERO;

    public Order() {
    }

    public Order(List<Long> itemIds, BigDecimal total) {
        this.itemIds = itemIds;
        this.total = total;
        this.status = OrderStatus.PENDING;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Long> getItemIds() {
        return itemIds;
    }

    public void setItemIds(List<Long> itemIds) {
        this.itemIds = itemIds;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }
}
