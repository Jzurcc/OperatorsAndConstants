package com.example.coffeeshop.service;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.coffeeshop.exception.InvalidOrderException;
import com.example.coffeeshop.exception.InvalidStatusTransitionException;
import com.example.coffeeshop.exception.MenuItemNotFoundException;
import com.example.coffeeshop.exception.OrderNotFoundException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.model.Order;
import com.example.coffeeshop.model.OrderStatus;
import com.example.coffeeshop.repository.MenuItemRepository;
import com.example.coffeeshop.repository.OrderRepository;

@Service
public class OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);
    private final OrderRepository orderRepo;
    private final MenuItemRepository menuRepo;

    public OrderService(OrderRepository orderRepo, MenuItemRepository menuRepo) {
        this.orderRepo = orderRepo;
        this.menuRepo = menuRepo;
    }

    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepo.findById(id)
                .orElseThrow(() -> new OrderNotFoundException(id));
    }

    public Order createOrder(List<Long> itemIds) {
        if (itemIds == null || itemIds.isEmpty()) {
            throw new InvalidOrderException("Item ids cannot be null or empty");
        }

        BigDecimal total = BigDecimal.ZERO;
        for (Long id : itemIds) {
            MenuItem item = menuRepo.findById(id)
                    .orElseThrow(() -> new MenuItemNotFoundException(id));
            if (!item.isAvailable()) {
                throw new InvalidOrderException("Item with id " + id + " is not available");
            }
            total = total.add(item.getPrice());
        }
        Order order = new Order(itemIds, total);
        log.info("Created order with id: {}", order.getId());
        return orderRepo.save(order);

    }

    public Order markReady(Long id) {
        Order order = getOrderById(id);
        if (order.getStatus() != OrderStatus.PENDING) {
            throw new InvalidStatusTransitionException(order.getStatus(), OrderStatus.READY);
        }
        order.setStatus(OrderStatus.READY);
        return orderRepo.save(order);

    }

    public Order markPaid(Long id) {
        Order order = getOrderById(id);
        if (order.getStatus() != OrderStatus.READY) {
            throw new InvalidStatusTransitionException(order.getStatus(), OrderStatus.PAID);
        }
        order.setStatus(OrderStatus.PAID);
        return orderRepo.save(order);
    }
}
