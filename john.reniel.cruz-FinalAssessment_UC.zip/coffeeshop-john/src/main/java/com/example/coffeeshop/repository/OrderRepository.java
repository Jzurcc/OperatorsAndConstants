package com.example.coffeeshop.repository;

import com.example.coffeeshop.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // nothing needed here — just the interface declaration above

}
