package com.example.coffeeshop.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.coffeeshop.exception.MenuItemNotFoundException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.repository.MenuItemRepository;

@Service

public class MenuService {

    private static final Logger log = LoggerFactory.getLogger(MenuService.class);
    private final MenuItemRepository repo;

    public MenuService(MenuItemRepository repo) {
        this.repo = repo;
    }

    public List<MenuItem> getAllItems() {
        log.info("Fetching all menu items");
        List<MenuItem> menuItems = repo.findAll();
        log.info("Found {} menu items", menuItems.size());
        return menuItems;
    }

    public MenuItem getItemById(Long id) {
        log.info("Getting item with id: {}", id);
        return repo.findById(id).orElseThrow(() -> new MenuItemNotFoundException(id));
    }

    public MenuItem createItem(MenuItem item) {
        log.info("Creating menu item: name={}, category={}, price={}, available={}", item.getName(),
                item.getCategory(), item.getPrice(), item.isAvailable());
        MenuItem created = repo.save(item);
        log.info("Created menu item {}", created.getId());
        return created;
    }

    public MenuItem updateItem(Long id, MenuItem updated) {
        log.info("Updating menu item with id: {}", id);
        MenuItem existing = getItemById(id);

        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setPrice(updated.getPrice());
        existing.setAvailable(updated.isAvailable());
        MenuItem updatedItem = repo.save(existing);
        log.info("Updated menu item with id={}, name={}", updatedItem.getId(), updatedItem.getName());
        return updatedItem;
    }

    public void deleteItem(Long id) {
        log.info("Deleting menu item with id: {}", id);
        MenuItem existing = getItemById(id);
        repo.delete(existing);
    }

    public List<MenuItem> getByCategory(String category) {
        log.info("Getting menu items by category: {}", category);
        return repo.findByCategoryIgnoreCase(category);
    }

    public List<MenuItem> getAvailableItems() {
        log.info("Getting available menu items");
        return repo.findByAvailableTrue();
    }
}
